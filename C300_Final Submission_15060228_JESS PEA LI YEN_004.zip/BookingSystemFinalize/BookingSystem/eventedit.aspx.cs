﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class eventedit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                object obj = Session["event_id"];

                string bookingid = Request.QueryString["event_booking_id"].ToString();

                string eventid = @"SELECT * FROM Events_booking eb,Events e ,Event_Venue ev, Event_shift_master esm 
WHERE eb.event_date_shift=esm.event_date_shift AND e.event_id=esm.event_id 
AND ev.venue_id=esm.venue_id AND event_booking_id='{0}'";

                DataTable vs = DBUtl.GetTable(eventid, bookingid);



                string sql1 = @"SELECT CONCAT(event_start_date,' - ',event_end_date) AS shift , shift_desc , event_date_shift FROM Events e,Event_venue ev,Event_shift_master esm WHERE e.event_id=esm.event_id 
AND ev.venue_id = esm.venue_id AND e.event_id ={0}";


                DataTable dss = DBUtl.GetTable(sql1, vs.Rows[0]["event_id"].ToString());
                DrpVenue.DataSource = dss;
                DrpVenue.DataTextField = "shift"; // the items to be displayed in the list items
                DrpVenue.DataValueField = "event_date_shift"; // the id of the items displayed
                DrpVenue.DataBind();
                DrpVenue.Items.Insert(0, "-- Select --");




                if (vs.Rows.Count == 1)
                {
                    TxtID.Text = vs.Rows[0]["event_booking_id"].ToString();
                    TxtName.Text = vs.Rows[0]["event_name"].ToString();
                    TxtVenue.Text = vs.Rows[0]["event_venue"].ToString();
                    DrpVenue.SelectedValue = vs.Rows[0]["event_date_shift"].ToString();


                }
                else
                {
                    LtlMessage.Text = "booking cant be retrieve!";
                }
            }

        }

        protected void BtnInsert_Click(object sender, EventArgs e)
        {
            string bookingid = Request.QueryString["event_booking_id"].ToString();

            string sql1 = @"SELECT * FROM Events_booking eb, Events e ,Event_Venue ev, Event_shift_master esm
 WHERE eb.event_date_shift = esm.event_date_shift AND e.event_id = esm.event_id
AND ev.venue_id = esm.venue_id AND nric = '{0}' AND eb.event_date_shift = '{1}'";

            sql1 = String.Format(sql1, Session["nric"].ToString(), DrpVenue.SelectedValue);
            DataTable dt = DBUtl.GetTable(sql1);




            string sql3 = @"SELECT * FROM Events_booking eb, Events e ,Event_Venue ev, Event_shift_master esm
 WHERE eb.event_date_shift = esm.event_date_shift AND e.event_id = esm.event_id
AND ev.venue_id = esm.venue_id AND e.event_id='{1}' AND nric = '{0}'";
            DataTable dtt = DBUtl.GetTable(sql3, Session["nric"].ToString(), 3);

            

            if (dt.Rows.Count == 1)
            {
                LtlMessage.Text = "Sorry you have booked this shift previously";
            }
            else if (DrpVenue.SelectedValue.Equals("6")|| DrpVenue.SelectedValue.Equals("4")|| DrpVenue.SelectedValue.Equals("5")) {


                if (dtt.Rows.Count == 2)
                {
                    LtlMessage.Text = "Sorry you cant change the shift ";
                }
                else
                {
                    string sql = @"UPDATE Events_booking SET event_date_shift='{0}' WHERE event_booking_id={1}";
                    sql = String.Format(sql, DrpVenue.SelectedValue, bookingid);
                    if (DBUtl.ExecSQL(sql) == 1)
                    {
                        LtlMessage.Text = "updated successfully!";


                    }
                    else
                    {
                        LtlMessage.Text = "error in updating";
                    }
                }
            

            }
            else
            {

                string sql = @"UPDATE Events_booking SET event_date_shift='{0}' WHERE event_booking_id={1}";
                sql = String.Format(sql, DrpVenue.SelectedValue, bookingid);
                if (DBUtl.ExecSQL(sql) == 1)
                {
                    LtlMessage.Text = "updated successfully!";


                }
                else
                {
                    LtlMessage.Text = "error in updating";
                }
            }
        }
    }
}






