﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class SAdminMaintainDatabase : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateTier();

                GenerateDrpTier();
                GenerateCluster();

                GenerateDrpCluster();
                GenerateSubCluster();

                GenerateShiftMaster();

                GenerateDrpShiftMaster();
                GenerateShifts();

                GenerateSkills();

                GenerateLocation();

                GenerateDriving();

                GenerateRank();

                GenerateRole();

                GenerateDrpSubCluster();
                GenerateSubShift();
                GenerateDrpShiftCode();
            }
        }

        private void GenerateRole()
        {
            GvRole.DataSource = DBUtl.GetTable("SELECT * FROM Role");
            GvRole.DataBind();
        }

        private void GenerateRank()
        {
            GvRank.DataSource = DBUtl.GetTable("SELECT * FROM Rank");
            GvRank.DataBind();
        }

        private void GenerateDriving()
        {
            GvDriving.DataSource = DBUtl.GetTable("SELECT * FROM Driving_Class");
            GvDriving.DataBind();
        }

        private void GenerateTier()
        {
            GvTier.DataSource = DBUtl.GetTable("SELECT * FROM Tier");
            GvTier.DataBind();
        }

        private void GenerateCluster()
        {
            GvCluster.DataSource = DBUtl.GetTable(String.Format(@"SELECT * FROM Cluster C, Tier T 
                                                                WHERE C.tier_id = T.tier_id 
                                                                AND T.tier_id = '{0}'", DrpTier.SelectedItem.Value));
            GvCluster.DataBind();
        }

        private void GenerateDrpTier()
        {
            string sql = @"SELECT * FROM Tier WHERE tier_id != 1";
            DataTable db = DBUtl.GetTable(sql);

            // Code for last location
            DrpTier.DataSource = db;
            DrpTier.DataTextField = "tier_no"; // the items to be displayed in the list items
            DrpTier.DataValueField = "tier_id"; // the id of the items displayed
            DrpTier.DataBind();
            DrpTier.SelectedIndex = 1;
            LtlTier.Text = DrpTier.SelectedItem.Text;
        }

        private void GenerateSkills()
        {
            GvSkills.DataSource = DBUtl.GetTable("SELECT * FROM Skills");
            GvSkills.DataBind();
        }

        private void GenerateLocation()
        {
            GvLocation.DataSource = DBUtl.GetTable("SELECT * FROM Prev_Location");
            GvLocation.DataBind();
        }

        private void GenerateShiftMaster()
        {
            GvShiftMaster.DataSource = DBUtl.GetTable("SELECT * FROM Shift_Master");
            GvShiftMaster.DataBind();
        }

        private void GenerateDrpShiftMaster()
        {
            string sql = @"SELECT * FROM Shift_Master";
            DataTable db = DBUtl.GetTable(sql);

            // Code for last location
            DrpShiftMaster.DataSource = db;
            DrpShiftMaster.DataTextField = "shift_id"; // the items to be displayed in the list items
            DrpShiftMaster.DataValueField = "shift_id"; // the id of the items displayed
            DrpShiftMaster.DataBind();
            int id = Convert.ToInt32(Convert.ToString(DrpShiftMaster.SelectedItem.Value)) - 1;
            LtlTimingHours.Text = "Time: " + db.Rows[id]["shift_timing"].ToString() + "</br>" +
                                    "Hours: " + db.Rows[id]["shift_hours"].ToString();
            LtlShiftMaster.Text = DrpShiftMaster.SelectedItem.Value;
        }

        private void GenerateShifts()
        {
            GvShifts.DataSource = DBUtl.GetTable(String.Format(@"SELECT * FROM Shifts S, Shift_Master SM 
                                                    WHERE S.shift_id = SM.shift_id
                                                    AND SM.shift_id = '{0}'", DrpShiftMaster.SelectedItem.Value));
            GvShifts.DataBind();
        }

        private void GenerateDrpCluster()
        {
            string sql = @"SELECT * FROM Cluster";
            DataTable db = DBUtl.GetTable(sql);

            // Code for last location
            DrpCluster.DataSource = db;
            DrpCluster.DataTextField = "cluster_name"; // the items to be displayed in the list items
            DrpCluster.DataValueField = "cluster_id"; // the id of the items displayed
            DrpCluster.DataBind();
            DrpCluster.SelectedIndex = 1;
            LtlCluster.Text = DrpCluster.SelectedItem.Text;
        }

        private void GenerateSubCluster()
        {
            GvSubCluster.DataSource = DBUtl.GetTable(String.Format(@"SELECT * FROM Cluster C, Sub_Cluster SC
                                                    WHERE C.cluster_id = SC.cluster_id
                                                    AND C.cluster_id = '{0}'", DrpCluster.SelectedItem.Value));
            GvSubCluster.DataBind();
        }

        private void GenerateDrpSubCluster()
        {
            string sql = @"SELECT * FROM Sub_Cluster";
            DataTable db = DBUtl.GetTable(sql);

            // Code for last location
            DrpSubCluster.DataSource = db;
            DrpSubCluster.DataTextField = "sub_cluster_name"; // the items to be displayed in the list items
            DrpSubCluster.DataValueField = "sub_cluster_id"; // the id of the items displayed
            DrpSubCluster.DataBind();
            DrpSubCluster.SelectedIndex = 1;
            LtlSubCluster.Text = DrpSubCluster.SelectedItem.Text;
        }

        private void GenerateSubShift()
        {
            string sql = String.Format(@"SELECT * FROM Shift_Master SM, Shifts S, Sub_Cluster SC, Sub_Cluster_has_Shift SCS
                                        WHERE SM.shift_id = S.shift_id
                                        AND S.shift_code = SCS.shift_code
                                        AND SCS.sub_cluster_id = SC.sub_cluster_id
                                        AND SC.sub_cluster_id = '{0}'", DrpSubCluster.SelectedItem.Value);
            GvSubShifts.DataSource = DBUtl.GetTable(sql);
            GvSubShifts.DataBind();
        }

        private void GenerateDrpShiftCode()
        {
            string sql = @"SELECT * FROM Shifts";
            DataTable db = DBUtl.GetTable(sql);

            // Code for last location
            DrpShiftCode.DataSource = db;
            DrpShiftCode.DataTextField = "shift_code"; // the items to be displayed in the list items
            DrpShiftCode.DataValueField = "shift_code"; // the id of the items displayed
            DrpShiftCode.DataBind();
            DrpShiftCode.Items.Insert(0, "--- Select Shift Code ---");
            DrpShiftCode.SelectedIndex = 0;
        }

        protected void BtnRole_Click(object sender, EventArgs e)
        {
            if (TxtRole.Text.Trim().Equals(""))
                return;
            string role = TxtRole.Text.Trim();
            string sql = String.Format(@"INSERT INTO Role(role_name) VALUES('{0}')", role);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateRole();
            refershPage();
        }

        protected void GvRole_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int role_id = Convert.ToInt32(GvRole.DataKeys[e.RowIndex].Value.ToString());
            string sqlRole = String.Format(@"DELETE FROM Role WHERE role_id = '{0}'", role_id);
            if (DBUtl.ExecSQL(sqlRole) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateRole();
        }

        protected void GvRole_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvRole.EditIndex = e.NewEditIndex;
            GenerateRole();
        }

        protected void GvRole_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvRole.Rows[e.RowIndex];
            TextBox TxtName = (TextBox)row.FindControl("TxtRoleName");
            int role_id = Convert.ToInt32(GvRole.DataKeys[e.RowIndex].Value.ToString());
            string role_name = TxtName.Text;
            string sqlRole = String.Format(@"UPDATE Role SET role_name = '{1}' WHERE role_id = '{0}'", role_id, role_name);
            if (DBUtl.ExecSQL(sqlRole) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvRole.EditIndex = -1;
            GenerateRole();
        }

        protected void GvRole_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvRole.EditIndex = -1;
            GenerateRole();
        }

        protected void GvRank_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int rank_id = Convert.ToInt32(GvRank.DataKeys[e.RowIndex].Value.ToString());
            string sqlRank = String.Format(@"DELETE FROM Rank WHERE rank_id = '{0}'", rank_id);
            if (DBUtl.ExecSQL(sqlRank) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateRank();
        }

        protected void GvRank_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvRank.EditIndex = -1;
            GenerateRank();
        }

        protected void GvRank_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvRank.EditIndex = e.NewEditIndex;
            GenerateRank();
        }

        protected void GvRank_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvRank.Rows[e.RowIndex];
            TextBox TxtName = (TextBox)row.FindControl("TxtRankName");
            int rank_id = Convert.ToInt32(GvRank.DataKeys[e.RowIndex].Value.ToString());
            string rank_name = TxtName.Text;
            string sqlRank = String.Format(@"UPDATE Rank SET rank_name = '{1}' WHERE rank_id = '{0}'", rank_id, rank_name);
            if (DBUtl.ExecSQL(sqlRank) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvRank.EditIndex = -1;
            GenerateRank();
        }

        protected void BtnRank_Click(object sender, EventArgs e)
        {
            if (TxtRank.Text.Trim().Equals(""))
                return;
            string rank = TxtRank.Text.Trim();
            string sql = String.Format(@"INSERT INTO Rank(rank_name) VALUES('{0}')", rank);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateRank();
            refershPage();
        }

        protected void GvDriving_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int driving_id = Convert.ToInt32(GvDriving.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Driving_Class WHERE driving_id = '{0}'", driving_id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateDriving();
        }

        protected void GvDriving_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvDriving.EditIndex = -1;
            GenerateDriving();
        }

        protected void GvDriving_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvDriving.EditIndex = e.NewEditIndex;
            GenerateDriving();
        }

        protected void GvDriving_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvDriving.Rows[e.RowIndex];
            TextBox TxtName = (TextBox)row.FindControl("TxtDrivingName");
            int driving_id = Convert.ToInt32(GvDriving.DataKeys[e.RowIndex].Value.ToString());
            string driving_name = TxtName.Text;
            string sql = String.Format(@"UPDATE Driving_Class SET driving_name = '{1}' WHERE driving_id = '{0}'", driving_id, driving_name);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvDriving.EditIndex = -1;
            GenerateDriving();
        }

        protected void BtnDriving_Click(object sender, EventArgs e)
        {
            if (TxtDriving.Text.Trim().Equals(""))
                return;
            string driving = TxtDriving.Text.Trim();
            string sql = String.Format(@"INSERT INTO Driving_Class(driving_name) VALUES('{0}')", driving);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateDriving();
            refershPage();
        }

        protected void GvTier_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int tier_id = Convert.ToInt32(GvTier.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Tier WHERE tier_id = '{0}'", tier_id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateTier();
        }

        protected void GvTier_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvTier.EditIndex = -1;
            GenerateTier();
        }

        protected void GvTier_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvTier.EditIndex = e.NewEditIndex;
            GenerateTier();
        }

        protected void GvTier_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvTier.Rows[e.RowIndex];
            TextBox TxtName = (TextBox)row.FindControl("TxtName");
            int tier_id = Convert.ToInt32(GvTier.DataKeys[e.RowIndex].Value.ToString());
            string tier_name = TxtName.Text;
            string sql = String.Format(@"UPDATE Tier SET tier_no = '{1}' WHERE tier_id = '{0}'", tier_id, tier_name);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvTier.EditIndex = -1;
            GenerateTier();
        }

        protected void BtnTier_Click(object sender, EventArgs e)
        {
            if (TxtTier.Text.Trim().Equals(""))
                return;
            string tier = TxtTier.Text.Trim();
            string sql = String.Format(@"INSERT INTO Tier(tier_no) VALUES('{0}')", tier);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateTier();
            refershPage();
        }

        protected void GvCluster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int cluster_id = Convert.ToInt32(GvCluster.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Cluster WHERE cluster_id = '{0}'", cluster_id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateCluster();
        }

        protected void GvCluster_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvCluster.EditIndex = -1;
            GenerateCluster();
        }

        protected void GvCluster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvCluster.EditIndex = e.NewEditIndex;
            GenerateCluster();
        }

        protected void GvCluster_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvCluster.Rows[e.RowIndex];
            TextBox TxtCluster = (TextBox)row.FindControl("TxtName");
            int id = Convert.ToInt32(GvCluster.DataKeys[e.RowIndex].Value.ToString());
            string Cluster = TxtCluster.Text;
            string sql = String.Format(@"UPDATE Cluster SET cluster_name = '{1}'
                                        WHERE cluster_id = '{0}'", id, Cluster);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvCluster.EditIndex = -1;
            GenerateCluster();
        }

        protected void BtnCluster_Click(object sender, EventArgs e)
        {
            if (TxtCluster.Text.Trim().Equals(""))
                return;
            string cluster = TxtCluster.Text.Trim();
            string sql = String.Format(@"INSERT INTO Cluster(cluster_name, tier_id) 
                                        VALUES('{0}', '{1}')", cluster, DrpTier.SelectedItem.Value);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateCluster();
            refershPage();
        }

        protected void GvSkills_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GvSkills.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Skills WHERE skill_id = '{0}'", id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateSkills();
        }

        protected void GvSkills_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvSkills.EditIndex = -1;
            GenerateSkills();
        }

        protected void GvSkills_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvSkills.EditIndex = e.NewEditIndex;
            GenerateSkills();
        }

        protected void GvSkills_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvSkills.Rows[e.RowIndex];
            TextBox TxtName = (TextBox)row.FindControl("TxtName");
            int id = Convert.ToInt32(GvSkills.DataKeys[e.RowIndex].Value.ToString());
            string name = TxtName.Text;
            string sql = String.Format(@"UPDATE Skills SET skill_name = '{1}' WHERE skill_id = '{0}'", id, name);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvSkills.EditIndex = -1;
            GenerateSkills();
        }

        protected void BtnSkill_Click(object sender, EventArgs e)
        {
            if (TxtSkill.Text.Trim().Equals(""))
                return;
            string name = TxtSkill.Text.Trim();
            string sql = String.Format(@"INSERT INTO Skills(skill_name) VALUES('{0}')", name);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateSkills();
            refershPage();
        }

        protected void GvLocation_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GvLocation.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Prev_Location WHERE prev_id = '{0}'", id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateLocation();
        }

        protected void GvLocation_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvLocation.EditIndex = -1;
            GenerateLocation();
        }

        protected void GvLocation_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvLocation.EditIndex = e.NewEditIndex;
            GenerateLocation();
        }

        protected void GvLocation_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvLocation.Rows[e.RowIndex];
            TextBox TxtName = (TextBox)row.FindControl("TxtName");
            int id = Convert.ToInt32(GvLocation.DataKeys[e.RowIndex].Value.ToString());
            string name = TxtName.Text;
            string sql = String.Format(@"UPDATE Prev_Location SET loca_name = '{1}' WHERE prev_id = '{0}'", id, name);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvLocation.EditIndex = -1;
            GenerateLocation();
        }

        protected void BtnLocation_Click(object sender, EventArgs e)
        {
            if (TxtLocation.Text.Trim().Equals(""))
                return;
            string name = TxtLocation.Text.Trim();
            string sql = String.Format(@"INSERT INTO Prev_Location(loca_name) VALUES('{0}')", name);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateLocation();
            refershPage();
        }

        protected void GvShiftMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GvShiftMaster.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Shift_Master WHERE shift_id = '{0}'", id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateShiftMaster();
        }

        protected void GvShiftMaster_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvShiftMaster.EditIndex = -1;
            GenerateShiftMaster();
        }

        protected void GvShiftMaster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvShiftMaster.EditIndex = e.NewEditIndex;
            GenerateShiftMaster();
        }

        protected void GvShiftMaster_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvShiftMaster.Rows[e.RowIndex];
            TextBox TxtTiming = (TextBox)row.FindControl("TxtTiming");
            TextBox TxtHours = (TextBox)row.FindControl("TxtHours");
            int id = Convert.ToInt32(GvShiftMaster.DataKeys[e.RowIndex].Value.ToString());
            string hours = TxtHours.Text;
            string timing = TxtTiming.Text;
            string sql = String.Format(@"UPDATE Shift_Master 
                                        SET shift_timing = '{1}', shift_hours = '{2}' 
                                        WHERE shift_id = '{0}'", id, timing, hours);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvShiftMaster.EditIndex = -1;
            GenerateShiftMaster();
        }

        protected void BtnShift_Click(object sender, EventArgs e)
        {
            if (TxtTiming.Text.Trim().Equals("") && TxtHours.Text.Trim().Equals(""))
                return;
            string timing = TxtTiming.Text.Trim();
            string hours = TxtHours.Text.Trim();
            string sql = String.Format(@"INSERT INTO Shift_Master(shift_timing, shift_hours) 
                                        VALUES('{0}', '{1}')", timing, hours);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateShiftMaster();
            refershPage();
        }

        protected void GvShifts_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GvShifts.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Shifts WHERE shift_code = '{0}'", id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateShifts();
        }

        protected void GvShifts_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvShifts.EditIndex = -1;
            GenerateShifts();
        }

        protected void GvShifts_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvShifts.EditIndex = e.NewEditIndex;
            GenerateShifts();
        }

        protected void GvShifts_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvShifts.Rows[e.RowIndex];
            TextBox TxtShiftNo = (TextBox)row.FindControl("TxtShiftNo");
            int id = Convert.ToInt32(GvShifts.DataKeys[e.RowIndex].Value.ToString());
            string shiftNo = TxtShiftNo.Text;
            string sql = String.Format(@"UPDATE Shifts SET shift_no = '{1}'
                                        WHERE shift_code = '{0}'", id, shiftNo);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvShifts.EditIndex = -1;
            GenerateShifts();
        }

        protected void BtnShifts_Click(object sender, EventArgs e)
        {
            if (TxtShiftNO.Text.Trim().Equals(""))
                return;
            string shiftNo = TxtShiftNO.Text.Trim();
            string sql = String.Format(@"INSERT INTO Shifts(shift_no, shift_id) 
                                        VALUES('{0}', '{1}')", shiftNo, DrpShiftMaster.SelectedItem.Value);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateShifts();
            refershPage();
        }

        protected void DrpShiftMaster_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = @"SELECT * FROM Shift_Master";
            DataTable db = DBUtl.GetTable(sql);

            int id = Convert.ToInt32(Convert.ToString(DrpShiftMaster.SelectedItem.Value)) - 1;
            LtlTimingHours.Text = "Time: " + db.Rows[id]["shift_timing"].ToString() + "</br>" +
                                    "Hours: " + db.Rows[id]["shift_hours"].ToString();
            LtlShiftMaster.Text = DrpShiftMaster.SelectedItem.Value;
            GenerateShifts();
        }

        protected void GvSubCluster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GvSubCluster.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Sub_Cluster WHERE sub_cluster_id = '{0}'", id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateSubCluster();
        }

        protected void GvSubCluster_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvSubCluster.EditIndex = -1;
            GenerateSubCluster();
        }

        protected void GvSubCluster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvSubCluster.EditIndex = e.NewEditIndex;
            GenerateSubCluster();
        }

        protected void GvSubCluster_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvSubCluster.Rows[e.RowIndex];
            TextBox TxtSubCluster = (TextBox)row.FindControl("TxtName");
            int id = Convert.ToInt32(GvSubCluster.DataKeys[e.RowIndex].Value.ToString());
            string subCluster = TxtSubCluster.Text;
            string sql = String.Format(@"UPDATE Sub_Cluster SET sub_cluster_name = '{1}'
                                        WHERE sub_cluster_id = '{0}'", id, subCluster);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvSubCluster.EditIndex = -1;
            GenerateSubCluster();
        }

        protected void BtnSubCluster_Click(object sender, EventArgs e)
        {
            if (TxtSubName.Text.Trim().Equals(""))
                return;
            string subName = TxtSubName.Text.Trim();
            string sql = String.Format(@"INSERT INTO Sub_Cluster(sub_cluster_name, cluster_id) 
                                        VALUES('{0}', '{1}')", subName, DrpCluster.SelectedItem.Value);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateSubCluster();
            refershPage();
        }

        protected void DrpCluster_SelectedIndexChanged(object sender, EventArgs e)
        {
            LtlCluster.Text = DrpCluster.SelectedItem.Text;
            GenerateSubCluster();
        }

        protected void DrpTier_SelectedIndexChanged(object sender, EventArgs e)
        {
            LtlTier.Text = DrpTier.SelectedItem.Text;
            GenerateCluster();
        }

        private void refershPage()
        {
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
        }

        protected void GvSubShifts_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GvSubShifts.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Sub_Cluster_has_Shift WHERE sub_shift_id = '{0}'", id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateSubShift();
        }

        protected void GvSubShifts_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvSubShifts.EditIndex = -1;
            GenerateSubShift();
        }

        protected void GvSubShifts_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvSubShifts.EditIndex = e.NewEditIndex;
            GenerateSubShift();
        }

        protected void GvSubShifts_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvSubShifts.Rows[e.RowIndex];
            TextBox TxtCode = (TextBox)row.FindControl("TxtShiftCode");
            int id = Convert.ToInt32(GvSubShifts.DataKeys[e.RowIndex].Value.ToString());
            string shiftCode = TxtCode.Text;
            string sql = String.Format(@"UPDATE Sub_Cluster_has_Shift SET shift_code = '{1}'
                                        WHERE sub_shift_id = '{0}'", id, shiftCode);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvSubShifts.EditIndex = -1;
            GenerateSubShift();
        }

        protected void DrpSubCluster_SelectedIndexChanged(object sender, EventArgs e)
        {
            LtlSubCluster.Text = DrpSubCluster.SelectedItem.Text;
            GenerateSubShift();
        }

        protected void BtnSubShift_Click(object sender, EventArgs e)
        {
            if (DrpShiftCode.SelectedIndex == 0)
                return;
            string shiftCode = DrpShiftCode.SelectedItem.Value;
            string sql = String.Format(@"INSERT INTO Sub_Cluster_has_Shift(sub_cluster_id, shift_code) 
                                        VALUES('{0}', '{1}')", DrpSubCluster.SelectedItem.Value, shiftCode);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Insert Successfully";
            else
                LtlMessage.Text = "Failed to Insert" + DBUtl.DB_Message;
            GenerateSubShift();
            refershPage();
        }
    }
}