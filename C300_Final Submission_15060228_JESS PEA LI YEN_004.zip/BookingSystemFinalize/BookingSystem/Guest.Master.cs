﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookingSystem
{
    public partial class Guest : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[""] == null)
            {
                LnkLogin.Visible = true;
                LnkLogout.Visible = false;
                LnkBrand.Enabled = false;
                return;
            }
            if (Session["role"].ToString().Equals(RoleType.SUPERADMIN))
            {
                Response.Redirect("SAdminHome.aspx");
            } else if (Session["role"].ToString().Equals(RoleType.ADMIN))
            {
                Response.Redirect("Home.aspx");
            } else if (Session["role"].ToString().Equals(RoleType.USER))
            {
                Response.Redirect("UserHome.aspx");
            }
        }
    }
}