﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.Cookies["userid"] != null &&
                    Request.Cookies["userpw"] != null)
                {
                    TxtUserID.Text = Request.Cookies["userid"].Value;
                    TxtPassword.Attributes["value"] = Request.Cookies["userpw"].Value;
                    ChkRemember.Checked = true;
                }
            }
        }

        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            string userid = TxtUserID.Text.Trim();
            string passwd = TxtPassword.Text.Trim();

            if (userid.Equals("") || passwd.Equals(""))
            {
                LtlMessage.Text = "Please enter User ID and Password";
                return;
            }

            string name = "";
            string cluster = "";
            string nric = TxtUserID.Text;
            RoleType role;
            if (!SecureValidUser(TxtUserID.Text, TxtPassword.Text, out name, out cluster, out role))
            {
                LtlMessage.Text = "Invalid nric and password";
                return;
            }
            string status = "";
            if (!CheckActiveUser(TxtUserID.Text, out status))
            {
                LtlMessage.Text = "Account Deactivated. Contact Aetos for more information";
                return;
            }
            Session["nric"] = nric;
            Session["name"] = name;
            Session["cluster"] = cluster;
            Session["role"] = role;
            Session["login"] = "success";

            Response.Cookies["userid"].Value = userid;
            Response.Cookies["userpw"].Value = passwd;
            if (ChkRemember.Checked)
            {
                Response.Cookies["userid"].Expires = DateTime.Now.AddDays(30);
                Response.Cookies["userpw"].Expires = DateTime.Now.AddDays(30);
            }
            else
            {
                Response.Cookies["userid"].Expires = DateTime.Now.AddDays(-1);
                Response.Cookies["userpw"].Expires = DateTime.Now.AddDays(-1);
            }

            if (Request["redirect"] != null)
                Response.Redirect(Request["redirect"]);
            else if (role.Equals(RoleType.USER))
                Response.Redirect("Broadcast.aspx");
            else if (role.Equals(RoleType.ADMIN))
                Response.Redirect("AdminBroadcast.aspx");
            else if (role.Equals(RoleType.SUPERADMIN))
                Response.Redirect("SAdminBroadcast.aspx");
            return;
        }

        private bool SecureValidUser(string uid, string pw, out string name, out string cluster, out RoleType role)
        {
            string sql = @"SELECT * FROM Users U, User_has_Cluster UC, Cluster C, Role R
                        WHERE U.nric = UC.nric
                        AND UC.cluster_id = C.cluster_id
                        AND U.role_id = R.role_id
                        AND U.nric='{0}' 
                        AND pwd = HASHBYTES('SHA1', '{1}')";

            DataTable ds = DBUtl.GetTable(sql, uid, pw);

            if (ds.Rows.Count == 1)
            {
                name = ds.Rows[0]["name"].ToString();
                cluster = ds.Rows[0]["cluster_name"].ToString();
                if (ds.Rows[0]["role_name"].ToString().Equals("SUPERADMIN"))
                    role = RoleType.SUPERADMIN;
                else if (ds.Rows[0]["role_name"].ToString().Equals("ADMIN"))
                    role = RoleType.ADMIN;
                else
                    role = RoleType.USER;
                return true;
            }
            else
            {
                name = "";
                cluster = "";
                role = RoleType.NULL;
                return false;
            }
        }

        private bool CheckActiveUser(string uid, out string status)
        {
            string sql = @"SELECT * FROM Users U, status S
                        WHERE U.status_id = S.status_id
                        AND U.nric='{0}'";

            DataTable ds = DBUtl.GetTable(sql, uid);

            if (ds.Rows[0]["status_name"].ToString().Equals("Active"))
            {
                status = ds.Rows[0]["status_name"].ToString();
                return true;
            }
            else
            {
                status = ds.Rows[0]["status_name"].ToString();
                return false;
            }
        }
    }
}