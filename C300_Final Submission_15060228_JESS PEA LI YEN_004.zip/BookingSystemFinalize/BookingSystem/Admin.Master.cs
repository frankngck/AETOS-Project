﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class Admin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["nric"] == null)
            {
                Response.Redirect("Login.aspx?redirect=" + Page.AppRelativeVirtualPath);
                return;
            }

            if (!Session["role"].Equals(RoleType.ADMIN))
            {
                Response.Redirect("NotAuthorised.aspx");
                return;
            }
            LnkLogin.Visible = false;
            LtlUserName.Text = "Welcome, " + Session["name"].ToString() + ", " + Session["cluster"].ToString();
            navBar.DataSource = GetMenu();
            navBar.DataBind();
        }

        private DataTable GetMenu()
        {
            string sql = String.Format(@"SELECT * FROM Cluster C, Sub_Cluster SC 
                                        WHERE C.cluster_id = SC.cluster_id 
                                        AND cluster_name = '{0}'", Session["cluster"].ToString());
            return DBUtl.GetTable(sql);
        }
    }
}