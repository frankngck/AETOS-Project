﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class eventdelete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string bookingid = Request.QueryString["event_booking_id"].ToString();
            string sql = "DELETE FROM Events_booking  WHERE event_booking_id={0}";
            sql = String.Format(sql, bookingid);

            string eventid= @"SELECT event_id FROM Events_booking eb,event_shift_master esm WHERE eb.event_date_shift=esm.event_date_shift AND event_booking_id={0}";
            DataTable vs = DBUtl.GetTable(eventid, bookingid);
            int eventnum = Convert.ToInt32(vs.Rows[0]["event_id"]);

            string number = @"SELECT available_slots FROM Events WHERE event_id={0}";
            DataTable ds = DBUtl.GetTable(number,eventnum);
            int num= Convert.ToInt32(ds.Rows[0]["available_slots"]) + 1;



            if (DBUtl.ExecSQL(sql) == 1)

            {

                string sql2 = @"UPDATE Events SET available_slots={0} WHERE event_id={1}";
                if (DBUtl.ExecSQL(sql2, num, eventnum) == 1)
                {

                }

                Literal1.Text = "Event Booking Cancelled.";
            }
            else
            {
                Literal1.Text = "Unsuccessful Cancellation ";
            }
        }

    }
    }
