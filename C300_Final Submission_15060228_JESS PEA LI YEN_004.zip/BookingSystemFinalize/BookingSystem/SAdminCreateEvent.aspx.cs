﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class SAdminCreateEvent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                HideNewEvent();
                HideNewElements();
                GenerateDrpEventName();
                GenerateDrpVenueName();
                return;
            }
        }

        private void ShowNewEvent()
        {
            TxtName.Enabled = true;
            TxtSlots.Enabled = true;
            DrpEventName.Enabled = false;
            DrpEventName.SelectedIndex = 0;
            TxtName.Text = "";
            TxtSlots.Text = "";
        }

        private void HideNewEvent()
        {
            TxtName.Enabled = false;
            TxtSlots.Enabled = false;
            DrpEventName.Enabled = true;
        }

        private void ShowNewVenue()
        {
            TxtVenue.Enabled = true;
            DrpVenue.Enabled = false;
            DrpVenue.SelectedIndex = 0;
            TxtVenue.Text = "";
        }

        private void HideNewVenue()
        {
            TxtVenue.Enabled = false;
            DrpVenue.Enabled = true;
        }

        private void HideNewElements()
        {
            TxtName.Enabled = false;
            TxtSlots.Enabled = false;
            TxtVenue.Enabled = false;
            DrpEventName.Enabled = true;
            DrpVenue.Enabled = true;
            TxtName.Text = "";
            TxtSlots.Text = "";
            TxtVenue.Text = "";
        }

        private void GenerateDrpEventName()
        {
            string sql = @"SELECT * FROM Events ORDER BY event_name";
            DataTable dt = DBUtl.GetTable(sql);
            DrpEventName.DataSource = dt;
            DrpEventName.DataTextField = "event_name";
            DrpEventName.DataValueField = "event_id";
            DrpEventName.DataBind();
            DrpEventName.Items.Insert(0, "--- Select ---");
        }

        private void GenerateDrpVenueName()
        {
            string sql = @"SELECT * FROM Event_venue";
            DataTable dt = DBUtl.GetTable(sql);
            DrpVenue.DataSource = dt;
            DrpVenue.DataTextField = "event_venue";
            DrpVenue.DataValueField = "venue_id";
            DrpVenue.DataBind();
            DrpVenue.Items.Insert(0, "--- Select ---");
        }

        protected void DrpEventName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DrpEventName.SelectedIndex == 0)
            {
                TxtName.Text = "";
                TxtSlots.Text = "";
                return;
            }
            TxtName.Text = DrpEventName.SelectedItem.Text;
            TxtSlots.Text = DBUtl.GetTable("SELECT * FROM Events WHERE event_id = " + DrpEventName.SelectedItem.Value).Rows[0]["available_slots"].ToString();
        }

        protected void DrpVenue_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DrpVenue.SelectedIndex == 0)
            {
                TxtVenue.Text = "";
                return;
            }
            TxtVenue.Text = DrpVenue.SelectedItem.Text;
        }

        protected void ChkNewEvent_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkNewEvent.Checked == true)
            {
                ShowNewEvent();
                return;
            }
            HideNewEvent();
        }

        protected void ChkNewVenue_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkNewVenue.Checked == true)
            {
                ShowNewVenue();
                return;
            }
            HideNewVenue();
        }

        protected void BtnCreate_Click(object sender, EventArgs e)
        {
            if (!IsValid)
            {
                return;
            }
            string event_id = DrpEventName.SelectedItem.Value;
            string venue_id = DrpVenue.SelectedItem.Value;
            if (ChkNewEvent.Checked == true)
            {
                string sqlEvent = String.Format(@"INSERT INTO Events(event_name, available_slots) 
                                        VALUES('{0}','{1}'); ",
                                        TxtName.Text, TxtSlots.Text);
                DBUtl.ExecSQL(sqlEvent);
                event_id = DBUtl.GetTable("SELECT * FROM Events WHERE event_name = '" + TxtName.Text + "'").Rows[0]["event_id"].ToString();
            }
            if (ChkNewVenue.Checked == true)
            {
                string sqlVenue = String.Format(@"INSERT INTO Event_venue(event_venue) 
                                        VALUES('{0}'); ",
                                        TxtVenue.Text);
                DBUtl.ExecSQL(sqlVenue);
                venue_id = DBUtl.GetTable("SELECT * FROM Event_venue WHERE event_venue = '" + TxtVenue.Text + "'").Rows[0]["venue_id"].ToString();
            }
            string sql = String.Format(@"INSERT INTO Event_shift_master(event_id, venue_id, 
                                        event_start_date, event_end_date, shift_desc) 
                                        VALUES('{0}','{1}','{2}','{3}','{4}')", 
                                        event_id, venue_id, TxtStartDate.Text, TxtEndDate.Text, TxtShift.Text);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Event Created Successfully ";
            else
                LtlMessage.Text = "Failed to Create " + sql + DBUtl.DB_Message;
        }
    }
}