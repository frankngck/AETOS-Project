﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;

namespace BookingSystem
{
    public partial class AdminReport : System.Web.UI.Page
    {
        // Ok
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Set the start date to today
                TxtStartDate.Text = DateTime.Now.ToString();
                // Set the end date to one week later
                TxtEndDate.Text = DateTime.Now.AddDays(7.0).ToString();

                // Generate the GridView for manpower available schedule
                GenerateGvManpower();

                // Generate the GridView for actual manpower schedule
                GenerateGvActual();
            }
        }

        private void GenerateGvManpower()
        {
            // Get the list of the date between the start & end date
            List<DateTime> dateList = GetDateList(Convert.ToDateTime(TxtStartDate.Text), Convert.ToDateTime(TxtEndDate.Text));

            // Get the list of names of cluster
            List<string> clusterList = GetClusterName();

            // Create new and empty datatable
            DataTable dt = new DataTable();
            // Create new row
            DataRow dr = null;

            // Header ONLY
            // Add column to the data table
            dt.Columns.Add(new DataColumn("Cluster Name", typeof(string)));

            // Header ONLY
            // Using loop to add columns according to the number of the date and the date as the title
            foreach (DateTime date in dateList)
            {
                dt.Columns.Add(new DataColumn(date.ToString("dd-MM-yyyy"), typeof(string)));
            }

            // CONTENT 
            // Using loop for the cluster
            foreach (string cluster_name in clusterList)
            {
                dr = dt.NewRow();
                // Add the cluster name to the table as the data below the header
                dr["Cluster Name"] = cluster_name;

                // Adding the number of ppl into the table according to the date by using a loop
                foreach (DateTime date in dateList)
                {
                    // The SQL to retrieve the number of ppl on a specific date
                    // number retreive is the number of part timers who book for that particular date
                    string get = @"SELECT COUNT(clusterbooking_id) AS '{0}'
                            FROM Cluster C, Sub_Cluster SB, Sub_Cluster_has_Shift SCS, Cluster_Booking CB
                            WHERE C.cluster_id = SB.cluster_id
                            AND SCS.sub_cluster_id = SB.sub_cluster_id 
                            AND SCS.sub_shift_id = CB.sub_shift_id
                            AND booking_date = '{1}'
                            AND cluster_name = '{2}';";

                    // Setting the header
                    string header = date.ToString("dd-MM-yyyy");
                    // Setting the value to be added to the table
                    string datafield = date.ToString("yyyy-MM-dd");

                    // Get table
                    DataTable db = DBUtl.GetTable(String.Format(get, header, datafield, cluster_name));

                    // Add into the datarow
                    dr[date.ToString("dd-MM-yyyy")] = db.Rows[0][0].ToString();
                }
                // Add into the datatable
                dt.Rows.Add(dr);
            }
            //Store the DataTable in ViewState
            // Din really used in other place 
            // Got it from website
            ViewState["CurrentTable"] = dt;

            // set the datatable to the gridview
            GvManpower.DataSource = dt;
            // bind/close the gridview
            GvManpower.DataBind();
        }

        private void GenerateGvActual() 
        {
            // actually the same way functioning as the GenerateGvManpower()
            // But this only get the number of ppl who actually attends/present

            List<DateTime> dateList = GetDateList(Convert.ToDateTime(TxtStartDate.Text), Convert.ToDateTime(TxtEndDate.Text));
            List<string> clusterList = GetClusterName();

            DataTable dt = new DataTable();
            DataRow dr = null;
            dt.Columns.Add(new DataColumn("Cluster Name", typeof(string)));
            foreach (DateTime date in dateList)
            {
                dt.Columns.Add(new DataColumn(date.ToString("dd-MM-yyyy"), typeof(string)));
            }

            foreach (string cluster_name in clusterList)
            {
                dr = dt.NewRow();
                dr["Cluster Name"] = cluster_name;
                foreach (DateTime date in dateList)
                {
                    // actually the same way functioning as the GenerateGvManpower()
                    // But this only get the number of ppl who actually attends/present
                    string get = @"SELECT COUNT(attendance_id) AS '{0}'
                            FROM Cluster C, Sub_Cluster SB, Sub_Cluster_has_Shift SCS, Cluster_Booking CB, Attendance A
                            WHERE C.cluster_id = SB.cluster_id
                            AND SCS.sub_cluster_id = SB.sub_cluster_id 
                            AND SCS.sub_shift_id = CB.sub_shift_id
                            AND CB.clusterbooking_id = A.clusterbooking_id
                            AND booking_date = '{1}'
                            AND cluster_name = '{2}'
                            AND attendance_status = 1;";

                    string header = date.ToString("dd-MM-yyyy");
                    string datafield = date.ToString("yyyy-MM-dd");
                    DataTable db = DBUtl.GetTable(String.Format(get, header, datafield, cluster_name));

                    dr[date.ToString("dd-MM-yyyy")] = db.Rows[0][0].ToString();
                }
                dt.Rows.Add(dr);
            }
            //Store the DataTable in ViewState
            ViewState["CurrentTable"] = dt;
            GvActualpower.DataSource = dt;
            GvActualpower.DataBind();
        }

        // Ok
        protected void BtnDisplay_Click(object sender, EventArgs e)
        {
            // This method is run when the user want to change the date to be display
            // So when they click
            // Both gridview will be regenerate using the new start and end date
            GenerateGvManpower();
            GenerateGvActual();
        }

        // Testing Purpose 
        // Can ignore
        private void display(List<DateTime> dateList)
        {
            foreach (DateTime date in dateList)
            {
                LtlMessage.Text += Convert.ToString(date);
            }
        }

        // Can Work
        private List<DateTime> GetDateList(DateTime start_date, DateTime end_date)
        {
            // Create a empty list for the date
            // The list can be taken as an array
            // Or can say is similar to array
            List<DateTime> dateList = new List<DateTime>();
            // Add individual date to the list
            for (DateTime date = start_date; date <= end_date; date = date.AddDays(1))
                dateList.Add(date);

            return dateList;
        }

        // This will get the list of the cluster name stored
        private List<string> GetClusterName()
        {
            List<string> clusterList = new List<string>();
            // Add the cluster name from the session when the admin logins
            clusterList.Add(Session["cluster"].ToString());
            return clusterList;
        }

        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            //Create a new DataTable.
            DataTable dtManpower = new DataTable();

            //Add columns to DataTable.
            foreach (TableCell cell in GvManpower.HeaderRow.Cells)
            {
                // cell.Text is to get the text in the gridview
                // dtManpower.Columns.Add(); is to add into the empty gridview
                dtManpower.Columns.Add(cell.Text);
            }

            //Loop through the GridView and copy rows.
            foreach (GridViewRow row in GvManpower.Rows)
            {
                // Add new rows
                dtManpower.Rows.Add();
                for (int i = 0; i < row.Cells.Count; i++)
                {
                    dtManpower.Rows[row.RowIndex][i] = row.Cells[i].Text;
                }
            }

            // get the current datatime
            string datetime = String.Format("csv_{0:yyyy-MM-dd_HHmmssff}", DateTime.Now);
            // create the new file useing the datetime as the name and stored it in the location stated in Server.MapPath()
            string fullFileName = Server.MapPath("~/Files/") + datetime + ".csv";

            // Method to write into csv
            ExportToCSV(dtManpower, fullFileName);

            // Below is the text display and the link for the admin to download after exported.

            LtlMsg.Text = "success: ";

            LnkCsv.Text = datetime + ".csv";
            LnkCsv.NavigateUrl = "~/Files/" + datetime + ".csv";
            LnkCsv.Target = "_blank";
        }

        // Code get from supervisor
        // Lazy to explain :P
        public static void ExportToCSV(DataTable dt, string fileName)
        {
            var sw = new StreamWriter(fileName, false);

            // Write the headers.
            int iColCount = dt.Columns.Count;
            for (int i = 0; i < iColCount; i++)
            {
                sw.Write(dt.Columns[i]);
                if (i < iColCount - 1) sw.Write(",");
            }
            sw.Write(sw.NewLine);

            // Write rows.
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 0; i < iColCount; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        if (dr[i].ToString().StartsWith("0"))
                        {
                            sw.Write(@"=""" + dr[i] + @"""");
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < iColCount - 1) sw.Write(",");
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }

        // Same as the BtnDownload_Click 
        // Cannot combine into one method as the Gridview refering is not the same one
        protected void BtnDownloadActual_Click(object sender, EventArgs e)
        {
            //Create a new DataTable.
            DataTable dtActual = new DataTable();

            //Add columns to DataTable.
            foreach (TableCell cell in GvActualpower.HeaderRow.Cells)
            {
                dtActual.Columns.Add(cell.Text);
            }

            //Loop through the GridView and copy rows.
            foreach (GridViewRow row in GvActualpower.Rows)
            {
                dtActual.Rows.Add();
                for (int i = 0; i < row.Cells.Count; i++)
                {
                    dtActual.Rows[row.RowIndex][i] = row.Cells[i].Text;
                }
            }

            string datetime = String.Format("csv_{0:yyyy-MM-dd_HHmmssff}", DateTime.Now);
            string fullFileName = Server.MapPath("~/Files/") + datetime + ".csv";

            ExportToCSV(dtActual, fullFileName);

            LtlMsgActual.Text = "success: ";

            LnkCsvActual.Text = datetime + ".csv";
            LnkCsvActual.NavigateUrl = "~/Files/" + datetime + ".csv";
            LnkCsvActual.Target = "_blank";
        }
    }
}