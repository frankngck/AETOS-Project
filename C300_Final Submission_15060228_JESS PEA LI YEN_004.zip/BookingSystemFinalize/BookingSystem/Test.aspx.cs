﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class Test : System.Web.UI.Page
    {
        decimal[] SAS = { 123, 345, 152, 351, 61, 152 };
        decimal[] SOI = { 69, 210, 134, 69, 65, 409 };
        decimal[] SHL = { 243, 91, 163, 71, 66, 126 };
        decimal[] SEG = { 73, 102, 183, 81, 67, 183 };
        decimal[] SMC = { 301, 65, 114, 151, 81, 172 };
        decimal[] STA = { 459, 97, 361, 271, 91, 82 };
        decimal[] SOH = { 83, 83, 273, 92, 151, 72 };
        string[] schNames = { "SAS", "SOI", "SHL", "SEG", "SMC", "STA", "SOH" };
        decimal[] yr2017 = { 152, 409, 126, 183, 172, 82, 72 };
        protected void Page_Load(object sender, EventArgs e)
        {
            //for (int i = 0; i < schNames.Length; i++)
            //{
            //    BarDatabase.Series.Add(new AjaxControlToolkit.BarChartSeries { Data = yr2017, Name = schNames[i] });
            //}
            BarDatabase.Series.Add(new AjaxControlToolkit.BarChartSeries { Data = SAS });
            BarDatabase.Series.Add(new AjaxControlToolkit.BarChartSeries { Data = SOI });
            BarDatabase.Series.Add(new AjaxControlToolkit.BarChartSeries { Data = SHL });
            BarDatabase.Series.Add(new AjaxControlToolkit.BarChartSeries { Data = SEG });
            BarDatabase.Series.Add(new AjaxControlToolkit.BarChartSeries { Data = SMC });
            BarDatabase.Series.Add(new AjaxControlToolkit.BarChartSeries { Data = STA });
            BarDatabase.Series.Add(new AjaxControlToolkit.BarChartSeries { Data = SOH });
        }
    }
}