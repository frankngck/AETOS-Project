﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.IO;

namespace BookingSystem
{
    public partial class SAdminViewUsers : System.Web.UI.Page
    {
        private string sql = @"SELECT * FROM Users U, User_has_Cluster UC, Cluster C, User_has_Tier UT, 
                                Tier T, Rank RK, Role RL, Status S
                            WHERE U.nric = UC.nric
                            AND UC.cluster_id = C.cluster_id
                            AND U.nric = UT.nric
                            AND UT.tier_id = C.tier_id
                            AND U.rank_id = RK.rank_id
							AND C.tier_id = T.tier_id
							AND U.role_id = RL.role_id
                            AND S.status_id = U.status_id
							AND role_name = 'USER'";

        protected void Page_Init(object sender, EventArgs e)
        {
            string sql = @"SELECT * FROM Status";
            DataTable db = DBUtl.GetTable(sql);

            // Code for last location
            DrpView.DataSource = db;
            DrpView.DataTextField = "status_name"; // the items to be displayed in the list items
            DrpView.DataValueField = "status_id"; // the id of the items displayed
            DrpView.DataBind();
            DrpView.Items.Insert(0, "All");
            DrpView.SelectedIndex = 1;
            GenerateGvUser();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateGvUser();
            }
        }

        protected void LnkDelete_Command(object sender, CommandEventArgs e)
        {
            string nric = e.CommandArgument.ToString();
            string get = sql + String.Format(" AND U.nric = '{0}'", nric);
            DataTable dt = DBUtl.GetTable(get);

            string update = "";
            if (dt.Rows[0]["status_name"].ToString().Equals("Inactive"))
                update = string.Format("UPDATE Users set status_id = 1 WHERE nric='{0}'", nric);
            else if (dt.Rows[0]["status_name"].ToString().Equals("Active"))
                update = string.Format("UPDATE Users set status_id = 2 WHERE nric='{0}'", nric);

            if (DBUtl.ExecSQL(update) == 1)
                LtlMessage.Text = "Status Updated Successfully ";
            else
                LtlMessage.Text = "Failed to Update status ";
            GenerateGvUser();
        }

        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            string service_id = TxtServiceID.Text.Trim();
            string search = string.Format(sql + " AND service_id='{0}'", service_id);
            GvUser.DataSource = DBUtl.GetTable(search);
            GvUser.DataBind();
        }

        protected void GvUser_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GvUser.PageIndex = e.NewPageIndex;
            if (ViewState["LastExpression"] == null)
            {
                GvUser.DataSource = DBUtl.GetTable(sql);
                return;
            }
            string sortExpression = ViewState["LastExpression"].ToString();
            string sortDirection = ViewState[sortExpression].ToString();
            if (DrpView.SelectedIndex == 0)
            {
                GvUser.DataSource = DBUtl.GetTable(sql + " ORDER BY {0} {1}", sortExpression, sortDirection);
                GvUser.DataBind();
                return;
            }
            GvUser.DataSource = DBUtl.GetTable(sql + " AND status_name = '{2}' ORDER BY {0} {1}",
                sortExpression, sortDirection, DrpView.SelectedItem.Text);
            GvUser.DataBind();
        }

        protected void GvUser_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortExpression = e.SortExpression;
            string sortDirection = GetSortDirection(sortExpression);
            if (DrpView.SelectedIndex == 0)
            {
                GvUser.DataSource = DBUtl.GetTable(sql + " ORDER BY {0} {1}", sortExpression, sortDirection);
                GvUser.DataBind();
                return;
            }
            GvUser.DataSource = DBUtl.GetTable(sql + " AND status_name = '{2}' ORDER BY {0} {1}",
                sortExpression, sortDirection, DrpView.SelectedItem.Text);
            GvUser.DataBind();
        }

        private string GetSortDirection(string sortExpression)
        {
            ViewState["LastExpression"] = sortExpression;
            if (ViewState[sortExpression] == null)
                ViewState[sortExpression] = "ASC";
            else if (ViewState[sortExpression].ToString().Equals("ASC"))
                ViewState[sortExpression] = "DESC";
            else
                ViewState[sortExpression] = "ASC";
            return ViewState[sortExpression].ToString();
        }

        protected void DrpView_SelectedIndexChanged(object sender, EventArgs e)
        {
            GenerateGvUser();
        }

        private void GenerateGvUser()
        {
            if (DrpView.SelectedIndex == 0)
            {
                GvUser.DataSource = DBUtl.GetTable(sql + "ORDER BY service_id");
                GvUser.DataBind();
                return;
            }
            GvUser.DataSource = DBUtl.GetTable(sql + String.Format("AND status_name = '{0}' ORDER BY service_id",
                DrpView.SelectedItem.Text));
            GvUser.DataBind();
        }

        protected void GvUser_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string nric = DataBinder.Eval(e.Row.DataItem, "nric").ToString(); // one of the other ways
                DataTable dt = DBUtl.GetTable(sql + String.Format(" AND U.nric = '{0}'", nric));

                LinkButton Lnb = e.Row.FindControl("LnkDelete") as LinkButton;
                if (dt.Rows[0]["status_name"].ToString().Equals("Active"))
                    Lnb.Text = "Deactivate";
                else
                    Lnb.Text = "Activate";
            }
        }

        private string CheckDrpValue(string sql)
        {
            if (DrpView.SelectedIndex != 0)
            {
                string sql1 = sql + String.Format(@" AND S.status_id = '{0}'", DrpView.SelectedItem.Value);
                return sql1;
            }
            return sql;
        }

       // protected void BtnDownload_Click(object sender, EventArgs e)
       // {
       //     string sql0 = @"SELECT service_id, rank_name, name, U.nric, cluster_name, contact_no, tier_no
       //                     FROM Users U, User_has_Cluster UC, Cluster C, User_has_Tier UT, 
       //                     Tier T, Rank RK, Role RL, Status S
       //                     WHERE U.nric = UC.nric
       //                     AND UC.cluster_id = C.cluster_id
       //                     AND U.nric = UT.nric
       //                     AND UT.tier_id = C.tier_id
       //                     AND U.rank_id = RK.rank_id
							//AND C.tier_id = T.tier_id
							//AND U.role_id = RL.role_id
       //                     AND S.status_id = U.status_id
							//AND role_name = 'USER'";
       //     string sqlAll = "SELECT * FROM Users";
       //     string sql1 = CheckDrpValue(sql0);

       //     DataTable dt = DBUtl.GetTable(sql1);
       //     //GvUser.DataSource = dt;
       //     //GvUser.DataBind();

       //     string datetime = String.Format("csv_{0:yyyy-MM-dd_HHmmssff}", DateTime.Now);
       //     string fullFileName = Server.MapPath("~/Files/") + datetime + ".csv";

       //     ExportToCSV(dt, fullFileName);

       //     LtlMsg.Text = "success: ";

       //     LnkCsv.Text = datetime + ".csv";
       //     LnkCsv.NavigateUrl = "~/Files/" + datetime + ".csv";
       //     LnkCsv.Target = "_blank";
       // }

       // public static void ExportToCSV(DataTable dt, string fileName)
       // {
       //     var sw = new StreamWriter(fileName, false);

       //     // Write the headers.
       //     int iColCount = dt.Columns.Count;
       //     for (int i = 0; i < iColCount; i++)
       //     {
       //         sw.Write(dt.Columns[i]);
       //         if (i < iColCount - 1) sw.Write(",");
       //     }
       //     sw.Write(sw.NewLine);

       //     // Write rows.
       //     foreach (DataRow dr in dt.Rows)
       //     {
       //         for (int i = 0; i < iColCount; i++)
       //         {
       //             if (!Convert.IsDBNull(dr[i]))
       //             {
       //                 if (dr[i].ToString().StartsWith("0"))
       //                 {
       //                     sw.Write(@"=""" + dr[i] + @"""");
       //                 }
       //                 else
       //                 {
       //                     sw.Write(dr[i].ToString());
       //                 }
       //             }
       //             if (i < iColCount - 1) sw.Write(",");
       //         }
       //         sw.Write(sw.NewLine);
       //     }
       //     sw.Close();
       // }
    }
}