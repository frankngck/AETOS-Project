﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class SAdminCreateAdmin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Code for Rank
                string sqlRank = @"SELECT * FROM Rank";
                DataTable dt = DBUtl.GetTable(sqlRank);
                DrpRank.DataSource = dt;
                DrpRank.DataTextField = "rank_name"; // the items to be displayed in the list items
                DrpRank.DataValueField = "rank_id"; // the id of the items displayed
                DrpRank.DataBind();

                // SQL Code for both last location and cluster
                string sqlCluster = @"SELECT * FROM Cluster";
                DataTable db = DBUtl.GetTable(sqlCluster);

                // Code for Cluster
                DrpCluster.DataSource = db;
                DrpCluster.DataTextField = "cluster_name"; // the items to be displayed in the list items
                DrpCluster.DataValueField = "cluster_id"; // the id of the items displayed
                DrpCluster.DataBind();
            }
        }

        protected void BtnCreate_Click(object sender, EventArgs e)
        {
            if (TxtPassword.Text.Trim().Equals(""))
                TxtPassword.Text = TxtNRIC.Text; // Set default password same as user id

            int role_id = 2; // Admin Role
            if (DrpCluster.SelectedItem.Equals("ALL"))
                role_id = 3; // Super Admin Role

            int tier_id = GetTierID(DrpCluster.SelectedValue);
            string sql = String.Format(@"INSERT INTO Users(nric, pwd, name, adhoc_event, last_updated_password, 
                                        rank_id, role_id) VALUES
                                        ('{0}', HASHBYTES('SHA1', '{1}'), '{2}', 1, '{3}', {4}, {5});
                                        INSERT INTO User_has_Cluster(nric, cluster_id) VALUES
                                        ('{6}', {7});
                                        INSERT INTO User_has_Tier(nric, tier_id) VALUES
                                        ('{8}', {9})", 
                                        TxtNRIC.Text, TxtPassword.Text, DBUtl.EscQuote(TxtFullName.Text),
                                        DateTime.Now.ToString(("MM/dd/yyyy HH:mm:ss")), 
                                        Convert.ToInt32(DrpRank.SelectedValue.ToString()), role_id,
                                        DBUtl.EscQuote(TxtNRIC.Text), Convert.ToInt32(DrpCluster.SelectedValue.ToString()),
                                        DBUtl.EscQuote(TxtNRIC.Text), tier_id);
            
            if (DBUtl.ExecSQL(sql) >= 1)
            {
                LtlMessage.Text = "Admin Created Successfully";
            } else
            {
                LtlMessage.Text = "Failed to create such Admin" + DBUtl.DB_Message;
            }
        }

        private int GetTierID(string selectedValue)
        {
            string sqlTier = String.Format(@"SELECT * FROM Cluster C, Tier T 
                                WHERE C.tier_id = T.tier_id
                                AND cluster_id = {0}", selectedValue);
            DataTable dt = DBUtl.GetTable(sqlTier);
            return Convert.ToInt32(dt.Rows[0]["tier_id"].ToString());
        }
    }
}