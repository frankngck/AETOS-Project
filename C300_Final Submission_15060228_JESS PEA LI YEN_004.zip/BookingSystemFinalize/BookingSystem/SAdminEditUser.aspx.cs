﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class SAdminEditUser : System.Web.UI.Page
    {
        // Previous Location
        private static string sqlAllLocation = @"SELECT * FROM Prev_Location";
        static DataTable dl = DBUtl.GetTable(sqlAllLocation);
        private static int locationCount = dl.Rows.Count;
        private int[] oldLocation = new int[locationCount];
        // Skills
        private static string sqlAllSkills = @"SELECT * FROM Skills";
        static DataTable ds = DBUtl.GetTable(sqlAllSkills);
        private static int skillCount = ds.Rows.Count;
        private int[] oldSkills = new int[skillCount];
        // Driving Class
        private static string sqlAllDriving = @"SELECT * FROM Driving_Class";
        static DataTable dd = DBUtl.GetTable(sqlAllDriving);
        private static int drivingCount = dd.Rows.Count;
        private int[] oldDriving = new int[drivingCount];

        protected void Page_Init(object sender, EventArgs e)
        {
            if (Request["nric"] == null)
            {
                Response.Redirect("SAdminViewUsers.aspx");
                return;
            }
            // Display Page 3 (Previous Location)
            string sqlCurrentLocation = string.Format(@"SELECT * FROM Users U, Prev_Location_has_User PLU, 
                                                        Prev_Location PL
                                                        WHERE U.nric = PLU.nric
                                                        AND PLU.prev_id = PL.prev_id
                                                        AND U.nric = '{0}'", Request["nric"].ToString());
            DataTable dtCurrentLocation = DBUtl.GetTable(sqlCurrentLocation);
            for (int i = 0; i < dtCurrentLocation.Rows.Count; i++)
            {
                oldLocation[Convert.ToInt32(dtCurrentLocation.Rows[i]["prev_id"].ToString()) - 1] = 1;
            }

            // Code for Previous Location CheckBoxList (Prevent adding duplicate)
            AddLocationCheckboxes(oldLocation, dtCurrentLocation);

            // Display Page 4 (Skills)
            string sqlCurrentSkills = string.Format(@"SELECT * FROM Users U, User_has_Skills US, Skills S
                                                        WHERE U.nric = US.nric
                                                        AND US.skill_id = S.skill_id
                                                        AND U.nric = '{0}'", Request["nric"].ToString());
            DataTable dtCurrentSkills = DBUtl.GetTable(sqlCurrentSkills);
            for (int i = 0; i < dtCurrentSkills.Rows.Count; i++)
            {
                oldSkills[Convert.ToInt32(dtCurrentSkills.Rows[i]["skill_id"].ToString()) - 1] = 1;
            }
            // Code for Skills CheckBoxList (Prevent adding duplicate)
            AddSkillCheckboxes(oldSkills);

            // Display Page 5 (Driving)
            string sqlCurrentDriving = string.Format(@"SELECT * FROM Users U, User_has_Driving_Class UDC, 
                                                        Driving_Class DC
                                                        WHERE U.nric = UDC.nric
                                                        AND UDC.driving_id = DC.driving_id
                                                        AND U.nric = '{0}'", Request["nric"].ToString());
            DataTable dtCurrentDriving = DBUtl.GetTable(sqlCurrentDriving);
            for (int i = 0; i < dtCurrentDriving.Rows.Count; i++)
            {
                oldDriving[Convert.ToInt32(dtCurrentDriving.Rows[i]["driving_id"].ToString()) - 1] = 1;
            }
            // Code for Driving CheckBoxList (Prevent adding duplicate)
            AddDrivingCheckboxes(oldDriving);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the nric is valid
                string sqlUser = String.Format("SELECT * FROM Users WHERE nric = '{0}'", Request["nric"].ToString());
                if (DBUtl.GetTable(sqlUser).Rows.Count == 0)
                {
                    Response.Redirect("SAdminViewPartTimers.aspx");
                    return;
                }
                // Display Page 1
                DataTable dtUser = DBUtl.GetTable(sqlUser);
                if (dtUser.Rows.Count == 0)
                    LtlMessage.Text = "User does not have any data";
                TxtFullName.Text = dtUser.Rows[0]["name"].ToString();
                char gender = Convert.ToChar(dtUser.Rows[0]["gender"].ToString());
                if (gender.Equals('F'))
                    LtlGender.Text = "Female";
                else if (gender.Equals('M'))
                    LtlGender.Text = "Male";
                TxtNRIC.Text = dtUser.Rows[0]["nric"].ToString();
                TxtDOB.Text = dtUser.Rows[0]["date_of_birth"].ToString();
                TxtNationality.Text = dtUser.Rows[0]["nationality"].ToString();
                TxtAddress.Text = dtUser.Rows[0]["address"].ToString();
                TxtEmail.Text = dtUser.Rows[0]["email"].ToString();
                TxtContactNO.Text = dtUser.Rows[0]["contact_no"].ToString();
                TxtMobileNO.Text = dtUser.Rows[0]["mobile_no"].ToString();

                // Display Page 2
                string sqlCompany = String.Format(@"SELECT * FROM User_CompanyInfo WHERE nric = '{0}'", Request["nric"].ToString());
                DataTable dtCompany = DBUtl.GetTable(sqlCompany);
                TxtJoinedDate.Text = dtCompany.Rows[0]["joined_date"].ToString();
                // Code for User's Rank
                string sqlRank = String.Format(@"SELECT * FROM Rank R, Users U 
                                                WHERE R.rank_id = U.rank_id 
                                                AND nric = '{0}'", Request["nric"].ToString());
                DataTable dtRank = DBUtl.GetTable(sqlRank);

                // Code for Rank
                string sqlAllRank = @"SELECT * FROM Rank";
                DataTable dtAllRank = DBUtl.GetTable(sqlAllRank);
                DrpRank.DataSource = dtAllRank;
                DrpRank.DataTextField = "rank_name"; // the items to be displayed in the list items
                DrpRank.DataValueField = "rank_id"; // the id of the items displayed
                DrpRank.DataBind();
                DrpRank.SelectedIndex = Convert.ToInt32(dtRank.Rows[0]["rank_id"].ToString()) - 1;

                TxtTrainComDate.Text = dtCompany.Rows[0]["train_date"].ToString();
                TxtSvcNo.Text = dtUser.Rows[0]["service_id"].ToString();

                // SQL Code for Location
                string sqlAllLocation = @"SELECT * FROM Prev_Location";
                DataTable dtLocation = DBUtl.GetTable(sqlAllLocation);

                // Get User Last Location
                string sqlLastLocation = String.Format(@"SELECT * FROM Users U, Prev_Location_has_User PLU, 
                                                        Prev_Location PL
                                                        WHERE U.nric = PLU.nric
                                                        AND PLU.prev_id = PL.prev_id
                                                        AND U.nric = '{0}'
                                                        ORDER BY prev_user_id DESC",
                                                        Request["nric"].ToString());
                DataTable dtLastLoca = DBUtl.GetTable(sqlLastLocation);
                // Code for last location
                if (dtLastLoca.Rows.Count >= 1)
                {
                    DrpLastLocation.DataSource = dtLocation;
                    DrpLastLocation.DataTextField = "loca_name"; // the items to be displayed in the list items
                    DrpLastLocation.DataValueField = "prev_id"; // the id of the items displayed
                    DrpLastLocation.DataBind();
                }
                if (dtLastLoca.Rows.Count > 1)
                    DrpLastLocation.SelectedIndex = Convert.ToInt32(dtLastLoca.Rows[0]["prev_id"].ToString()) - 1;
                else
                {
                    DrpLastLocation.Items.Insert(0, new ListItem("No Previous Location", "NULL"));
                    DrpLastLocation.SelectedIndex = 0;
                }

                // SQL Code for both cluster
                string sqlAllCluster = @"SELECT * FROM Cluster WHERE cluster_name != 'ALL'";
                DataTable dtCluster = DBUtl.GetTable(sqlAllCluster);

                // Get User Last Location
                string sqlCurrentCluster = String.Format(@"SELECT * FROM Users U, User_has_Cluster UC, Cluster C
                                                        WHERE U.nric = UC.nric
                                                        AND UC.cluster_id = C.cluster_id
                                                        AND U.nric = '{0}'
                                                        ORDER BY user_cluster_id DESC",
                                                        Request["nric"].ToString());
                DataTable dtUserCluster = DBUtl.GetTable(sqlCurrentCluster);
                // Code for Cluster
                DrpDeployment.DataSource = dtCluster;
                DrpDeployment.DataTextField = "cluster_name"; // the items to be displayed in the list items
                DrpDeployment.DataValueField = "cluster_id"; // the id of the items displayed
                DrpDeployment.DataBind();
                DrpDeployment.SelectedIndex = Convert.ToInt32(dtUserCluster.Rows[0]["cluster_id"].ToString()) - 1;

                string sqlAllTier = String.Format(@"SELECT * FROM Users U, User_has_Tier UT, Tier T 
                                    WHERE u.nric = UT.nric
                                    AND UT.tier_id = T.tier_id
                                    AND U.nric = '{0}'
                                    ORDER BY user_tier_id DESC", Request["nric"].ToString());
                DataTable dtTier = DBUtl.GetTable(sqlAllTier);
                // For tier
                if (dtTier.Rows[0]["tier_id"].ToString().Equals(RbTier1.Text))
                {
                    RbTier1.Checked = true;
                }
                else if (dtTier.Rows[0]["tier_id"].ToString().Equals(RbTier2.Text))
                {
                    RbTier2.Checked = true;
                }
                TxtRemarks.Text = dtCompany.Rows[0]["remarks"].ToString();
                // For Ad hoc event
                if (dtUser.Rows[0]["adhoc_event"].ToString().Equals("0"))
                    RbEventNo.Checked = true;
                else if (dtUser.Rows[0]["adhoc_event"].ToString().Equals("1"))
                    RbEventYes.Checked = true;
                return;
            }
        }

        private void AddSkillCheckboxes(int[] skills)
        {
            try
            {
                string sqlCheckBox = @"SELECT * FROM Skills";
                DataTable dt = DBUtl.GetTable(sqlCheckBox);

                // Looping the dt Database
                CheckBoxList cbList = new CheckBoxList();
                skillCount = dt.Rows.Count;
                for (int i = 0; i < skillCount; i++)
                {
                    ListItem item = new ListItem();
                    item.Text = dt.Rows[i]["skill_name"].ToString();
                    item.Value = dt.Rows[i]["skill_id"].ToString();
                    if (skills[i] == 1)
                    {
                        item.Selected = true;
                    }
                    ChlSkill.Items.Add(item);
                }
            }
            catch (Exception exp)
            {
                throw new Exception(exp.Message);
            }
        }

        private void AddLocationCheckboxes(int[] locations, DataTable dtCurrentSkills)
        {
            try
            {
                string sqlCheckBox = @"SELECT * FROM Prev_Location";
                DataTable dt = DBUtl.GetTable(sqlCheckBox);

                // Looping the dt Database
                CheckBoxList cbList = new CheckBoxList();
                locationCount = dt.Rows.Count;
                for (int i = 0; i < locationCount; i++)
                {
                    ListItem item = new ListItem();
                    item.Text = dt.Rows[i]["loca_name"].ToString();
                    item.Value = dt.Rows[i]["prev_id"].ToString();
                    if (locations[i] == 1)
                    {
                        item.Selected = true;
                    }
                    ChlLocation.Items.Add(item);
                }
                Session["Location"] = ChlLocation;
            }
            catch (Exception exp)
            {
                throw new Exception(exp.Message);
            }
        }

        private void AddDrivingCheckboxes(int[] driving)
        {
            try
            {
                int count = 0;
                string sqlCheckBox = @"SELECT * FROM Driving_Class";
                DataTable dt = DBUtl.GetTable(sqlCheckBox);

                // Looping the dt Database
                CheckBoxList cbList = new CheckBoxList();
                drivingCount = dt.Rows.Count;
                for (int i = 0; i < drivingCount; i++)
                {
                    ListItem item = new ListItem();
                    item.Text = dt.Rows[i]["driving_name"].ToString();
                    item.Value = dt.Rows[i]["driving_id"].ToString();
                    if (driving[i] == 1)
                    {
                        item.Selected = true;
                        count++;
                    }
                    ChlDriving.Items.Add(item);
                }
                if (count > 0)
                {
                    RbDriveYes.Checked = true;
                }
                else
                {
                    RbDriveNo.Checked = true;
                }
            }
            catch (Exception exp)
            {
                throw new Exception(exp.Message);
            }
        }

        protected void SavePersonal(object sender, EventArgs e)
        {
            string dob = Convert.ToDateTime(TxtDOB.Text).ToString("yyyy-MM-dd");

            string sqlUser = String.Format(@"UPDATE Users
                                            SET name = '{1}', date_of_birth = '{2}', 
                                            nationality = '{3}', address = '{4}', email = '{5}', 
                                            contact_no = {6}, mobile_no = {7}
                                            WHERE nric = '{0}';
                                            UPDATE User_CompanyInfo
                                            SET last_updated = '{8}'
                                            WHERE nric = '{0}'",
                                            TxtNRIC.Text, DBUtl.EscQuote(TxtFullName.Text), dob,
                                            TxtNationality.Text, TxtAddress.Text, TxtEmail.Text,
                                            TxtContactNO.Text, TxtMobileNO.Text, DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"));
            if (DBUtl.ExecSQL(sqlUser) >= 1)
                LtlMessage.Text = "User Updated Successfully";
            else
                LtlMessage.Text = "Failed to update User" + DBUtl.DB_Message;
        }

        protected void SaveCompany(object sender, EventArgs e)
        {
            string joined_date = Convert.ToDateTime(TxtJoinedDate.Text).ToString("yyyy-MM-dd");
            string train_date = Convert.ToDateTime(TxtTrainComDate.Text).ToString("yyyy-MM-dd");
            string sqlUser = String.Format(@"UPDATE User_CompanyInfo
                                            SET joined_date = '{1}', train_date = '{2}', remarks = '{3}', 
                                            last_updated = '{4}'
                                            WHERE nric = '{0}'",
                                            TxtNRIC.Text, joined_date, train_date, TxtRemarks.Text,
                                            DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"));
            if (DBUtl.ExecSQL(sqlUser) == 1)
                LtlMessage.Text = "User Updated Successfully";
            else
                LtlMessage.Text = "Failed to update User" + DBUtl.DB_Message;
        }

        protected void SavePrevLocation(object sender, EventArgs e)
        {
            int[] check_id;
            if (!GetListID(ChlLocation, TableType.PREV_LOCATION, out check_id))
            {
                LtlMessage.Text = "No Previous Location Selected" + display(check_id);
                return;
            }

            int[] updatedArray;
            if (!CompareTwoArray(oldLocation, check_id, out updatedArray))
            {
                LtlMessage.Text += "No New Previous Location Added";
                return;
            }
            // Get Location SQL
            string sqlLocation;
            if (!GetLocationSQL(updatedArray, out sqlLocation))
                return;

            if (DBUtl.ExecSQL(sqlLocation) == 1)
                LtlMessage.Text = "User Updated Successfully";
            else
                LtlMessage.Text = "Failed to update User" + DBUtl.DB_Message;
        }

        private string display(int[] array)
        {
            string sql = "";
            for (int i = 0; i < array.Length; i++)
            {
                sql += array[i].ToString();
            }
            return sql;
        }

        private string display(string[] array)
        {
            string sql = "";
            for (int i = 0; i < array.Length; i++)
            {
                sql += array[i];
            }
            return sql;
        }

        private Boolean CompareTwoArray(int[] oldArray, int[] newArray, out int[] updatedArray)
        {
            updatedArray = new int[oldArray.Length];
            for (int i = 0; i < newArray.Length; i++)
            {
                if (oldArray[i] != newArray[i])
                {
                    updatedArray[i] = 1;
                }
            }
            if (updatedArray == null)
                return false;
            return true;
        }

        private int[] GetSkillsID(CheckBoxList ChlPanel)
        {
            string skill = "";
            foreach (ListItem item in ChlPanel.Items)
            {
                if (item.Selected == true)
                {
                    skill += item.Value + ",";
                }
            }
            skill = skill.TrimEnd(',');
            int[] skill_id = new int[skillCount];
            if (!skill.Equals(""))
            {
                string[] skills = skill.Split(',');
                for (int i = 0; i < skills.Length; i++)
                {
                    if (!skills[i].Equals(""))
                    {
                        skill_id[i] = Convert.ToInt32(skills[i]);
                    }
                }
                return skill_id;
            }
            return skill_id;
        }

        private Boolean GetListID(CheckBoxList ChlPanel, TableType table, out int[] check_id)
        {
            check_id = new int[ChlPanel.Items.Count];
            CheckBoxList ChlLocation = (CheckBoxList)Session["Location"];
            string query = "";
            CheckBoxList Cbx = ChlPanel;
            foreach (ListItem e in Cbx.Items)
            {
                LtlMessage.Text += e.Value;
                if (e.Selected)
                {
                    LtlMessage.Text += e.Value;
                    query += e.Value + ",";
                }
            }
            for (int i = 0; i < ChlLocation.Items.Count; i++)
            {
                if (ChlLocation.Items[i].Selected == true)
                {
                    query += ChlLocation.Items[i].Value + ",";
                }
            }
            foreach (ListItem item in ChlPanel.Items)
            {
                if (item.Selected == true)
                {
                    query += Convert.ToString(item.Value) + ",";
                }
            }
            if (!query.Equals(""))
                return false;
            query = query.TrimEnd(',');
            string[] list = query.Split(',');
            LtlMessage.Text += display(list);
            for (int i = 0; i < list.Length; i++)
            {
                check_id[Convert.ToInt32(list[i])] = 1;
            }
            return true;
        }

        private Boolean GetLocationSQL(int[] Locations, out string newSql)
        {
            string sqlInsert = @"INSERT INTO Previous_Location_has_User(nric, prev_id) VALUES";
            for (int i = 0; i > Locations.Length; i++)
            {
                if (Locations != null)
                    sqlInsert += String.Format(" ('{0}', '{1}'),", TxtNRIC.Text, Locations[i]);
            }
            newSql = "";
            if (TrimEnd(sqlInsert, out newSql))
                return true;
            return false;
        }

        private Boolean GetSkillSQL(int[] skills, out string newSql)
        {
            string sqlInsert = @"INSERT INTO User_has_Skills(nric, skill_id) VALUES";
            for (int i = 0; i > skills.Length; i++)
            {
                if (skills != null)
                    sqlInsert += String.Format(" ('{0}', '{1}'),", TxtNRIC.Text, skills[i]);
            }
            newSql = "";
            if (TrimEnd(sqlInsert, out newSql))
                return true;
            return false;
        }

        private Boolean TrimEnd(string sqlInsert, out string newSql)
        {
            newSql = "";
            if (sqlInsert.EndsWith(","))
            {
                newSql = sqlInsert.TrimEnd(',') + ";";
                return true;
            }
            return false;
        }
    }
}