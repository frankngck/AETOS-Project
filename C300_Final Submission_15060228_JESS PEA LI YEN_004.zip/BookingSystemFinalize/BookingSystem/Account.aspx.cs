﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class Account : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = @"SELECT * FROM Users WHERE nric = '{0}'";

                string select = string.Format(sql, Session["nric"].ToString());
                DataTable dt = DBUtl.GetTable(select);

                if (dt.Rows.Count == 1)
                {
                    TxtName.Text = dt.Rows[0]["name"].ToString();
                    LtlDepartment.Text = Session["cluster"].ToString();
                    LtlNRIC.Text = dt.Rows[0]["nric"].ToString();
                    if (dt.Rows[0]["gender"].ToString().Equals("M"))
                    {
                        LtlGender.Text = "Male";
                    }
                    else if (dt.Rows[0]["gender"].ToString().Equals("F"))
                    {
                        LtlGender.Text = "Female";
                    }
                    LtlNationality.Text = dt.Rows[0]["nationality"].ToString();
                    TxtMobile.Text = dt.Rows[0]["mobile_no"].ToString();
                    TxtHP.Text = dt.Rows[0]["contact_no"].ToString();
                    TxtEmail.Text = dt.Rows[0]["email"].ToString();
                }
                string sql1 = @"SELECT * FROM User_Emergency WHERE nric ='{0}'";

                string emergency = string.Format(sql1, Session["nric"].ToString());
                DataTable db = DBUtl.GetTable(emergency);
                if (db.Rows.Count == 1)
                {
                    TxtEmergName.Text = db.Rows[0]["emergency_name"].ToString();
                    TxtEmergContact.Text = db.Rows[0]["emergency_contact"].ToString();
                }
            }
        }

        protected void BtnSave_Click(object sender, EventArgs e)
        {
            string sql = String.Format(@"UPDATE Users SET name = '{1}', mobile_no='{2}', contact_no='{3}' 
                                        WHERE nric = '{0}'", Session["nric"].ToString(), TxtName.Text, TxtMobile.Text, TxtHP.Text);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Information Updated Successfully";
            else
                LtlMessage.Text = "Failed to Create " + sql + DBUtl.DB_Message;
        }

        protected void BtnUpdated_Click(object sender, EventArgs e)
        {
            string update = "";
            string select = String.Format(@"SELECT * FROM User_Emergency WHERE nric = '{0}'", Session["nric"].ToString());
            if (DBUtl.GetTable(select).Rows.Count == 0)
            {
                update = String.Format(@"INSERT INTO User_Emergency(emergency_name,emergency_contact,nric) VALUES 
                                        ('{0}', '{1}', '{2}')", TxtEmergName.Text, TxtEmergContact.Text, Session["nric"].ToString());
            }
            else
            {
                update = String.Format(@"UPDATE User_Emergency SET emergency_name = '{1}', emergency_contact='{2}'
                                        WHERE nric = '{0}'", Session["nric"].ToString(), TxtEmergName.Text, TxtEmergContact.Text);
            }

            if (DBUtl.ExecSQL(update) == 1)
                LtlMessage.Text = "Information Updated Successfully ";
            else
                LtlMessage.Text = "Failed to Update " + DBUtl.DB_Message;
        }
    }
}