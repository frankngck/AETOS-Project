﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;

namespace BookingSystem
{
    public partial class SAdminViewReports : System.Web.UI.Page
    {
        private string sql = @"SELECT cluster_name FROM Cluster C WHERE cluster_name != 'ALL'";

        // Ok
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                TxtStartDate.Text = DateTime.Now.ToString();
                TxtEndDate.Text = DateTime.Now.AddDays(7.0).ToString();
                GenerateGvManpower();
                GenerateGvActual();
            }
            //display(GetDateList(Convert.ToDateTime(TxtStartDate.Text), Convert.ToDateTime(TxtEndDate.Text)));
        }

        private void GenerateGvManpower()
        {
            List<DateTime> dateList = GetDateList(Convert.ToDateTime(TxtStartDate.Text), Convert.ToDateTime(TxtEndDate.Text));
            List<string> clusterList = GetClusterName();

            DataTable dt = new DataTable();
            DataRow dr = null;
            dt.Columns.Add(new DataColumn("Cluster Name", typeof(string)));
            foreach (DateTime date in dateList)
            {
                dt.Columns.Add(new DataColumn(date.ToString("dd-MM-yyyy"), typeof(string)));
            }

            foreach (string cluster_name in clusterList)
            {
                dr = dt.NewRow();
                dr["Cluster Name"] = cluster_name;
                foreach (DateTime date in dateList)
                {
                    string get = @"SELECT COUNT(clusterbooking_id) AS '{0}'
                            FROM Cluster C, Sub_Cluster SB, Sub_Cluster_has_Shift SCS, Cluster_Booking CB
                            WHERE C.cluster_id = SB.cluster_id
                            AND SCS.sub_cluster_id = SB.sub_cluster_id 
                            AND SCS.sub_shift_id = CB.sub_shift_id
                            AND booking_date = '{1}'
                            AND cluster_name = '{2}';";

                    string header = date.ToString("dd-MM-yyyy");
                    string datafield = date.ToString("yyyy-MM-dd");
                    DataTable db = DBUtl.GetTable(String.Format(get, header, datafield, cluster_name));

                    dr[date.ToString("dd-MM-yyyy")] = db.Rows[0][0].ToString();
                }
                dt.Rows.Add(dr);
            }
            //Store the DataTable in ViewState
            ViewState["CurrentTable"] = dt;
            GvManpower.DataSource = dt;
            GvManpower.DataBind();
            //ChangeTextToHyperLink();
        }

        private void GenerateGvActual()
        {
            List<DateTime> dateList = GetDateList(Convert.ToDateTime(TxtStartDate.Text), Convert.ToDateTime(TxtEndDate.Text));
            List<string> clusterList = GetClusterName();

            DataTable dt = new DataTable();
            DataRow dr = null;
            dt.Columns.Add(new DataColumn("Cluster Name", typeof(string)));
            foreach (DateTime date in dateList)
            {
                dt.Columns.Add(new DataColumn(date.ToString("dd-MM-yyyy"), typeof(string)));
            }

            foreach (string cluster_name in clusterList)
            {
                dr = dt.NewRow();
                dr["Cluster Name"] = cluster_name;
                foreach (DateTime date in dateList)
                {
                    string get = @"SELECT COUNT(attendance_id) AS '{0}'
                            FROM Cluster C, Sub_Cluster SB, Sub_Cluster_has_Shift SCS, Cluster_Booking CB, Attendance A
                            WHERE C.cluster_id = SB.cluster_id
                            AND SCS.sub_cluster_id = SB.sub_cluster_id 
                            AND SCS.sub_shift_id = CB.sub_shift_id
                            AND CB.clusterbooking_id = A.clusterbooking_id
                            AND booking_date = '{1}'
                            AND cluster_name = '{2}'
                            AND attendance_status = 1;";

                    string header = date.ToString("dd-MM-yyyy");
                    string datafield = date.ToString("yyyy-MM-dd");
                    DataTable db = DBUtl.GetTable(String.Format(get, header, datafield, cluster_name));

                    dr[date.ToString("dd-MM-yyyy")] = db.Rows[0][0].ToString();
                }
                dt.Rows.Add(dr);
            }
            //Store the DataTable in ViewState
            ViewState["CurrentTable"] = dt;
            GvActualpower.DataSource = dt;
            GvActualpower.DataBind();
        }

        // Ok
        protected void BtnDisplay_Click(object sender, EventArgs e)
        {
            GenerateGvManpower();
            GenerateGvActual();
        }

        // Testing Purpose
        private void display(List<DateTime> dateList)
        {
            foreach (DateTime date in dateList)
            {
                LtlMessage.Text += "'" + Convert.ToString(date.ToString("yyyy-MM-dd")) + "'";
            }
        }

        // Can Work
        private List<DateTime> GetDateList(DateTime start_date, DateTime end_date)
        {
            List<DateTime> dateList = new List<DateTime>();
            for (DateTime date = start_date; date <= end_date; date = date.AddDays(1))
                dateList.Add(date);
            return dateList;
        }

        private List<string> GetClusterName()
        {
            List<string> clusterList = new List<string>();
            DataTable dt = DBUtl.GetTable(sql);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                clusterList.Add(dt.Rows[i]["cluster_name"].ToString());
            }
            return clusterList;
        }

        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            //Create a new DataTable.
            DataTable dtManpower = new DataTable();

            //Add columns to DataTable.
            foreach (TableCell cell in GvManpower.HeaderRow.Cells)
            {
                dtManpower.Columns.Add(cell.Text);
            }

            //Loop through the GridView and copy rows.
            foreach (GridViewRow row in GvManpower.Rows)
            {
                dtManpower.Rows.Add();
                for (int i = 0; i < row.Cells.Count; i++)
                {
                    dtManpower.Rows[row.RowIndex][i] = row.Cells[i].Text;
                }
            }

            string datetime = String.Format("csv_{0:yyyy-MM-dd_HHmmssff}", DateTime.Now);
            string fullFileName = Server.MapPath("~/Files/") + datetime + ".csv";

            ExportToCSV(dtManpower, fullFileName);

            LtlMsg.Text = "success: ";

            LnkCsv.Text = datetime + ".csv";
            LnkCsv.NavigateUrl = "~/Files/" + datetime + ".csv";
            LnkCsv.Target = "_blank";
        }

        public static void ExportToCSV(DataTable dt, string fileName)
        {
            var sw = new StreamWriter(fileName, false);

            // Write the headers.
            int iColCount = dt.Columns.Count;
            for (int i = 0; i < iColCount; i++)
            {
                sw.Write(dt.Columns[i]);
                if (i < iColCount - 1) sw.Write(",");
            }
            sw.Write(sw.NewLine);

            // Write rows.
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 0; i < iColCount; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        if (dr[i].ToString().StartsWith("0"))
                        {
                            sw.Write(@"=""" + dr[i] + @"""");
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < iColCount - 1) sw.Write(",");
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }

        protected void BtnDownloadActual_Click(object sender, EventArgs e)
        {
            //Create a new DataTable.
            DataTable dtActual = new DataTable();

            //Add columns to DataTable.
            foreach (TableCell cell in GvActualpower.HeaderRow.Cells)
            {
                dtActual.Columns.Add(cell.Text);
            }

            //Loop through the GridView and copy rows.
            foreach (GridViewRow row in GvActualpower.Rows)
            {
                dtActual.Rows.Add();
                for (int i = 0; i < row.Cells.Count; i++)
                {
                    dtActual.Rows[row.RowIndex][i] = row.Cells[i].Text;
                }
            }

            string datetime = String.Format("csv_{0:yyyy-MM-dd_HHmmssff}", DateTime.Now);
            string fullFileName = Server.MapPath("~/Files/") + datetime + ".csv";

            ExportToCSV(dtActual, fullFileName);

            LtlMsgActual.Text = "success: ";

            LnkCsvActual.Text = datetime + ".csv";
            LnkCsvActual.NavigateUrl = "~/Files/" + datetime + ".csv";
            LnkCsvActual.Target = "_blank";
        }

        //protected void GvManpower_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        string cluster_name = e.Row.Cells[0].Text;
        //        LtlMsg.Text += cluster_name + " " + e.Row.Cells[1].Text;
        //        for (int col = 1; col <= GvManpower.Columns.Count; col++)
        //        {
        //            string date = e.Row.Cells[col].Text;
        //            LtlMsg.Text += date;
        //            HyperLink Link = new HyperLink();
        //            Link.ID = cluster_name + date;
        //            e.Row.Cells[col].Controls.Add(Link);
        //        }

        //        //GridView gridView = (GridView)sender;
        //        //int colCount = gridView.Columns.Count;
        //        //for (int col = 1; col <= colCount; col++)
        //        //{
        //        //    // Get the value in the hyperlink column.
        //        //    string HyperLinkValue = e.Row.Cells[col].Text;
        //        //    // Insert a real hyperlink into Cells[1] using HyperLinkValue.
        //        //    HyperLink myLink = new HyperLink();
        //        //    LtlMessage.Text += e.Row.Cells[0].Text + e.Row.Cells[col].Text;
        //        //    myLink.NavigateUrl = String.Format(@"SAdminHome.aspx?cluster='{0}'&date='{1}')",
        //        //                                            e.Row.Cells[0].Text, e.Row.Cells[col].Text);
        //        //    myLink.Text = HyperLinkValue;
        //        //    // then add the control to the cell.
        //        //    e.Row.Cells[1].Controls.Add(myLink);
        //        //}
        //    }

        //}
    }
}