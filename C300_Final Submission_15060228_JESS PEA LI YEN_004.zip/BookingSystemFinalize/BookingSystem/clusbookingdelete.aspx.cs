﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
namespace BookingSystem
{
    public partial class clusbookingdelete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string clusbookingid = Request.QueryString["clusterbooking_id"].ToString();
            string sql = @"SELECT * FROM Cluster_booking WHERE clusterbooking_id='{0}'";
            DataTable ds = DBUtl.GetTable(sql, clusbookingid);
            DateTime  date = DateTime.Parse(ds.Rows[0]["booking_date"].ToString());
            if (date < DateTime.Now.Date.AddDays(3))
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myal‌​ert", "alert('Booking must be cancelled 3 days in advance ');", true);
                Response.Redirect("viewbooking.aspx");
            }
            else
            {

                string sql1 = "DELETE FROM Cluster_booking  WHERE clusterbooking_id={0}";
                sql = String.Format(sql1, clusbookingid);



                if (DBUtl.ExecSQL(sql) == 1)

                {
                    Literal1.Text = "Booking Cancelled.";
                }
                else
                {
                    Literal1.Text = "Unsuccessful Cancellation ";
                }
            }



           
        }
    }
}