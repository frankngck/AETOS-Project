﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookingSystem
{
    public partial class SAdminViewAdmin : System.Web.UI.Page
    {
        private string sql = @"SELECT * FROM Users U, User_has_Cluster UC, Cluster C, User_has_Tier UT, Tier T, Rank RK, Role RL
                            WHERE U.nric = UC.nric
                            AND UC.cluster_id = C.cluster_id
                            AND U.nric = UT.nric
                            AND UT.tier_id = C.tier_id
                            AND U.rank_id = RK.rank_id
							AND C.tier_id = T.tier_id
							AND U.role_id = RL.role_id
                            AND role_name = 'ADMIN'";

        protected void Page_Load(object sender, EventArgs e)
        {
            GvAdmin.DataSource = DBUtl.GetTable(sql);
            GvAdmin.DataBind();
        }

        protected void LnkDelete_Command(object sender, CommandEventArgs e)
        {
            string delete = string.Format("DELETE FROM Users WHERE nric='{0}'", e.CommandArgument.ToString());
            if (DBUtl.ExecSQL(delete) == 1)
            {
                LtlMessage.Text = "Deleted Successfully";
                GvAdmin.DataSource = DBUtl.GetTable(sql);
                GvAdmin.DataBind();
            }
            else
            {
                LtlMessage.Text = "Failed to Delete";
                GvAdmin.DataSource = DBUtl.GetTable(sql);
                GvAdmin.DataBind();
            }
        }

        protected void GvAdmin_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GvAdmin.PageIndex = e.NewPageIndex;
            if (ViewState["LastExpression"] == null)
            {
                GvAdmin.DataSource = DBUtl.GetTable(sql);
            }
            else
            {
                string sortExpression = ViewState["LastExpression"].ToString();
                string sortDirection = ViewState[sortExpression].ToString(); ;
                GvAdmin.DataSource = DBUtl.GetTable(sql + " ORDER BY {0} {1}", sortExpression, sortDirection);
            }
            GvAdmin.DataBind();
        }

        protected void GvAdmin_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortExpression = e.SortExpression;
            string sortDirection = GetSortDirection(sortExpression);
            GvAdmin.DataSource = DBUtl.GetTable(sql + " ORDER BY {0} {1}", sortExpression, sortDirection);
            GvAdmin.DataBind();
        }

        private string GetSortDirection(string sortExpression)
        {
            ViewState["LastExpression"] = sortExpression;
            if (ViewState[sortExpression] == null)
                ViewState[sortExpression] = "ASC";
            else if (ViewState[sortExpression].ToString().Equals("ASC"))
                ViewState[sortExpression] = "DESC";
            else
                ViewState[sortExpression] = "ASC";
            return ViewState[sortExpression].ToString();
        }
    }
}