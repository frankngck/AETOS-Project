﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class SAdminCreateUser : System.Web.UI.Page
    {
        private int skillCount;
        private int locationCount;
        private int drivingCount;

        protected void Page_Init(object sender, EventArgs e)
        {
            // Code for Skills CheckBoxList
            AddSkillCheckboxes();
            // Code for Previous Location CheckBoxList
            AddLocationCheckboxes();
            // Code for Driving Class CheckBoxList
            AddDrivingCheckboxes();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Code for Rank
                string sqlRank = @"SELECT * FROM Rank";
                DataTable dt = DBUtl.GetTable(sqlRank);
                DrpRank.DataSource = dt;
                DrpRank.DataTextField = "rank_name"; // the items to be displayed in the list items
                DrpRank.DataValueField = "rank_id"; // the id of the items displayed
                DrpRank.DataBind();

                // SQL Code for both last location and cluster
                string sqlCluster = @"SELECT * FROM Cluster C, Tier T 
                                    WHERE C.tier_id = T.tier_id
                                    AND tier_no = 1 AND cluster_name != 'ALL'";
                DataTable db = DBUtl.GetTable(sqlCluster);

                // Code for Cluster
                DrpDeployment.DataSource = db;
                DrpDeployment.DataTextField = "cluster_name"; // the items to be displayed in the list items
                DrpDeployment.DataValueField = "cluster_id"; // the id of the items displayed
                DrpDeployment.DataBind();

                return;
            }
            string sqlTier = @"SELECT * FROM Cluster C, Tier T 
                                    WHERE C.tier_id = T.tier_id
                                    AND tier_no = {0}";
            if (RbTier1.Checked == true)
            {
                DataTable db = DBUtl.GetTable(String.Format(sqlTier, 1));
                DrpDeployment.DataSource = db;
                DrpDeployment.DataTextField = "cluster_name"; // the items to be displayed in the list items
                DrpDeployment.DataValueField = "cluster_id"; // the id of the items displayed
                DrpDeployment.DataBind();
            }
            else if (RbTier2.Checked == true)
            {
                DataTable db = DBUtl.GetTable(String.Format(sqlTier, 2));
                DrpDeployment.DataSource = db;
                DrpDeployment.DataTextField = "cluster_name"; // the items to be displayed in the list items
                DrpDeployment.DataValueField = "cluster_id"; // the id of the items displayed
                DrpDeployment.DataBind();
            }
            if (RbDriveNo.Checked)
                ChlDriving.Visible = false;
            else if (RbDriveYes.Checked)
                ChlDriving.Visible = true;
        }

        private void AddSkillCheckboxes()
        {
            try
            {
                string sqlCheckBox = @"SELECT * FROM Skills";
                DataTable dt = DBUtl.GetTable(sqlCheckBox);

                // Looping the dt Database
                CheckBoxList cbList = new CheckBoxList();
                skillCount = dt.Rows.Count;
                for (int i = 0; i < skillCount; i++)
                {
                    ListItem item = new ListItem();
                    item.Text = dt.Rows[i]["skill_name"].ToString();
                    item.Value = dt.Rows[i]["skill_id"].ToString();
                    ChlSkill.Items.Add(item);
                }
            }
            catch (Exception exp)
            {
                throw new Exception(exp.Message);
            }
        }

        private void AddLocationCheckboxes()
        {
            try
            {
                string sqlCheckBox = @"SELECT * FROM Prev_Location";
                DataTable dt = DBUtl.GetTable(sqlCheckBox);

                // Looping the dt Database
                CheckBoxList cbList = new CheckBoxList();
                locationCount = dt.Rows.Count;
                for (int i = 0; i < locationCount; i++)
                {
                    ListItem item = new ListItem();
                    item.Text = dt.Rows[i]["loca_name"].ToString();
                    item.Value = dt.Rows[i]["prev_id"].ToString();
                    ChlLocation.Items.Add(item);
                }
            }
            catch (Exception exp)
            {
                throw new Exception(exp.Message);
            }
        }

        private void AddDrivingCheckboxes()
        {
            try
            {
                string sqlCheckBox = @"SELECT * FROM Driving_Class";
                DataTable dt = DBUtl.GetTable(sqlCheckBox);

                // Looping the dt Database
                CheckBoxList cbList = new CheckBoxList();
                drivingCount = dt.Rows.Count;
                for (int i = 0; i < drivingCount; i++)
                {
                    ListItem item = new ListItem();
                    item.Text = dt.Rows[i]["driving_name"].ToString();
                    item.Value = dt.Rows[i]["driving_id"].ToString();
                    ChlDriving.Items.Add(item);
                }
            }
            catch (Exception exp)
            {
                throw new Exception(exp.Message);
            }
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            if (!IsValid)
            {
                return;
            }
            string sqlCheck = String.Format(@"SELECT * FROM Users WHERE service_id = '{0}' OR nric = '{1}'",
                                                    TxtSvcNo.Text, TxtNRIC.Text);
            if (DBUtl.GetTable(sqlCheck).Rows.Count >= 1)
            {
                LtlMessage.Text = "Duplicate Service NO. and/or NRIC";
                return;
            }
            // Remember to change back the date to YYYY-MM-DD
            string joined_date = Convert.ToDateTime(TxtJoinedDate.Text).ToString("yyyy-MM-dd");
            string train_date = Convert.ToDateTime(TxtTrainComDate.Text).ToString("yyyy-MM-dd");
            string dob = Convert.ToDateTime(TxtDOB.Text).ToString("yyyy-MM-dd");
            char gender = 'M';
            if (RbFemale.Checked == true)
                gender = 'F';

            int ad_event = 1;
            if (RbEventNo.Checked == true)
                ad_event = 0;

            int tier_id = 2;
            if (RbTier2.Checked)
                tier_id = 3;

            string sql = @"INSERT INTO Users(nric, pwd, name, service_id, email, contact_no, mobile_no, address, 
                            gender, date_of_birth, nationality, adhoc_event, last_updated_password, rank_id, role_id, 
                            status_id) 
                            VALUES('{0}', HASHBYTES('SHA1', '{1}'), '{2}', '{3}', '{4}', {5}, {6}, '{7}', 
                            '{8}', '{9}', '{10}', {11}, '{12}', {13}, 1, 1);
                            INSERT INTO User_CompanyInfo(joined_date, train_date, remarks, last_updated, nric) 
                            VALUES('{13}', '{14}', '{15}', '{16}', '{17}');
                            INSERT INTO User_has_Tier(nric, tier_id) VALUES('{18}', {19}); 
                            INSERT INTO User_has_Cluster(nric, cluster_id) VALUES('{20}', {21});";
            sql = String.Format(sql, TxtNRIC.Text, TxtNRIC.Text, DBUtl.EscQuote(TxtFullName.Text), TxtSvcNo.Text,
                                TxtEmail.Text, TxtContactNO.Text, TxtMobileNO.Text, TxtAddress.Text, gender, dob,
                                TxtNationality.Text, ad_event, DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"),
                                Convert.ToInt32(DrpRank.SelectedValue.ToString()),
                                joined_date, train_date, TxtRemarks.Text, DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"),
                                TxtNRIC.Text, TxtNRIC.Text, tier_id, TxtNRIC.Text, Convert.ToInt32(DrpDeployment.SelectedValue));
            // Get skills SQL
            string sqlSkill = "";
            string[] skill_id;
            if (GetCheckBoxID(ChlSkill, TableType.SKILL, out skill_id))
                if (GetSkillSQL(skill_id, out sqlSkill))
                    sql += sqlSkill;

            // Get Locaition SQL
            string sqlLocation = "";
            string[] location_id;
            if (GetCheckBoxID(ChlLocation, TableType.PREV_LOCATION, out location_id))
                if (GetLocationSQL(location_id, out sqlLocation))
                    sql += sqlLocation;

            // Get Driving SQL
            string sqlDriving = "";
            string[] driving_id;
            if (GetCheckBoxID(ChlDriving, TableType.DRIVING, out driving_id))
                if (GetDrivingSQL(driving_id, out sqlDriving))
                    sql += sqlDriving;

            sql = sql.TrimEnd(';');
            if (DBUtl.ExecSQL(sql) >= 1)
                LtlMessage.Text = "User Created Successfully ";
            else
                LtlMessage.Text = "Failed to create User " + sql + DBUtl.DB_Message;
        }

        private string[] getNewArray(TableType table)
        {
            if (table.Equals(TableType.SKILL))
            {
                string[] skills = new string[skillCount];
                return skills;
            }
            else if (table.Equals(TableType.SKILL))
            {
                string[] location = new string[locationCount];
                return location;
            }
            else
            {
                string[] driving = new string[drivingCount];
                return driving;
            }
        }

        private Boolean GetCheckBoxID(CheckBoxList ChlPanel, TableType table, out string[] id)
        {
            id = getNewArray(table);
            string skill = "";
            foreach (ListItem item in ChlPanel.Items)
            {
                if (item.Selected == true)
                    skill += item.Value + " ";
            }
            if (skill.Equals(""))
                return false;
            id = null;
            skill = skill.TrimEnd();
            id = skill.Split();
            return true;
        }

        private void display(string[] index)
        {
            for (int i = 0; i < index.Length; i++)
            {
                LtlMessage.Text += index[i];
            }
        }

        private Boolean GetSkillSQL(string[] skills, out string newSql)
        {
            string sqlSkill = @"INSERT INTO User_has_Skills(nric, skill_id) VALUES";
            for (int i = 0; i < skills.Length; i++)
            {
                sqlSkill += String.Format(" ('{0}', '{1}'),", TxtNRIC.Text, skills[i]);
            }
            newSql = "";
            if (TrimEnd(sqlSkill, out newSql))
                return true;
            return false;
        }

        private Boolean GetLocationSQL(string[] Locations, out string newSql)
        {
            string sqlLocation = @"INSERT INTO Prev_Location_has_User(nric, prev_id) VALUES";
            for (int i = 0; i < Locations.Length; i++)
            {
                sqlLocation += String.Format(" ('{0}', '{1}'),", TxtNRIC.Text, Locations[i]);
            }
            newSql = "";
            if (TrimEnd(sqlLocation, out newSql))
                return true;
            return false;
        }

        private Boolean GetDrivingSQL(string[] Drivings, out string newSql)
        {
            string sqlDriving = @"INSERT INTO User_has_Driving_Class(nric, driving_id) VALUES";
            for (int i = 0; i < Drivings.Length; i++)
            {
                sqlDriving += String.Format(" ('{0}', '{1}'),", TxtNRIC.Text, Drivings[i]);
            }
            newSql = "";
            if (TrimEnd(sqlDriving, out newSql))
                return true;
            return false;
        }

        private Boolean TrimEnd(string sqlInsert, out string newSql)
        {
            newSql = "";
            if (sqlInsert.EndsWith(","))
            {
                newSql = sqlInsert.TrimEnd(',') + ";";
                return true;
            }
            return false;
        }
    }
}