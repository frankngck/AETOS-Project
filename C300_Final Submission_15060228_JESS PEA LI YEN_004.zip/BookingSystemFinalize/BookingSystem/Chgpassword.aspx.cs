﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
namespace BookingSystem
{
    public partial class Chgpassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnSave_Click(object sender, EventArgs e)
        {

            string nric = Session["nric"].ToString();
            string sql = @"SELECT * FROM Users WHERE nric='{0}' AND pwd = HASHBYTES('SHA1', '{1}')";

            DataTable ds = DBUtl.GetTable(sql, nric, TxtPW1.Text);
            if (IsValid)
            {
                if (ds.Rows.Count == 1)
                {
                    string sql2 = @"UPDATE Users SET pwd = HASHBYTES('SHA1', '{0}') WHERE nric = '{1}'";
                    int count = DBUtl.ExecSQL(sql2, TextBox2, nric);

                    if (count == 1)
                    {

                        LtlMessage.Text = "Password Changed Successfully!";
                        Literal1.Text = "";
                    }
                    else
                    {
                        LtlMessage.Text = "Password Changed Unsuccessfully!";
                        Literal1.Text = "";
                    }
                }
                else
                {
                    Literal1.Text = "Current Password Incorrect!";
                    LtlMessage.Text = "";
                }
            }
            else
            {
                Literal1.Text = "";
                LtlMessage.Text = "";
            }

        }

    }
}
