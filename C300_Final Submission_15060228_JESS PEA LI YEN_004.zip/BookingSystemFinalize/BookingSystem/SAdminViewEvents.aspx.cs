﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class SAdminViewEvents : System.Web.UI.Page
    {
        private const string sql = @"SELECT * FROM Events E, Event_Venue EV, Event_shift_master ESM
                                            WHERE ESM.event_id = E.event_id
                                            AND ESM.venue_id = EV.venue_id";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateGvEvents();
            }
        }

        private void GenerateGvEvents()
        {
            DataTable ds = DBUtl.GetTable(sql);
            GvEvents.DataSource = ds;
            GvEvents.DataBind();
        }

        protected void GvEvents_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GvEvents.PageIndex = e.NewPageIndex;
            if (ViewState["LastExpression"] == null)
            {
                GvEvents.DataSource = DBUtl.GetTable(sql);
            }
            else
            {
                string sortExpression = ViewState["LastExpression"].ToString();
                string sortDirection = ViewState[sortExpression].ToString(); ;
                GvEvents.DataSource = DBUtl.GetTable(sql + " ORDER BY {0} {1}", sortExpression, sortDirection);
            }
            GvEvents.DataBind();
        }

        protected void GvEvents_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortExpression = e.SortExpression;
            string sortDirection = GetSortDirection(sortExpression);
            GvEvents.DataSource = DBUtl.GetTable(sql + " ORDER BY {0} {1}", sortExpression, sortDirection);
            GvEvents.DataBind();
        }

        private string GetSortDirection(string sortExpression)
        {
            ViewState["LastExpression"] = sortExpression;
            if (ViewState[sortExpression] == null)
                ViewState[sortExpression] = "ASC";
            else if (ViewState[sortExpression].ToString().Equals("ASC"))
                ViewState[sortExpression] = "DESC";
            else
                ViewState[sortExpression] = "ASC";
            return ViewState[sortExpression].ToString();
        }

        protected void GvEvents_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GvEvents.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Event_shift_master WHERE event_date_shift = '{0}'", id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateGvEvents();
        }

        protected void GvEvents_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvEvents.EditIndex = -1;
            GenerateGvEvents();
        }

        protected void GvEvents_RowEditing(object sender, GridViewEditEventArgs e)
        {
            LtlMessage.Text = "";
            GvEvents.EditIndex = e.NewEditIndex;
            GenerateGvEvents();
        }

        protected void GvEvents_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvEvents.Rows[e.RowIndex];
            string event_id = (GvEvents.Rows[e.RowIndex].FindControl("DrpEvent") as DropDownList).SelectedItem.Value;
            string venue_id = (GvEvents.Rows[e.RowIndex].FindControl("DrpVenue") as DropDownList).SelectedItem.Value;
            TextBox TxtStartDate = (TextBox)row.FindControl("TxtStartDate");
            TextBox TxtEndDate = (TextBox)row.FindControl("TxtEndDate");
            TextBox TxtShift = (TextBox)row.FindControl("TxtShift");
            string id = GvEvents.DataKeys[e.RowIndex].Value.ToString();
            // Have to change to MM first else the records stored is switch between the Month and the Date
            string start_date = Convert.ToDateTime(TxtStartDate.Text).ToString("MM-dd-yyyy hh:mm:ss tt");
            string end_date = Convert.ToDateTime(TxtEndDate.Text).ToString("MM-dd-yyyy hh:mm:ss tt");
            string sql = String.Format(@"UPDATE Event_shift_master SET event_id = '{1}', venue_id = '{2}', event_start_date = '{3}',
                                        event_end_date = '{4}', shift_desc = '{5}'
                                        WHERE event_date_shift = '{0}'", id, event_id, venue_id, start_date, end_date, TxtShift.Text);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvEvents.EditIndex = -1;
            GenerateGvEvents();
        }

        private int GetEventNamePos(DataTable dt)
        {
            return Convert.ToInt32(dt.Rows[0]["event_id"].ToString());
        }

        private int GetVenueNamePos(DataTable dt)
        {
            return Convert.ToInt32(dt.Rows[0]["venue_id"].ToString());
        }

        private DropDownList GetDrpEventName(DataTable dbJoin, int index)
        {
            DropDownList DrpEvent = new DropDownList();
            // Code for Event
            DrpEvent.DataSource = dbJoin;
            DrpEvent.DataTextField = "event_name"; // the items to be displayed in the list items
            DrpEvent.DataValueField = "event_id"; // the id of the items displayed
            DrpEvent.DataBind();
            DrpEvent.SelectedIndex = index;
            return DrpEvent;
        }

        private DropDownList GetDrpVenueName(DataTable dbJoin, int index)
        {
            string sqlName = sql + String.Format(@" AND event_date_shift = '{0}'", index);
            DataTable dt = DBUtl.GetTable(sqlName);
            DropDownList DrpVenue = new DropDownList();
            // Code for Venue
            DrpVenue.DataSource = dbJoin;
            DrpVenue.DataTextField = "event_venue"; // the items to be displayed in the list items
            DrpVenue.DataValueField = "venue_id"; // the id of the items displayed
            DrpVenue.DataBind();
            DrpVenue.SelectedIndex = index;
            return DrpVenue;
        }

        protected void GvEvents_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && GvEvents.EditIndex == e.Row.RowIndex)
            {
                // Get Event ID and Venue ID
                string id = GvEvents.DataKeys[e.Row.RowIndex].Values[0].ToString();
                string sqlName = sql + String.Format(@" AND event_date_shift = '{0}'", id);
                DataTable dt = DBUtl.GetTable(sqlName);
                int event_id = GetEventNamePos(dt);
                int venue_id = GetVenueNamePos(dt);

                DropDownList DrpEvent = (DropDownList)e.Row.FindControl("DrpEvent");
                DataTable db = DBUtl.GetTable("SELECT * FROM Events");
                DrpEvent.DataSource = db;
                DrpEvent.DataTextField = "event_name";
                DrpEvent.DataValueField = "event_id";
                DrpEvent.DataBind();
                DrpEvent.SelectedIndex = event_id - 1;

                DropDownList DrpVenue = (DropDownList)e.Row.FindControl("DrpVenue");
                DataTable ds = DBUtl.GetTable("SELECT * FROM Event_venue");
                DrpVenue.DataSource = ds;
                DrpVenue.DataTextField = "event_venue";
                DrpVenue.DataValueField = "venue_id";
                DrpVenue.DataBind();
                DrpVenue.SelectedIndex = venue_id - 1;
            }
        }

        protected void BtnCreateNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("SAdminCreateEvent.aspx");
        }
    }
}