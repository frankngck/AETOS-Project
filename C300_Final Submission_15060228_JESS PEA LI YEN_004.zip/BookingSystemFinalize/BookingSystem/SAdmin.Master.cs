﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookingSystem
{
    public partial class SAdmin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["nric"] == null)
            {
                Response.Redirect("Login.aspx?redirect=" + Page.AppRelativeVirtualPath);
                return;
            }

            if (Session["role"].Equals(RoleType.SUPERADMIN))
            {
                LnkLogin.Visible = false;
                LtlUserName.Text = "Welcome, " + Session["name"].ToString() + ", " + Session["cluster"].ToString();
                return;
            }
            Response.Redirect("NotAuthorised.aspx");
        }
    }
}