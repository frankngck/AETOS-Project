﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookingSystem
{
    public partial class SAdminAddAnnouncement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TxtStartDate.Text = DateTime.Now.ToString();
        }

        protected void BtnCreate_Click(object sender, EventArgs e)
        {
            if (TxtAnnounceName.Text.Trim().Equals("") && TxtDescription.Text.Trim().Equals("") && TxtEndDate.Text.Trim().Equals(""))
            {
                return;
            }

            // Have to change to MM first else the records stored is switch between the Month and the Date
            string start_date = Convert.ToDateTime(TxtStartDate.Text).ToString("MM-dd-yyyy hh:mm:ss tt");
            string end_date = Convert.ToDateTime(TxtEndDate.Text).ToString("MM-dd-yyyy hh:mm:ss tt");
            string sql = String.Format(@"INSERT INTO Announcement(announ_title, announ_descrip, start_date, end_date)
                                        VALUES('{0}', '{1}', '{2}', '{3}') ", TxtAnnounceName.Text, TxtDescription.Text,
                                        start_date, end_date);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Announcement Created Successfully ";
            else
                LtlMessage.Text = "Failed to Create " + sql + DBUtl.DB_Message;
        }
    }
}