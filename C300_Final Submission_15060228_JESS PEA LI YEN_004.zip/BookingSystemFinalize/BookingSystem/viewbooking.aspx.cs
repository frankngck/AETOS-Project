﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Script.Services;
using System.Web.Services;


namespace BookingSystem
{
    public partial class viewbooking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {



            object objPrevPageObject = Session["nric"];
         

            string sql1 = @"SELECT * FROM Events_booking eb,Events e ,Event_venue ev ,Event_shift_master esm
 WHERE eb.event_date_shift = esm.event_date_shift AND ev.venue_id = esm.venue_id AND esm.event_id = e.event_id AND nric = '{0}'";
    GvPerformance.DataSource = DBUtl.GetTable(sql1, objPrevPageObject);

       GvPerformance.DataBind();


            string sql = @"SELECT * FROM Cluster_booking cb,sub_cluster_has_shift cs,sub_cluster s,shifts ss,shift_master sm WHERE cb.sub_shift_id=cs.sub_shift_id
AND s.sub_cluster_id=cs.sub_cluster_id AND ss.shift_code=cs.shift_code AND sm.shift_id=ss.shift_id AND nric='{0}' ORDER BY booking_date DESC";
            GridView1.DataSource = DBUtl.GetTable(sql, objPrevPageObject);
            GridView1.DataBind();

        }


        [WebMethod]
        [ScriptMethod]
        public static string GetHtml(string contextKey)
        {
            // A little pause to mimic a latent call
            System.Threading.Thread.Sleep(250);

            var value = (contextKey == "U")
                ? DateTime.UtcNow.ToString()
                : String.Format("{0:" + contextKey + "}", DateTime.Now);
            return String.Format("<span style='font-family:courier new;font-weight:bold;'>{0}</span>", value);
        }




        protected void deletion_Command(object sender, CommandEventArgs e)
        {
            string sql = @"SELECT FORMAT(event_start_date,'yyyy-MM-dd') as date FROM Events_booking eb,Event_shift_master esm 
WHERE eb.event_date_shift=esm.event_date_shift AND event_booking_id={0}";
            DataTable ds = DBUtl.GetTable(sql, e.CommandArgument);
            DateTime date = DateTime.Parse(ds.Rows[0]["date"].ToString());
            if (date < DateTime.Now.Date.AddDays(3))
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myal‌​ert", "alert('Booking can only be cancel 3 days in advance');", true);
            }
            else
            {
                string url = String.Format("eventdelete.aspx?event_booking_id={0}", e.CommandArgument);
                Response.Redirect(url);
            }

        }

        protected void Edit_Command(object sender, CommandEventArgs e)
        {
            string url = String.Format("eventedit.aspx?event_booking_id={0}", e.CommandArgument);
            Response.Redirect(url);
        }


        protected void Editt_Command(object sender, CommandEventArgs e)
        {


                string url = String.Format("clusbookingedit.aspx?clusterbooking_id={0}", e.CommandArgument);
                Response.Redirect(url);

            
        }

        protected void deletionn_Command(object sender, CommandEventArgs e)
        {
            string sql = @"SELECT * FROM Cluster_booking WHERE clusterbooking_id='{0}'";
            DataTable ds = DBUtl.GetTable(sql, e.CommandArgument);
            DateTime date = DateTime.Parse(ds.Rows[0]["booking_date"].ToString());
            if (date < DateTime.Now.Date.AddDays(3))
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myal‌​ert", "alert('Booking can only be cancel 3 days in advance');", true);

            }
            else
            {
                string url = String.Format("clusbookingdelete.aspx?clusterbooking_id={0}", e.CommandArgument);
                Response.Redirect(url);


            }
         

        }



      

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            object objPrevPageObject = Session["nric"];




            string sql = @"SELECT * FROM Cluster_booking cb,sub_cluster_has_shift cs,sub_cluster s,shifts ss,shift_master sm WHERE cb.sub_shift_id=cs.sub_shift_id
AND s.sub_cluster_id=cs.sub_cluster_id AND ss.shift_code=cs.shift_code AND sm.shift_id=ss.shift_id AND nric='{0}' ORDER BY booking_date DESC";
            GridView1.DataSource = DBUtl.GetTable(sql, objPrevPageObject);
            GridView1.DataBind();
        }






        protected void GvGrade_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            object objPrevPageObject = Session["nric"];


        

            string sql = @"SELECT * FROM Cluster_booking cb,sub_cluster_has_shift cs,sub_cluster s,shifts ss,shift_master sm WHERE cb.sub_shift_id=cs.sub_shift_id
AND s.sub_cluster_id=cs.sub_cluster_id AND ss.shift_code=cs.shift_code AND sm.shift_id=ss.shift_id AND nric='{0}' ORDER BY booking_date DESC";
            GridView1.DataSource = DBUtl.GetTable(sql, objPrevPageObject);
            GridView1.DataBind();

        }

       

        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            string nric = Session["nric"].ToString();
            string date = Date1.Text.Trim();
            string sql = @"SELECT * FROM Cluster_booking cb,sub_cluster_has_shift cs,sub_cluster s,shifts ss,shift_master sm WHERE cb.sub_shift_id=cs.sub_shift_id
AND s.sub_cluster_id=cs.sub_cluster_id AND ss.shift_code=cs.shift_code AND sm.shift_id=ss.shift_id AND nric='{1}' AND booking_date='{0}' ORDER BY booking_date DESC";
            string select = string.Format(sql, date, nric);
            GridView1.DataSource = DBUtl.GetTable(select);
            GridView1.DataBind();
        }
    }
}
//   <asp:Button runat="server" ID="Button2"  CssClass="submit" Width="35px" OnClick="Button1_Click1"  />