﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Data.OleDb;
using System.Security.Cryptography;

namespace BookingSystem
{
    public partial class SAdminUploadUsers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GvUser.DataSource = DBUtl.GetTable("SELECT TOP 1 * FROM Users WHERE role_id = 1 ORDER BY service_id;");
            GvUser.DataBind();
        }

        private string GetConnectionString()
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings["conString"].ConnectionString;
        }

        private void CreateDatabaseTable(DataTable dt, string tableName)
        {
            string sqlQuery = string.Empty;
            string sqlDBType = string.Empty;
            string dataType = string.Empty;
            int maxLength = 0;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat(string.Format("CREATE TABLE {0} (", tableName));

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                dataType = dt.Columns[i].DataType.ToString();
                if (dataType == "System.Int32")
                {
                    sqlDBType = "INT";
                }
                else if (dataType == "System.String")
                {
                    sqlDBType = "NVARCHAR";
                    maxLength = dt.Columns[i].MaxLength;
                }

                if (maxLength > 0)
                {
                    sb.AppendFormat(string.Format(" {0} {1} ({2}), ", dt.Columns[i].ColumnName, sqlDBType, maxLength));
                }
                else
                {
                    sb.AppendFormat(string.Format(" {0} {1}, ", dt.Columns[i].ColumnName, sqlDBType));
                }
            }

            sqlQuery = sb.ToString();
            sqlQuery = sqlQuery.Trim().TrimEnd(',');
            sqlQuery = sqlQuery + " )";

            if (DBUtl.ExecSQL(sqlQuery) >= 1)
                LtlMsg.Text = "User's data Inserted Successfully";
            else
                LtlMsg.Text = "Failed to insert data " + DBUtl.DB_Message + sqlQuery;
        }

        private void LoadDataToDatabase(string tableName, string fileFullPath, string delimeter)
        {
            string sqlQuery = string.Empty;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat(string.Format("BULK INSERT {0} ", tableName));
            sb.AppendFormat(string.Format(" FROM '{0}'", fileFullPath));
            sb.AppendFormat(string.Format(" WITH ( FIELDTERMINATOR = '{0}' , ROWTERMINATOR = '\n' )", delimeter));

            string a = @"BULK INSERT {0} FROM '{1}' [ WITH   
    (   
   [ [ , ] BATCHSIZE = batch_size ]   
   [ [ , ] CHECK_CONSTRAINTS ]   
   [ [ , ] CODEPAGE = { 'ACP' | 'OEM' | 'RAW' | 'code_page' } ]   
   [ [ , ] DATAFILETYPE =   
      { 'char' | 'native'| 'widechar' | 'widenative' } ]   
   [ [ , ] DATASOURCE = 'data_source_name' ]
   [ [ , ] ERRORFILE = 'file_name' ]
   [ [ , ] ERRORFILE_DATASOURCE = 'data_source_name' ]   
   [ [ , ] FIRSTROW = first_row ]   
   [ [ , ] FIRE_TRIGGERS ]   
   [ [ , ] FORMATFILE_DATASOURCE = 'data_source_name' ]
   [ [ , ] KEEPIDENTITY ]   
   [ [ , ] KEEPNULLS ]   
   [ [ , ] KILOBYTES_PER_BATCH = kilobytes_per_batch ]   
   [ [ , ] LASTROW = last_row ]   
   [ [ , ] MAXERRORS = max_errors ]   
   [ [ , ] ORDER ( { column [ ASC | DESC ] } [ ,...n ] ) ]   
   [ [ , ] ROWS_PER_BATCH = rows_per_batch ]   
   [ [ , ] ROWTERMINATOR = 'row_terminator' ]   
   [ [ , ] TABLOCK ] ";

            sqlQuery = sb.ToString();

            if (DBUtl.ExecSQL(sqlQuery) >= 1)
                LtlMsg.Text = "User's data Inserted Successfully";
            else
                LtlMsg.Text = "Failed to insert data " + DBUtl.DB_Message + sqlQuery;
        }

        private byte[] ConvertStringToBytes(string pwdString, DataTable dt)
        {
            string[] strings = pwdString.Split(',');
            byte[] bytes = strings.Select(s => byte.Parse(s)).ToArray();
            SHA1 sha = new SHA1CryptoServiceProvider();
            byte[] password = sha.ComputeHash(bytes);
            return password;
        }

        private string GetPwdString(DataTable dt)
        {
            string pwd = "";
            foreach (DataRow row in dt.Rows)
            {
                pwd += row["pwd"].ToString() + ",";
            }
            if (pwd.EndsWith(","))
            {
                pwd.TrimEnd(',');
            }
            return pwd;
        }

        //protected void BTNImport_Click(object sender, EventArgs e)
        //{
        //    const string CSV_CONNECTIONSTRING = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"{0}\";Extended Properties=\"text;HDR=YES;FMT=Delimited\"";

        //    string csvPath = Server.MapPath("~/Files/");
        //    string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
        //    FileUpload1.SaveAs(Path.Combine(csvPath, fileName));
        //    string File_Name = string.Empty;

        //    string ConString = ConfigurationManager.ConnectionStrings["dbstr"].ConnectionString;

        //    File_Name = fileName;
        //    DataTable dt = new DataTable();
        //    using (OleDbConnection con = new OleDbConnection(string.Format(CSV_CONNECTIONSTRING, csvPath)))
        //    {
        //        using (OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + File_Name + "]", con))
        //        {
        //            da.Fill(dt);
        //        }
        //    }
        //    byte[] fileData = ConvertStringToBytes(GetPwdString(dt), dt);
        //    //Convert byte array into a string
        //    string strFileData = System.Text.Encoding.UTF8.GetString(fileData, 0, fileData.Length);
        //    //Convert string into a MemoryStream
        //    Stream stream = new MemoryStream(fileData);

        //    //Parse the stream
        //    using (TextFieldParser parser = new TextFieldParser(stream))
        //    {
        //        parser.TextFieldType = FieldType.Delimited;
        //        parser.TextFieldType = FieldType.Delimited;
        //        parser.SetDelimiters(",");
        //        int rowCount = 1, colCount = 1;
        //        string strInsert = "";
        //        string Field1 = "", Field2 = "", Field3 = "", Field4 = "";
        //        while (!parser.EndOfData)
        //        {
        //            //Processing row
        //            string[] row = parser.ReadFields();
        //            if (rowCount > 1) //Skip header row
        //            {
        //                foreach (string field in row)
        //                {
        //                    if (colCount == 1)
        //                    {
        //                        Field1 = field;
        //                    }
        //                    else if (colCount == 2)
        //                    {
        //                        Field2 = field;
        //                    }
        //                    else if (colCount == 3)
        //                    {
        //                        Field3 = field;
        //                    }
        //                    else if (colCount == 4)
        //                    {
        //                        Field4 = field;
        //                    }
        //                    colCount++;
        //                }
        //                colCount = 1;

        //                strInsert = @"INSERT INTO Import_Table (Field1, Field2, Field3, Field4) 
        //                                VALUES ('" + Field1 + "', '" + Field2 + "', '" + Field3 + "', '" + Field4 + "')";
        //                //Execute this insert query
        //            }
        //            rowCount++;
        //        }
        //    }
        //}

        protected void Upload(object sender, System.EventArgs e)
        {
            const string CSV_CONNECTIONSTRING = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"{0}\";Extended Properties=\"text;HDR=YES;FMT=Delimited\"";

            string csvPath = Server.MapPath("~/Files/");
            string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
            FileUpload1.SaveAs(Path.Combine(csvPath, fileName));
            string File_Name = string.Empty;

            string ConString = ConfigurationManager.ConnectionStrings["dbstr"].ConnectionString;

            try
            {
                File_Name = fileName;
                DataTable dt = new DataTable();
                Byte[] fileData = ConvertStringToBytes(GetPwdString(dt), dt);

                using (OleDbConnection con = new OleDbConnection(string.Format(CSV_CONNECTIONSTRING, csvPath)))
                {
                    using (OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + File_Name + "]", con))
                    {
                        da.Fill(dt);
                    }
                }
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ConString))
                {
                    bulkCopy.ColumnMappings.Add(0, "nric");
                    bulkCopy.ColumnMappings.Add(1, "pwd");
                    bulkCopy.ColumnMappings.Add(2, "name");
                    bulkCopy.ColumnMappings.Add(3, "service_id");
                    bulkCopy.ColumnMappings.Add(4, "email");
                    bulkCopy.ColumnMappings.Add(5, "contact_no");
                    bulkCopy.ColumnMappings.Add(6, "mobile_no");
                    bulkCopy.ColumnMappings.Add(7, "address");
                    bulkCopy.ColumnMappings.Add(8, "gender");
                    bulkCopy.ColumnMappings.Add(9, "date_of_birth");
                    bulkCopy.ColumnMappings.Add(10, "nationality");
                    bulkCopy.ColumnMappings.Add(11, "adhoc_event");
                    bulkCopy.ColumnMappings.Add(12, "last_updated_password");
                    bulkCopy.ColumnMappings.Add(13, "rank_id");
                    bulkCopy.ColumnMappings.Add(14, "role_id");
                    bulkCopy.ColumnMappings.Add(15, "status_id");

                    bulkCopy.DestinationTableName = "Users";
                    bulkCopy.BatchSize = dt.Rows.Count;
                    bulkCopy.WriteToServer(dt);
                    bulkCopy.Close();
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            LtlMsg.Text = "<br><b>Uploaded Successfully";

            //for (int i = 0; i < AllFiles.Length; i++)
            //{

            //}
        }

        protected void Upload2(object sender, System.EventArgs e)
        {
            const string CSV_CONNECTIONSTRING = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"{0}\";Extended Properties=\"text;HDR=YES;FMT=Delimited\"";

            string csvPath = Server.MapPath("~/Files/");
            string fileName = Path.GetFileName(FileUpload2.PostedFile.FileName);
            FileUpload2.SaveAs(Path.Combine(csvPath, fileName));
            string File_Name = string.Empty;

            string ConString = ConfigurationManager.ConnectionStrings["dbstr"].ConnectionString;

            try
            {
                File_Name = fileName;
                DataTable dt = new DataTable();
                Byte[] fileData = ConvertStringToBytes(GetPwdString(dt), dt);

                using (OleDbConnection con = new OleDbConnection(string.Format(CSV_CONNECTIONSTRING, csvPath)))
                {
                    using (OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + File_Name + "]", con))
                    {
                        da.Fill(dt);
                    }
                }
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ConString))
                {
                    bulkCopy.ColumnMappings.Add(0, "joined_date");
                    bulkCopy.ColumnMappings.Add(1, "train_date");
                    bulkCopy.ColumnMappings.Add(2, "remarks");
                    bulkCopy.ColumnMappings.Add(3, "date_created");
                    bulkCopy.ColumnMappings.Add(4, "last_updated");
                    bulkCopy.ColumnMappings.Add(5, "nric");

                    bulkCopy.DestinationTableName = "User_CompanyInfo";
                    bulkCopy.BatchSize = dt.Rows.Count;
                    bulkCopy.WriteToServer(dt);
                    bulkCopy.Close();
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            Literal1.Text = "<br><b>Uploaded Successfully";

            //for (int i = 0; i < AllFiles.Length; i++)
            //{

            //}
        }

        //protected void Upload(object sender, EventArgs e)
        //{
        //    //Upload and save the file
        //    string csvPath = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
        //    FileUpload1.SaveAs(csvPath);

        //    DataTable dt = new DataTable();
        //    dt.Columns.AddRange(new DataColumn[16] { new DataColumn("nric", typeof(string)),
        //    new DataColumn("pwd", typeof(Base64FormattingOptions)),
        //    new DataColumn("name",typeof(string)),
        //    new DataColumn("service_id",typeof(string)),
        //    new DataColumn("email",typeof(string)),
        //    new DataColumn("contact_no",typeof(int)),
        //    new DataColumn("mobile_no",typeof(int)),
        //    new DataColumn("address",typeof(string)),
        //    new DataColumn("gender",typeof(char)),
        //    new DataColumn("date_of_birth",typeof(DateTime)),
        //    new DataColumn("nationality",typeof(string)),
        //    new DataColumn("adhoc_event",typeof(Boolean)),
        //    new DataColumn("last_updated_password",typeof(DateTime)),
        //    new DataColumn("rank_id",typeof(int)),
        //    new DataColumn("role_id",typeof(int)),
        //    new DataColumn("status_id",typeof(int)) });

        //    string csvData = File.ReadAllText(csvPath);
        //    foreach (string row in csvData.Split('\n'))
        //    {
        //        if (!string.IsNullOrEmpty(row))
        //        {
        //            dt.Rows.Add();
        //            int col = 0;
        //            foreach (string cell in row.Split(','))
        //            {
        //                if (col == 1) // pwd column
        //                {
        //                    dt.Rows[dt.Rows.Count - 1][col] = String.Format("HASHBYTES('SHA1', '{0}')", cell);
        //                }
        //                else if (col == 12)
        //                {
        //                    DateTime now = DateTime.Now;
        //                    dt.Rows[dt.Rows.Count - 1][col] = now;
        //                }
        //                else
        //                {
        //                    dt.Rows[dt.Rows.Count - 1][col] = cell;
        //                }
        //                LtlMsg.Text += cell + "</br>";
        //                col++;
        //            }
        //        }
        //    }

        //    string consString = ConfigurationManager.ConnectionStrings["dbstr"].ConnectionString;
        //    using (SqlConnection con = new SqlConnection(consString))
        //    {
        //        using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
        //        {
        //            //Set the database table name
        //            sqlBulkCopy.DestinationTableName = "dbo.Users";
        //            con.Open();
        //            sqlBulkCopy.WriteToServer(dt);
        //            con.Close();
        //        }
        //    }
        //}
    }
}