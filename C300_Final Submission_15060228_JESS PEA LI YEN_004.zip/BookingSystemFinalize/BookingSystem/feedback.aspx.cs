﻿using System;

using System.Collections;

using System.Configuration;

using System.Data;

using System.Linq;

using System.Web;

using System.Web.Security;

using System.Web.UI;

using System.Web.UI.HtmlControls;

using System.Web.UI.WebControls;

using System.Web.UI.WebControls.WebParts;

using System.Xml.Linq;

using System.Net.Mail;

using System.Net;

using System.Drawing;

using System.IO;




namespace BookingSystem
{
    public partial class feedback : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SendEmail(object sender, EventArgs e)
        {
            string nric = Session["nric"].ToString();
            string cluster = Session["cluster"].ToString();
            string sql= @"SELECT * FROM Users WHERE nric='{0}'";
            sql = String.Format(sql, nric);
            DataTable dtt = DBUtl.GetTable(sql);


            using (MailMessage mm = new MailMessage("angelinetanch@gmail.com", "angelinetanch@gmail.com"))
            {
                
                mm.Subject = txtSubject.Text;
                mm.Body = "<h2>" + "Enquiry :" + "</h2>" + "<br><br>" +
                "Name: " + dtt.Rows[0]["name"].ToString()   + "<br>" +
                "NRIC: " + nric+ "<br>" +
                "Department: " + cluster + "<br>" +

                "Contact Number: " + dtt.Rows[0]["contact_no"].ToString() + "<br>" +

               "Subject: " + txtSubject.Text + "<br>" +
               

                "Email : " + TextBox1.Text.Trim() + "<br>" +

              "InQuiry: " + txtInquiry.Text.Trim() + "<br>" +

               "Thank You";


                mm.IsBodyHtml =true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential("angelinetanch@gmail.com", "5566117angeline");
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = 587;
                smtp.Send(mm);
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Email sent.');", true);


                //53233


                // try
                //{
                //   MailMessage mailMessage = new MailMessage();
                // mailMessage.To.Add("angelinetanch@gmail.com");
                // mailMessage.From = new MailAddress(txtEmail.Text.Trim());
                // mailMessage.Subject = "Enquiry Form";
                // mailMessage.Body = "<h2>" + "Enquiry from " + " " + txtName.Text + "</h2>" + "<br><br>" +
                //
                //  "Subject: " + txtSubject.Text + "<br>" +

                // "Email : " + txtEmail.Text.Trim() + "<br>" +

                //"InQuiry: " + txtInquiry.Text.Trim() + "<br>" +

                // "Thank You";

                // EmailUtl.SendEmail(mailMessage);
                // Response.Write("E-mail sent!");
                //  }
                // catch (Exception ex)
                //  {
                //  Response.Write("Could not send the e-mail - error: " + ex.Message);
                // }






                //  }

                //private void Clear()

                //    {

                //      txtName.Text = string.Empty;

                //   txtSubject.Text = string.Empty;
                //
                //  txtEmail.Text = string.Empty;

                //  txtInquiry.Text = string.Empty;


                //if (fuAttachment.HasFile)
                //{
                  //  string FileName = Path.GetFileName(fuAttachment.PostedFile.FileName);
                  //  mm.Attachments.Add(new Attachment(fuAttachment.PostedFile.InputStream, FileName));
                //}





            }

        }
    }
}