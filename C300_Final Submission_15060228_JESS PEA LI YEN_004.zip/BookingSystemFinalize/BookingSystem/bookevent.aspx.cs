﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class _event : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request["event_id"] == null)
            {
                Response.Redirect("Home.aspx");
                return;
            }
            if (!IsPostBack)
            {

                string sql = @"SELECT * FROM Events e,Event_venue ev,Event_shift_master esm WHERE e.event_id=esm.event_id 
AND ev.venue_id = esm.venue_id AND e.event_id={0}";


                DataTable ds = DBUtl.GetTable(sql, Request["event_id"]);
                TxtTitle.Text = ds.Rows[0]["event_name"].ToString();
                Txtvenue.Text = ds.Rows[0]["event_venue"].ToString();

                string sql1 = @"SELECT CONCAT(event_start_date,' - ',event_end_date) AS shift , shift_desc , event_date_shift FROM Events e,Event_venue ev,Event_shift_master esm WHERE e.event_id=esm.event_id 
AND ev.venue_id = esm.venue_id AND e.event_id ={0}";


                DataTable dss = DBUtl.GetTable(sql1, Request["event_id"]);
                DrpVenue.DataSource = dss;
                DrpVenue.DataTextField = "shift"; // the items to be displayed in the list items
                DrpVenue.DataValueField = "event_date_shift"; // the id of the items displayed
                DrpVenue.DataBind();
                DrpVenue.Items.Insert(0, "-- Select --");

                Session["event_id"] = Request["event_id"];

            }

        }

        protected void BtnBook_Click(object sender, EventArgs e)
        {
            string title = TxtTitle.Text.Trim();
            string nric = Session["nric"].ToString();

            string[] venue = DrpVenue.SelectedValue.Split('-');

            string sqlt = @"SELECT * FROM Events e,Event_venue ev,Event_shift_master esm WHERE e.event_id=esm.event_id 
AND ev.venue_id = esm.venue_id AND e.event_id={0}";
            DataTable dt = DBUtl.GetTable(sqlt, Request["event_id"]);


            if (title.Equals("") || DrpVenue.SelectedValue.Equals(""))
            {
                Literal1.Text = "Please enter all fields";
                return;
            }

            if (dt.Rows.Count==1 || dt.Rows.Count == 2)
            {


                string sql1 = @"SELECT * FROM Events_booking eb,Events e ,Event_venue ev ,Event_shift_master esm
 WHERE eb.event_date_shift=esm.event_date_shift AND ev.venue_id=esm.venue_id AND esm.event_id=e.event_id AND nric='{0}' AND e.event_id='{1}'";

                DataTable dss = DBUtl.GetTable(sql1, nric, Request["event_id"]);

                if (dss.Rows.Count == 0)
                {
                    int rowsAffected = 0;
                    string number = @"SELECT available_slots FROM Events WHERE event_id={0}";
                    DataTable ds = DBUtl.GetTable(number, Request["event_id"]);
                    int num = Convert.ToInt32(ds.Rows[0]["available_slots"]) - 1;

                    string venuee = @"SELECT * FROM Events_booking WHERE nric='{0}' AND event_date_shift='{1}'";
                    DataTable vs = DBUtl.GetTable(venuee, nric, DrpVenue.SelectedValue);

                    if (vs.Rows.Count == 0)
                    {

                        // TODO P08 Task 5 Code INSERT SQL and Call DBUtl.ExecSQL Securely
                        string sql = @"INSERT INTO Events_booking (event_date_shift,nric)
                          VALUES('{0}','{1}')";
                        rowsAffected = DBUtl.ExecSQL(sql, DrpVenue.SelectedValue, nric);
                        if (rowsAffected == 1 && num != -1)
                        {

                            string sql2 = @"UPDATE Events SET available_slots={0} WHERE event_id={1}";
                            if (DBUtl.ExecSQL(sql2, num, Request["event_id"]) == 1)
                            {

                            }
                            Literal1.Text = "Booking successful!";
                            Literal2.Text = "";

                        }
                        else if (num == -1)
                        {

                            Literal1.Text = "Sorry , No slot Available for booking ";
                            Literal2.Text = "";
                        }
                        else
                        {
                            Literal1.Text = "Booking Unsuccessful!";
                            Literal2.Text = "";
                        }

                    }

                    else
                    {
                        Literal2.Text = "Sorry , you have already booked this timing";
                        Literal1.Text = "";
                    }

                }
                else
                {

                    Literal2.Text = "Sorry , you are not allowed to book two shift for this event ";
                    Literal1.Text = "";

                }


            }
            else if (dt.Rows.Count == 3)
            {
                string sql1 = @"SELECT * FROM Events_booking eb,Events e ,Event_venue ev ,Event_shift_master esm
 WHERE eb.event_date_shift=esm.event_date_shift AND ev.venue_id=esm.venue_id AND esm.event_id=e.event_id AND nric='{0}' AND e.event_id='{1}'";

                DataTable dss = DBUtl.GetTable(sql1, nric, Request["event_id"]);


                if (dss.Rows.Count == 0)
                {

                    int rowsAffected = 0;
                    string number = @"SELECT available_slots FROM Events WHERE event_id={0}";
                    DataTable ds = DBUtl.GetTable(number, Request["event_id"]);
                    int num = Convert.ToInt32(ds.Rows[0]["available_slots"]) - 1;

                    string venuee = @"SELECT * FROM Events_booking WHERE nric='{0}' AND event_date_shift='{1}'";
                    DataTable vs = DBUtl.GetTable(venuee, nric, DrpVenue.SelectedValue);

                    if (vs.Rows.Count == 0)
                    {

                        // TODO P08 Task 5 Code INSERT SQL and Call DBUtl.ExecSQL Securely
                        string sql = @"INSERT INTO Events_booking (event_date_shift,nric)
                          VALUES('{0}','{1}')";
                        rowsAffected = DBUtl.ExecSQL(sql, DrpVenue.SelectedValue, nric);
                        if (rowsAffected == 1 && num != -1)
                        {

                            string sql2 = @"UPDATE Events SET available_slots={0} WHERE event_id={1}";
                            if (DBUtl.ExecSQL(sql2, num, Request["event_id"]) == 1)
                            {

                            }
                            Literal1.Text = "Booking successful!";
                            Literal2.Text = "";

                        }
                        else if (num == -1)
                        {

                            Literal2.Text = "Sorry , No slot Available for booking ";
                            Literal1.Text = "";
                        }
                        else
                        {
                            Literal2.Text = "Booking Unsuccessful!";
                            Literal1.Text = "";
                        }

                    }

                    else
                    {
                        Literal2.Text = "Sorry , you have already booked this timing";
                        Literal1.Text = "";
                    }

                }

                else if (dss.Rows.Count == 1)
                {
                    if (dss.Rows[0]["event_date_shift"].ToString().Equals("4"))
                    {
                        if (DrpVenue.SelectedValue.Equals("6"))
                        {
                            int rowsAffected = 0;
                            string number = @"SELECT available_slots FROM Events WHERE event_id={0}";
                            DataTable ds = DBUtl.GetTable(number, Request["event_id"]);
                            int num = Convert.ToInt32(ds.Rows[0]["available_slots"]) - 1;


                            string sql = @"INSERT INTO Events_booking (event_date_shift,nric)
                          VALUES('{0}','{1}')";
                            rowsAffected = DBUtl.ExecSQL(sql, DrpVenue.SelectedValue, nric);
                            if (rowsAffected == 1 && num != -1)
                            {

                                string sql2 = @"UPDATE Events SET available_slots={0} WHERE event_id={1}";
                                if (DBUtl.ExecSQL(sql2, num, Request["event_id"]) == 1)
                                {

                                }
                                Literal1.Text = "Booking successful!";
                                Literal2.Text = "";
                                Literal3.Text = "";

                            }
                            else if (num == -1)
                            {

                                Literal3.Text = "Sorry , No slot Available for booking ";
                                Literal1.Text = "";
                                Literal2.Text = "";
                            }
                            else
                            {
                                Literal3.Text = "Booking Unsuccessful!";
                                Literal1.Text = "";
                                Literal2.Text = "";

                            }

                        }
                        else if (DrpVenue.SelectedValue.Equals("5"))
                        {
                            Literal3.Text = "sorry you are not allowed to book this timing! ";
                            Literal1.Text = "";
                            Literal2.Text = "";

                        }
                        else if (DrpVenue.SelectedValue.Equals("4"))
                        {
                            Literal3.Text = "sorry you are not allowed to book the same timing! ";
                            Literal1.Text = "";
                            Literal2.Text = "";

                        }
                    }
                    else if (dss.Rows[0]["event_date_shift"].ToString().Equals("5"))
                    {

                        Literal3.Text = "sorry you are not allowed to book this timing! ";

                    }
                    else if (dss.Rows[0]["event_date_shift"].ToString().Equals("6"))
                    {


                        if (DrpVenue.SelectedValue.Equals("4"))
                        {
                            int rowsAffected = 0;
                            string number = @"SELECT available_slots FROM Events WHERE event_id={0}";
                            DataTable ds = DBUtl.GetTable(number, Request["event_id"]);
                            int num = Convert.ToInt32(ds.Rows[0]["available_slots"]) - 1;


                            string sql = @"INSERT INTO Events_booking (event_date_shift,nric)
                          VALUES('{0}','{1}')";
                            rowsAffected = DBUtl.ExecSQL(sql, DrpVenue.SelectedValue, nric);
                            if (rowsAffected == 1 && num != -1)
                            {

                                string sql2 = @"UPDATE Events SET available_slots={0} WHERE event_id={1}";
                                if (DBUtl.ExecSQL(sql2, num, Request["event_id"]) == 1)
                                {

                                }
                                Literal1.Text = "Booking successful!";
                                Literal2.Text = "";
                                Literal3.Text = "";

                            }
                        }
                        else if (DrpVenue.SelectedValue.Equals("5"))
                        {
                            Literal3.Text = "sorry you are not allowed to book this timing! ";
                            Literal1.Text = "";

                        }
                        else if (DrpVenue.SelectedValue.Equals("6"))
                        {
                            Literal3.Text = "sorry you are not allowed to book the same timing! ";
                            Literal1.Text = "";
                            Literal2.Text = "";

                        }
                    }




                }
                else
                {
                    Literal2.Text = "sorry you have already book two different shift timing! ";
                    Literal1.Text = "";
                    Literal3.Text = "";
                }
            }



        }

        protected void BtnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}

