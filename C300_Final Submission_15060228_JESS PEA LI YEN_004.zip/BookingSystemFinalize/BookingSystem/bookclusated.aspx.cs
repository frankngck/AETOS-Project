﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class bookclusated : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

                DateTime dt = Convert.ToDateTime(Request["booking_date"].ToString());

                Literal1.Text = "Booking Shift for " + String.Format("{0:dd MMM yyyy}", dt);
                string sql = "";
                if (Session["cluster"].Equals("ATED"))
                {
                    sql = @"SELECT * FROM Sub_cluster sc, Sub_Cluster_has_Shift sch, 
                        Shifts s, Shift_Master sm WHERE s.shift_code = sch.shift_code
                        AND sc.sub_cluster_id = sch.sub_cluster_id AND sm.shift_id = s.shift_id
                        AND sch.sub_cluster_id ={0}";
                    GridView1.Columns[0].Visible = true;
                    GridView1.DataSource = DBUtl.GetTable(sql, 7);
                }

                GridView1.DataBind();
                GridView1.Columns[0].Visible = false;
            }
        }
        protected void btnDisplay_Click(object sender, EventArgs e)
        {


            string data = "";
            int count = 0;
            string idd = "";

            foreach (GridViewRow row in GridView1.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkRow = (row.Cells[3].FindControl("chkCtrl") as CheckBox);
                    if (chkRow.Checked)
                    {
                        count = count + 1;
                        string storid = row.Cells[2].Text;
                        string storidd = row.Cells[1].Text;
                        string id = row.Cells[0].Text;
                        //data = data + storid + " ";
                        data = data + id;

                        idd = idd + storidd + ",";

                    }
                }
            }



            if (count > 1)
            {
                lblmsg.Text = "Select only one shift!";
                msg.Text = "";
            }
            else
            {

                string nric = Session["nric"].ToString();
                string booking = Request["booking_date"].ToString();

                string sqlr = @"SELECT * FROM Cluster_booking cb, sub_cluster_has_shift sch WHERE cb.sub_shift_id=sch.sub_shift_id AND cb.booking_date ='{0}' 
                        AND sch.sub_cluster_id ='{1}' AND cb.nric ='{2}' AND cb.sub_shift_id ='{3}'";
                DataTable ds = DBUtl.GetTable(sqlr, booking, '7', nric, data);
                if (ds.Rows.Count == 1)
                {
                    lblmsg.Text = "Sorry you have already booked the same Shift " + " you are not allowed to book the same shift!";
                    msg.Text = "";
                }
                else
                {

                    string sql = @"INSERT INTO Cluster_booking(booking_date,nric,sub_shift_id) 
                               VALUES('{0}','{1}','{2}')";
                    int rows = DBUtl.ExecSQL(sql, booking, nric, data);
                    if (rows > 0)

                    {
                        msg.Text = "Selected Shift: " + idd + " has booked successfully!";
                        lblmsg.Text = "";
                    }
                    else
                    {
                        lblmsg.Text = "Booked unsuccessfully! ";
                        msg.Text = "";


                    }

                }

            }
        }

    }
}
