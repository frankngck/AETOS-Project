﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class EditPartTimer : System.Web.UI.Page
    {
        private static int emergency;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = @"SELECT * FROM Users, User_has_Cluster,Cluster
                                WHERE Cluster.cluster_id=User_has_Cluster.cluster_id
                                AND User_has_Cluster.nric=Users.nric
                                AND Users.nric='{0}'";
                DataTable ds = DBUtl.GetTable(sql, Request["nric"].ToString());

                TxtID.Text = ds.Rows[0]["service_id"].ToString();
                TxtName.Text = ds.Rows[0]["name"].ToString();
                TxtDept.Text = ds.Rows[0]["cluster_name"].ToString();
                TxtGender.Text = ds.Rows[0]["gender"].ToString();
                TxtNationality.Text = ds.Rows[0]["nationality"].ToString();
                TxtNRIC.Text = ds.Rows[0]["nric"].ToString();
                TxtPhone.Text = ds.Rows[0]["mobile_no"].ToString();
                TxtHome.Text = ds.Rows[0]["contact_no"].ToString();
                TxtAddress.Text = ds.Rows[0]["address"].ToString();
                TxtEmail.Text = ds.Rows[0]["email"].ToString();

                string sql1 = @"SELECT * FROM Users, User_Emergency
                                WHERE Users.nric = User_Emergency.nric
                                AND Users.nric='{0}'";
                DataTable dt = DBUtl.GetTable(sql1, Request["nric"].ToString());
                if (dt.Rows.Count == 1)
                {
                    emergency = 1;
                    TxtPhone1.Text = dt.Rows[0]["emergency_contact"].ToString();
                    TxtER.Text = dt.Rows[0]["emergency_name"].ToString();
                }
                else
                {
                    emergency = 0;
                }

            }
        }
    }
}

