﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookingSystem
{
    public partial class contact : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txt_location.Text = "145 West Coast Road Singapore 127367";

            TextBox1.Text = "info@aetos.com.sg";
            TextBox2.Text = "1800-2255-273";
            TextBox3.Text = "Mon to Fri, 8.30am to 6.00pm";



        }

    }

    }