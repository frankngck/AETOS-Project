﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;

namespace BookingSystem
{
    public partial class SAdminUserPromotion : System.Web.UI.Page
    {
        private const string sql = @"SELECT * FROM Users U, Rank R, Tier T, Cluster C, User_has_Cluster UC, User_has_Tier UT
                                    WHERE U.rank_id = R.rank_id
                                    AND U.nric = UT.nric
							        AND UT.tier_id = T.tier_id
							        AND U.nric = UC.nric
							        AND UC.cluster_id = C.cluster_id
							        AND role_id = 1";
        private string[] month = { "This month", "Previous month", "Two month ago" };

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateDrpCluster();
                GenerateGvUser();
                GenerateDrpMonth();
                PnlAdvanced.Visible = false;
                //Session["GvUser_Current"] = GvUser;
            }
        }

        private void GenerateDrpCluster()
        {
            string sql1 = @"SELECT * FROM Cluster C, Tier T 
                            WHERE C.tier_id = T.tier_id 
                            AND T.tier_id != 1";
            DataTable dt = DBUtl.GetTable(sql1);

            DrpCluster.DataSource = dt;
            DrpCluster.DataTextField = "cluster_name";
            DrpCluster.DataValueField = "cluster_id";
            DrpCluster.DataBind();
            DrpCluster.Items.Insert(0, "All");
        }

        private void GenerateDrpMonth()
        {
            //string[][] month = { new string[]{ "January", "1" }, new string[]{ "February", "2" },
            //                    new string[]{ "March", "3" }, new string[]{ "April", "4" },
            //                    new string[]{ "May", "5" } , new string[]{ "June", "6" },
            //                    new string[]{ "July", "7" }, new string[]{ "August", "8" },
            //                    new string[]{ "September", "9" }, new string[]{ "October", "10" },
            //                    new string[]{ "November", "11" }, new string[]{ "December", "12" } };

            DrpMonth.DataSource = month;
            DrpMonth.DataBind();
        }

        private void GenerateGvUser()
        {
            string sql1 = CheckDrpValue(sql);
            DataTable ds = DBUtl.GetTable(sql1);
            GvUser.DataSource = ds;
            GvUser.DataBind();
            LtlMessage.Text = "";
            Session["GvUser_Current"] = ds;
        }

        private string CheckDrpValue(string sql)
        {
            if (DrpCluster.SelectedIndex != 0)
            {
                string sql1 = sql + String.Format(@" AND C.cluster_id = '{0}'", DrpCluster.SelectedItem.Value);
                return sql1;
            }
            return sql;
        }

        protected void DrpCluster_SelectedIndexChanged(object sender, EventArgs e)
        {
            GenerateDrpMonth();
            GenerateGvUser();
        }

        protected void GvUser_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string nric = DataBinder.Eval(e.Row.DataItem, "nric").ToString(); // one of the other ways
                DataTable dt = DBUtl.GetTable(sql + String.Format(" AND U.nric = '{0}'", nric));

                RadioButton RbTier1 = e.Row.FindControl("RbTier1") as RadioButton;
                RadioButton RbTier2 = e.Row.FindControl("RbTier2") as RadioButton;
                if (dt.Rows[0]["tier_no"].ToString().Equals("1"))
                {
                    RbTier1.Checked = true;
                }
                else
                {
                    RbTier2.Checked = true;
                }

                Literal LtlHours = e.Row.FindControl("LtlHours") as Literal;
                LtlHours.Text = GetTotalHours(nric);

            }
            Session["oldList"] = GetGvUserTier();
        }

        private string GetTotalHours(string nric)
        {
            List<DateTime> dateList;
            List<int> hoursWorked = new List<int>();
            if (GetDate(out dateList))
            {
                foreach (DateTime date in dateList)
                {
                    string sql = String.Format(@"SELECT * FROM Shift_Master SM, Shifts S, Sub_Cluster_has_Shift SCS, Sub_Cluster SC, Users U, 
                                                    Cluster C, Tier T, User_has_Cluster UC, User_has_Tier UT, Cluster_Booking CB, Attendance A
                                                    WHERE SM.shift_id = S.shift_id
                                                    AND S.shift_code = SCS.shift_code
                                                    AND SCS.sub_cluster_id = SC.sub_cluster_id
                                                    AND SC.cluster_id = C.cluster_id
                                                    AND C.cluster_id = UC.cluster_id
                                                    AND UC.nric = U.nric
                                                    AND C.tier_id = T.tier_id
                                                    AND T.tier_id = UT.tier_id
                                                    AND U.nric = UT.nric
                                                    AND SCS.sub_shift_id = CB.sub_shift_id
                                                    AND CB.nric = U.nric
                                                    AND CB.clusterbooking_id = A.clusterbooking_id
                                                    AND A.nric = U.nric
                                                    AND U.nric = '{0}'
                                                    AND booking_date = '{1}'
                                                    AND attendance_status = 1", nric, date.ToString("yyyy-MM-dd"));

                    if (DBUtl.GetTable(sql).Rows.Count >= 1)
                    {
                        int hours = 0;
                        for (int count = 0; count < DBUtl.GetTable(sql).Rows.Count; count++)
                        {
                            hours += Convert.ToInt32(DBUtl.GetTable(sql).Rows[count]["shift_hours"].ToString());
                        }
                        hoursWorked.Add(hours);
                    }
                }
            }

            // Calculate the total hours for the month
            return CalculateMonthlyHours(hoursWorked).ToString();
        }

        private int CalculateMonthlyHours(List<int> hoursWorked)
        {
            int total = 0;
            foreach (int index in hoursWorked)
            {
                total += index;
            }
            return total;
        }

        private bool GetDate(out List<DateTime> dateList)
        {
            int index = GetMonthIndex();
            DateTime date = DateTime.Now;
            DateTime firstDayOfMonth;
            DateTime lastDayOfMonth;
            switch (index)
            {
                case 1:
                    date = date.AddMonths(-1);
                    break;
                case 2:
                    date = date.AddMonths(-2);
                    break;
                default:
                    break;
            }
            firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddDays(-1);
            // Check whether the date is correct
            //LtlMessage.Text = date.ToString() + firstDayOfMonth.ToString() + lastDayOfMonth.ToString();
            dateList = GetDateList(firstDayOfMonth, lastDayOfMonth);
            return true;
        }

        // Can Work
        private List<DateTime> GetDateList(DateTime start_date, DateTime end_date)
        {
            List<DateTime> dateList = new List<DateTime>();
            for (DateTime date = start_date; date <= end_date; date = date.AddDays(1))
                dateList.Add(date);
            return dateList;
        }

        private int GetMonthIndex()
        {
            for (int count = 0; count < month.Length; count++)
                if (DrpMonth.Text.Equals(month[count]))
                    return count;
            return -1;
        }

        protected void GvUser_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string sql1 = CheckDrpValue(sql);
            GvUser.PageIndex = e.NewPageIndex;
            if (ViewState["LastExpression"] == null)
            {
                GvUser.DataSource = DBUtl.GetTable(sql);
                return;
            }
            string sortExpression = ViewState["LastExpression"].ToString();
            string sortDirection = ViewState[sortExpression].ToString();
            GvUser.DataSource = DBUtl.GetTable(sql1 + " ORDER BY {0} {1}", sortExpression, sortDirection);
            GvUser.DataBind();
        }

        protected void GvUser_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sql1 = CheckDrpValue(sql);
            string sortExpression = e.SortExpression;
            string sortDirection = GetSortDirection(sortExpression);
            GvUser.DataSource = DBUtl.GetTable(sql1 + " ORDER BY {0} {1}", sortExpression, sortDirection);
            GvUser.DataBind();
        }

        private string GetSortDirection(string sortExpression)
        {
            ViewState["LastExpression"] = sortExpression;
            if (ViewState[sortExpression] == null)
                ViewState[sortExpression] = "ASC";
            else if (ViewState[sortExpression].ToString().Equals("ASC"))
                ViewState[sortExpression] = "DESC";
            else
                ViewState[sortExpression] = "ASC";
            return ViewState[sortExpression].ToString();
        }

        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            string service_id = TxtServiceID.Text.Trim();
            string sql1 = CheckDrpValue(sql);
            string search = string.Format(sql1 + " AND service_id='{0}'", service_id);
            GvUser.DataSource = DBUtl.GetTable(search);
            GvUser.DataBind();
        }

        private void Display(List<string> list)
        {
            foreach (string index in list)
            {
                LtlMessage.Text += index;
            }
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            UpdateTable();
        }

        private void UpdateTable()
        {
            List<string> oldList = (List<string>)Session["oldList"];
            Display(oldList);
            List<string> nricList = GetNricList();
            List<string> tierList = GetGvUserTier();
            string sql1 = "";
            for (int i = 0; i < nricList.Count; i++)
            {
                if (oldList[i].Equals(tierList[i]))
                {
                    continue;
                }
                string cluster_id = GetClusterID(tierList[i].ToString());
                int tier_id = Convert.ToInt32(tierList[i].ToString()) + 1;
                sql1 = String.Format(@"UPDATE User_has_Tier SET tier_id = '{1}', date_moved = getdate() 
                                        WHERE nric = '{0}'; 
                                        UPDATE User_has_Cluster SET cluster_id = '{2}', date_moved = getdate() 
                                        WHERE nric = '{0}'",
                                        nricList[i].ToString(), tier_id, cluster_id);
                if (DBUtl.ExecSQL(sql1) >= 1)
                    LtlMessage.Text += "Tier Updated Successfully </br>";
                else
                    LtlMessage.Text += "Failed to Update Tier " + DBUtl.DB_Message;
            }
        }

        private string GetClusterID(string tier_id)
        {
            string sql1 = String.Format(@"SELECT * FROM Cluster C, Tier T 
                                        WHERE T.tier_id = C.cluster_id 
                                        AND T.tier_no='{0}'", tier_id);
            DataTable dt = DBUtl.GetTable(sql1);
            return dt.Rows[0]["cluster_id"].ToString();
        }

        private List<string> GetNricList()
        {
            List<string> nricList = new List<string>();
            foreach (GridViewRow gr in GvUser.Rows)
            {
                string nric = GvUser.DataKeys[gr.RowIndex].Value.ToString(); // one of the other ways
                nricList.Add(nric);
            }
            return nricList;
        }

        private List<string> GetGvUserTier()
        {
            List<string> tierList = new List<string>();
            foreach (GridViewRow row in GvUser.Rows)
            {
                //Find the Radio button control
                RadioButton RbTier1 = (RadioButton)row.FindControl("RbTier1");
                RadioButton RbTier2 = (RadioButton)row.FindControl("RbTier2");
                if (RbTier1.Checked == true)
                {
                    tierList.Add("1");
                }
                else
                {
                    tierList.Add("2");
                }
            }
            return tierList;
        }

        protected void DrpHours_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (DrpHours.SelectedIndex == 0) // Less than 48 hrs/month
            //{
            //    return;
            //}
            //// Get the current Gridview
            //DataTable dtUser = Session["GvUser_Current"] as DataTable;
            //DataTable dtNew = new DataTable();

            //for (int row = 0; row < dtUser.Rows.Count; row++)
            //{
            //    int LtlHours = Convert.ToInt32((GvUser.Rows[row].FindControl("LtlHours") as Literal).Text);
            //    if (DrpHours.SelectedValue.Equals("1")) // Less than 48 hours
            //    {
            //        if (LtlHours <= 48)
            //        {
            //            dtNew.ImportRow(dtUser.Rows[row]);
            //        }
            //    } else if (DrpHours.SelectedValue.Equals("2")) // More than 48 hours
            //    {
            //        if (LtlHours > 48)
            //        {
            //            dtNew.ImportRow(dtUser.Rows[row]);
            //        }
            //    }
            //}
            //GvUser.DataSource = dtNew;
            //GvUser.DataBind();
            //Session["GvUser_Current"] = dtNew;
            ////LtlMessage.Text = DrpMonth.SelectedItem.Text;
        }

        protected void DrpMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            GenerateGvUser();
        }

        protected void ShowHideAdvanced_Click(object sender, EventArgs e)
        {
            if (Session["ShowHide"] == null)
            {
                PnlAdvanced.Visible = true;
                Session["ShowHide"] = "Show";
                ShowHideAdvanced.Text = "Hide Advanced";
            }
            else if (Session["ShowHide"].ToString().Equals("Show"))
            {
                PnlAdvanced.Visible = false;
                Session["ShowHide"] = "Hide";
                ShowHideAdvanced.Text = "Show Advanced";
            }
            else
            {
                PnlAdvanced.Visible = true;
                Session["ShowHide"] = "Show";
                ShowHideAdvanced.Text = "Hide Advanced";
            }
        }
    }
}