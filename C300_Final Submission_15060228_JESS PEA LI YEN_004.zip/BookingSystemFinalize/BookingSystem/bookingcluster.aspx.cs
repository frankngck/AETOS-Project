﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class bookingcluster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

                string nric = Session["nric"].ToString();
                string booking = Request["booking_date"].ToString();

                string sqlrr = @"SELECT * FROM Cluster_booking cb, sub_cluster_has_shift sch WHERE cb.sub_shift_id=sch.sub_shift_id AND cb.booking_date ='{0}' 
                        AND cb.nric ='{1}'";
                DataTable dss = DBUtl.GetTable(sqlrr, booking, nric);






                DateTime dt = Convert.ToDateTime(Request["booking_date"].ToString());


                Literal1.Text = "Booking Shift for " + String.Format("{0:dd MMM yyyy}", dt);
                if (Session["cluster"].Equals("WCP"))
                {

                    if (dss.Rows.Count > 0)
                    {
                        string sql2 = "SELECT * FROM Sub_cluster WHERE cluster_id=2 AND sub_cluster_id='{0}'";
                        DataTable dns = DBUtl.GetTable(sql2, dss.Rows[0]["sub_cluster_id"]);
                        DrpDuration.DataSource = dns;
                        DrpDuration.DataTextField = "sub_cluster_name"; // the items to be displayed in the list items
                        DrpDuration.DataValueField = "sub_cluster_id"; // the id of the items displayed
                        DrpDuration.DataBind();
                        DrpDuration.Items.Insert(0, "-- Select --");
                    }

                    else
                    {

                        string sql1 = "SELECT * FROM Sub_cluster WHERE cluster_id=2";
                        DataTable ds = DBUtl.GetTable(sql1);
                        DrpDuration.DataSource = ds;
                        DrpDuration.DataTextField = "sub_cluster_name"; // the items to be displayed in the list items
                        DrpDuration.DataValueField = "sub_cluster_id"; // the id of the items displayed
                        DrpDuration.DataBind();
                        DrpDuration.Items.Insert(0, "-- Select --");
                    }
                }
            }
        }


        //ListItem i = DrpDuration.Items.FindByValue("2");
        //ListItem ii = DrpDuration.Items.FindByValue("3");
        //ListItem iii = DrpDuration.Items.FindByValue("4");
        //ListItem iiii = DrpDuration.Items.FindByValue("5");
        //ListItem right = DrpDuration.Items.FindByValue(s);

        //i.Attributes.Add("disabled", "true");
        //ii.Attributes.Add("disabled", "true");
        //iii.Attributes.Add("disabled", "true");
        // iiii.Attributes.Add("disabled", "true");






        protected void btmDisplay_Click(object sender, EventArgs e)
        {
            string nric = Session["nric"].ToString();
            string booking = Request["booking_date"].ToString();

            string sqlv = @"SELECT * FROM Cluster_booking cb, sub_cluster_has_shift sch WHERE cb.sub_shift_id = sch.sub_shift_id AND cb.booking_date = '{0}'
                        AND sch.sub_cluster_id = '{1}' AND cb.nric = '{2}'";
            DataTable dssd = DBUtl.GetTable(sqlv, Request["booking_date"].ToString(), DrpDuration.SelectedValue, nric);


            string sqlt = @"SELECT * FROM Sub_Cluster sc,Sub_Cluster_has_Shift scs WHERE sc.sub_Cluster_id=scs.sub_Cluster_id 
                          AND sc.sub_cluster_id='{0}'";
            DataTable ds = DBUtl.GetTable(sqlt, DrpDuration.SelectedValue);



            string data = "";
            int count = 0;
            string idd = "";

            foreach (GridViewRow row in GridView1.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkRow = (row.Cells[3].FindControl("chkCtrl") as CheckBox);
                    if (chkRow.Checked)
                    {
                        count = count + 1;
                        string storid = row.Cells[2].Text;
                        string storidd = row.Cells[1].Text;
                        string id = row.Cells[0].Text;
                        //data = data + storid + " ";
                        data = data + id + ";";

                        idd = idd + storidd + ",";

                    }
                }


            }



            if (ds.Rows.Count == 2)
            {

                if (dssd.Rows.Count == 1)
                {

                    lblmsg.Text = "Sorry only allow one shift booking ,  you have booked one shift previously";

                    msg.Text = "";


                }
                else
                {





                    if (count > 1)
                    {
                        lblmsg.Text = "Select only one shift!";
                        msg.Text = "";
                    }





                    else
                    {
                        string[] dataarray = data.Split(';');



                        string sqlr = @"SELECT * FROM Cluster_booking cb, sub_cluster_has_shift sch WHERE cb.sub_shift_id=sch.sub_shift_id AND cb.booking_date ='{0}' 
                        AND sch.sub_cluster_id ='{1}' AND cb.nric ='{2}' AND cb.sub_shift_id ='{3}'";
                        DataTable dsvm = DBUtl.GetTable(sqlr, booking, DrpDuration.SelectedValue, nric, dataarray[0]);



                        if (dsvm.Rows.Count == 1)
                        {
                            lblmsg.Text = "Sorry you have already booked Shift : " + " you are not allowed to book the same shift!";
                            msg.Text = "";
                            return;

                        }

                        else
                        {

                            string sql = @"INSERT INTO Cluster_booking(booking_date,nric,sub_shift_id) 
                               VALUES('{0}','{1}','{2}')";
                            int rows = DBUtl.ExecSQL(sql, booking, nric, dataarray[0]);
                            if (rows > 0)

                            {
                                msg.Text = "Selected Shift: " + idd + " has booked successfully!";
                                lblmsg.Text = "";



                            }
                            else
                            {
                                lblmsg.Text = "Booked unsuccessfully! ";
                                msg.Text = "";


                            }

                        }

                    }
                }

            }
            else if (ds.Rows.Count == 3)
            {


                if (dssd.Rows.Count == 2)
                {

                    lblmsg.Text = "Sorry only allow maximum two shift booking,  you have booked two shift previously";

                    msg.Text = "";


                }
                else
                {

                    if (count == 3)
                    {
                        lblmsg.Text = "Cannot select three shift!";

                        msg.Text = "";
                    }




                    else if (count == 2)
                    {

                        string[] dataarray = data.Split(';');

                        string sqlr = @"SELECT* FROM Cluster_booking cb, sub_cluster_has_shift sch WHERE cb.sub_shift_id = sch.sub_shift_id AND cb.booking_date = '{0}'
                        AND sch.sub_cluster_id = '{1}' AND cb.nric = '{2}' AND cb.sub_shift_id = '{3}'";
                        DataTable dst = DBUtl.GetTable(sqlr, Request["booking_date"].ToString(), DrpDuration.SelectedValue, nric, dataarray[0]);
                        DataTable dt = DBUtl.GetTable(sqlr, Request["booking_date"].ToString(), DrpDuration.SelectedValue, nric, dataarray[1]);


                        if (dst.Rows.Count == 1 || dt.Rows.Count == 1)
                        {
                            lblmsg.Text = "Sorry you have already booked the selected shift, Sorry you are not allowed to book the same shift!";
                            msg.Text = "";
                        }
                        else
                        {

                            string sql = @"INSERT INTO Cluster_booking(booking_date,nric,sub_shift_id) 
                               VALUES('{0}','{1}','{2}'),('{0}','{1}','{3}')";



                            if (DBUtl.ExecSQL(sql, Request["booking_date"].ToString(), nric, dataarray[0], dataarray[1]) > 0)

                            {
                                msg.Text = "Selected Shift: " + idd + " has booked successfully!";
                                lblmsg.Text = "";


                            }
                            else
                            {
                                lblmsg.Text = "Booked unsuccessfully! ";
                                msg.Text = "";
                            }

                        }
                    }
                    else
                    {

                        string[] dataarray = data.Split(';');



                        string sqlr = @"SELECT * FROM Cluster_booking cb, sub_cluster_has_shift sch WHERE cb.sub_shift_id=sch.sub_shift_id AND cb.booking_date ='{0}' 
                        AND sch.sub_cluster_id ='{1}' AND cb.nric ='{2}' AND cb.sub_shift_id ='{3}'";
                        DataTable dstt = DBUtl.GetTable(sqlr, Request["booking_date"].ToString(), DrpDuration.SelectedValue, nric, dataarray[0]);



                        if (dstt.Rows.Count == 1)
                        {
                            lblmsg.Text = "Sorry you have already booked the selected shift,Sorry you are not allowed to book the same shift!";
                            msg.Text = "";
                        }
                        else
                        {
                            string sql = @"INSERT INTO Cluster_booking(booking_date,nric,sub_shift_id) 
                               VALUES('{0}','{1}','{2}')";



                            if (DBUtl.ExecSQL(sql, Request["booking_date"].ToString(), nric, dataarray[0]) > 0)

                            {
                                msg.Text = "Selected Shift: " + idd + " has booked successfully!";
                                lblmsg.Text = "";

                            }
                            else
                            {
                                lblmsg.Text = "Booked unsuccessfully! ";
                                msg.Text = "";


                            }
                        }
                    }
                }

            }
        }

        protected void DrpDuration_SelectedIndexChanged(object sender, EventArgs e)
        {



            string nric = Session["nric"].ToString();
            string booking = Request["booking_date"].ToString();




            //   foreach (ListItem item in DrpDuration.Items)
            //    {
            //      if (item.ToString() != dss.Rows[0]["sub_cluster_id"].ToString())
            //    {
            //    item.Attributes.Add("disabled", "disabled");
            //  }
            //}
            //}

            //  if (DrpDuration.SelectedValue != dss.Rows[0]["sub_cluster_id"].ToString())
            //{
            //  Page.ClientScript.RegisterStartupScript(this.GetType(), "myal‌​ert", "alert('Booking are only available for ');", true);

            //}
            //}
            string sqlrr = @"SELECT * FROM Cluster_booking cb, sub_cluster_has_shift sch WHERE cb.sub_shift_id=sch.sub_shift_id AND cb.booking_date ='{0}' 
                        AND cb.nric ='{1}'";
            DataTable dss = DBUtl.GetTable(sqlrr, booking, nric);

            if (dss.Rows.Count > 0)
            {
                string sql2 = "SELECT * FROM Sub_cluster WHERE cluster_id=2 AND sub_cluster_id='{0}'";
                DataTable dns = DBUtl.GetTable(sql2, dss.Rows[0]["sub_cluster_id"]);
                DrpDuration.DataSource = dns;
                DrpDuration.DataTextField = "sub_cluster_name"; // the items to be displayed in the list items
                DrpDuration.DataValueField = "sub_cluster_id"; // the id of the items displayed
                DrpDuration.DataBind();
                DrpDuration.Items.Insert(0, "-- Select --");
                DrpDuration.SelectedValue = dss.Rows[0]["sub_cluster_id"].ToString();

                string sql1 = "";



                sql1 = @"SELECT * FROM Sub_cluster sc,Sub_Cluster_has_Shift sch, 
                        Shifts s,Shift_Master sm WHERE s.shift_code=sch.shift_code
                        AND sc.sub_cluster_id=sch.sub_cluster_id AND sm.shift_id=s.shift_id
                        AND sch.sub_cluster_id='{0}'";
                GridView1.Columns[0].Visible = true;
                GridView1.DataSource = DBUtl.GetTable(sql1, dss.Rows[0]["sub_cluster_id"]);



                GridView1.DataBind();
                GridView1.Columns[0].Visible = false;



            }
            else if (dss.Rows.Count == 0)
            {

                string sql = "";
                if (DrpDuration.SelectedValue.Equals("-- Select --"))
                {
                    msg.Text = null;
                    GridView1.DataSource = null;
                }
                else
                {
                    sql = @"SELECT * FROM Sub_cluster sc,Sub_Cluster_has_Shift sch, 
                        Shifts s,Shift_Master sm WHERE s.shift_code=sch.shift_code
                        AND sc.sub_cluster_id=sch.sub_cluster_id AND sm.shift_id=s.shift_id
                        AND sch.sub_cluster_id={0}";
                    GridView1.Columns[0].Visible = true;
                    GridView1.DataSource = DBUtl.GetTable(sql, DrpDuration.SelectedValue);


                }

                GridView1.DataBind();
                GridView1.Columns[0].Visible = false;
                //@"SELECT * FROM Sub_cluster sc, Sub_Cluster_has_Shift sch,

            }
        }
    }
}




