﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookingSystem
{
    public partial class AdminViewUsers : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            string sqlUser = "";
            if (Request["sub-cluster"] != null)
            {
                string sql = @"SELECT * FROM Users U, User_has_Cluster UC, Cluster C, User_has_Tier UT, Tier T, 
                                Rank RK, Role RL, Sub_Cluster SC
                            WHERE U.nric = UC.nric
                            AND UC.cluster_id = C.cluster_id
                            AND U.nric = UT.nric
                            AND UT.tier_id = C.tier_id
                            AND U.rank_id = RK.rank_id
							AND C.tier_id = T.tier_id
							AND U.role_id = RL.role_id
                            AND C.cluster_id = SC.cluster_id
							AND role_name = 'USER'
                            AND cluster_name = '{0}'";
                sqlUser = String.Format(sql + " AND sub_cluster_name = '{1}'",
                    Session["cluster"].ToString(), Request["sub-cluster"].ToString());
            }
            else
            {
                string sql = @"SELECT * FROM Users U, User_has_Cluster UC, Cluster C, User_has_Tier UT, Tier T, 
                                Rank RK, Role RL
                            WHERE U.nric = UC.nric
                            AND UC.cluster_id = C.cluster_id
                            AND U.nric = UT.nric
                            AND UT.tier_id = C.tier_id
                            AND U.rank_id = RK.rank_id
							AND C.tier_id = T.tier_id
							AND U.role_id = RL.role_id
							AND role_name = 'USER'
                            AND cluster_name = '{0}'";
                sqlUser = String.Format(sql, Session["cluster"].ToString());
            }

            GvUser.DataSource = DBUtl.GetTable(sqlUser);
            GvUser.DataBind();
        }

        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            string service_id = TxtServiceID.Text.Trim();
            string sqlSearch = "";
            if (Request["sub-cluster"] != null)
            {
                string sql = @"SELECT * FROM Users U, User_has_Cluster UC, Cluster C, User_has_Tier UT, Tier T, 
                                Rank RK, Role RL, Sub_Cluster SC
                            WHERE U.nric = UC.nric
                            AND UC.cluster_id = C.cluster_id
                            AND U.nric = UT.nric
                            AND UT.tier_id = C.tier_id
                            AND U.rank_id = RK.rank_id
							AND C.tier_id = T.tier_id
							AND U.role_id = RL.role_id
                            AND C.cluster_id = SC.cluster_id
							AND role_name = 'USER'
                            AND cluster_name = '{0}' ";
                sqlSearch = String.Format(sql + " AND sub_cluster_name = '{1}' AND service_id='{2}''",
                    Session["cluster"].ToString(), Request["sub-cluster"].ToString(), TxtServiceID.Text);
            }
            else
            {
                string sql = @"SELECT * FROM Users U, User_has_Cluster UC, Cluster C, User_has_Tier UT, Tier T, 
                                Rank RK, Role RL
                            WHERE U.nric = UC.nric
                            AND UC.cluster_id = C.cluster_id
                            AND U.nric = UT.nric
                            AND UT.tier_id = C.tier_id
                            AND U.rank_id = RK.rank_id
							AND C.tier_id = T.tier_id
							AND U.role_id = RL.role_id
							AND role_name = 'USER'
                            AND cluster_name = '{0}'AND service_id='{1}'";
                sqlSearch = String.Format(sql, Session["cluster"].ToString(), TxtServiceID.Text);
            }
            GvUser.DataSource = DBUtl.GetTable(sqlSearch);
            GvUser.DataBind();
        }
    }
}