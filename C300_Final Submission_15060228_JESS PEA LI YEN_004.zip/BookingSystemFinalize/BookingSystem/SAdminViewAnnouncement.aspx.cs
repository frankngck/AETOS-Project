﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookingSystem
{
    public partial class SAdminViewAnnouncement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateGvAnnouncement();
            }
        }

        private void GenerateGvAnnouncement()
        {
            string sql = @"SELECT * FROM Announcement ORDER BY start_date DESC";
            GvAnnouncement.DataSource = DBUtl.GetTable(sql);
            GvAnnouncement.DataBind();
        }

        protected void GvAnnouncement_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string sql = @"SELECT * FROM Announcement";
            GvAnnouncement.PageIndex = e.NewPageIndex;
            if (ViewState["LastExpression"] == null)
            {
                GvAnnouncement.DataSource = DBUtl.GetTable(sql);
            }
            else
            {
                string sortExpression = ViewState["LastExpression"].ToString();
                string sortDirection = ViewState[sortExpression].ToString(); ;
                GvAnnouncement.DataSource = DBUtl.GetTable(sql + " AND {0} {1}", sortExpression, sortDirection);
            }
            GvAnnouncement.DataBind();
        }

        protected void GvAnnouncement_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sql = @"SELECT * FROM Announcement";
            string sortExpression = e.SortExpression;
            string sortDirection = GetSortDirection(sortExpression);
            GvAnnouncement.DataSource = DBUtl.GetTable(sql + " AND {0} {1}", sortExpression, sortDirection);
            GvAnnouncement.DataBind();
        }

        private string GetSortDirection(string sortExpression)
        {
            ViewState["LastExpression"] = sortExpression;
            if (ViewState[sortExpression] == null)
                ViewState[sortExpression] = "ASC";
            else if (ViewState[sortExpression].ToString().Equals("ASC"))
                ViewState[sortExpression] = "DESC";
            else
                ViewState[sortExpression] = "ASC";
            return ViewState[sortExpression].ToString();
        }

        protected void GvAnnouncement_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GvAnnouncement.DataKeys[e.RowIndex].Value.ToString());
            string sql = String.Format(@"DELETE FROM Announcement WHERE announ_id = '{0}'", id);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Deleted Successfully";
            else
                LtlMessage.Text = "Failed to Delete" + DBUtl.DB_Message;
            GenerateGvAnnouncement();
        }

        protected void GvAnnouncement_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            GvAnnouncement.EditIndex = -1;
            GenerateGvAnnouncement();
        }

        protected void GvAnnouncement_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvAnnouncement.EditIndex = e.NewEditIndex;
            GenerateGvAnnouncement();
        }

        protected void GvAnnouncement_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GvAnnouncement.Rows[e.RowIndex];
            TextBox TxtName = (TextBox)row.FindControl("TxtName");
            TextBox TxtDescription = (TextBox)row.FindControl("TxtDescription");
            TextBox TxtStartDate = (TextBox)row.FindControl("TxtStartDate");
            TextBox TxtEndDate = (TextBox)row.FindControl("TxtEndDate");
            int id = Convert.ToInt32(GvAnnouncement.DataKeys[e.RowIndex].Value.ToString());
            // Have to change to MM first else the records stored is switch between the Month and the Date
            string start_date = Convert.ToDateTime(TxtStartDate.Text).ToString("MM-dd-yyyy hh:mm:ss tt");
            string end_date = Convert.ToDateTime(TxtEndDate.Text).ToString("MM-dd-yyyy hh:mm:ss tt");
            string sql = String.Format(@"UPDATE Announcement SET announ_title = '{1}', announ_descrip = '{2}', 
                                        start_date = '{3}', end_date = '{4}'
                                        WHERE announ_id = '{0}'", id, TxtName.Text, TxtDescription.Text,
                                        start_date, end_date);
            if (DBUtl.ExecSQL(sql) == 1)
                LtlMessage.Text = "Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update" + DBUtl.DB_Message;
            GvAnnouncement.EditIndex = -1;
            GenerateGvAnnouncement();
        }

        protected void BtnCreateNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("SAdminAddAnnouncement.aspx");
        }
    }
}