﻿using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System;
using System.Collections.Generic;

public class DBUtl
{

    //
    // "dbstr" must exist in web.config to determine which database to connect
    //
    private static string DB_CONNECTION =
       ConfigurationManager.ConnectionStrings["dbstr"].ConnectionString;

    public static string DB_Message;

    public static DataTable GetTable(string sql, params object[] list)
    {
        List<String> escParams = new List<String>();
        foreach (object o in list)
        {
            escParams.Add(EscQuote(o.ToString()));
        }
        string escSQL = String.Format(sql, escParams.ToArray());

        DataTable dt = new DataTable();
        using (SqlConnection dbConn = new SqlConnection(DB_CONNECTION))
        using (SqlDataAdapter dAdptr = new SqlDataAdapter(escSQL, dbConn))
        {
            try
            {
                dAdptr.Fill(dt);
                return dt;
            }

            catch (System.Exception ex)
            {
                dt.Columns.Add("EXCEPTION", typeof(string));
                dt.Columns.Add("SQL", typeof(string));
                DataRow row = dt.NewRow();
                row[0] = ex.Message;
                row[1] = sql;
                dt.Rows.Add(row);
                return dt;
            }
        }
    }

    public static int ExecSQL(string sql, params object[] list)
    {
        List<String> escParams = new List<String>();
        foreach (object o in list)
        {
            escParams.Add(EscQuote(o.ToString()));
        }
        string escSQL = String.Format(sql, escParams.ToArray());

        int rowsAffected = 0;
        using (SqlConnection dbConn = new SqlConnection(DB_CONNECTION))
        using (SqlCommand dbCmd = dbConn.CreateCommand())
        {
            try
            {
                dbConn.Open();
                dbCmd.CommandText = escSQL;
                rowsAffected = dbCmd.ExecuteNonQuery();
            }

            catch (System.Exception ex)
            {
                DB_Message = ex.Message;
                rowsAffected = -1;
            }
        }
        return rowsAffected;
    }

    public static string EscQuote(string line)
    {
        return line.Replace("'", "''");
    }
}
