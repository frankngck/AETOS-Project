﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace BookingSystem
{
    public partial class Booking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Selection_Change(object sender, EventArgs e)
        {
            if (Calendar1.SelectedDate < DateTime.Now.Date.AddDays(3))
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myal‌​ert", "alert('Booking are only available for 3 days in advance');", true);
            }
            else
            {
                if (Session["cluster"].Equals("WCP"))
                {
                    string url = String.Format("bookingcluster.aspx?booking_date={0}", Calendar1.SelectedDate.ToString("yyyy-MM-dd"));
                    Response.Redirect(url);
                }
                else if (Session["cluster"].Equals("PRISON"))
                {
                    string url = String.Format("bookclusprison.aspx?booking_date={0}", Calendar1.SelectedDate.ToString("yyyy-MM-dd"));
                    Response.Redirect(url);
                }
                else if (Session["cluster"].Equals("ATED"))
                {
                    string url = String.Format("bookclusated.aspx?booking_date={0}", Calendar1.SelectedDate.ToString("yyyy-MM-dd"));
                    Response.Redirect(url);
                }
            }
        }
    }
}