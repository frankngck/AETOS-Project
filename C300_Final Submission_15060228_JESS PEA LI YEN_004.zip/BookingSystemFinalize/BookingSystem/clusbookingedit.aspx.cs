﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
namespace BookingSystem
{
    public partial class clusbookingedit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string clusbookingid = Request.QueryString["clusterbooking_id"].ToString();
                string clusterid = "";

                string sql2 = @"SELECT * FROM Cluster_booking cb, Sub_Cluster_has_shift sch WHERE cb.sub_shift_id=sch.sub_shift_id AND clusterbooking_id='{0}'";
                sql2 = String.Format(sql2, clusbookingid);
                DataTable dtt = DBUtl.GetTable(sql2);



                string sqll = @"SELECT * FROM Sub_cluster sc,Sub_Cluster_has_Shift sch, 
                        Shifts s,Shift_Master sm WHERE s.shift_code=sch.shift_code
                        AND sc.sub_cluster_id=sch.sub_cluster_id AND sm.shift_id=s.shift_id AND sc.sub_cluster_id='{0}'";

                DrpVenue.DataSource = DBUtl.GetTable(sqll, dtt.Rows[0]["sub_cluster_id"]);
                DrpVenue.DataBind();


                string sql1 = @"SELECT * FROM Cluster_booking cb, Sub_Cluster_has_shift sch ,Sub_Cluster cs,Shifts s,Shift_Master sm 
 WHERE cb.sub_shift_id=sch.sub_shift_id AND cs.sub_cluster_id=sch.sub_cluster_id AND sch.shift_code=s.shift_code
 AND s.shift_id=sm.shift_id AND  clusterbooking_id='{0}'";
                sql1 = String.Format(sql1, clusbookingid);
                DataTable dt = DBUtl.GetTable(sql1);
                if (dt.Rows.Count == 1)
                {
                    TxtID.Text = dt.Rows[0]["sub_cluster_name"].ToString();
                    clusterid = dt.Rows[0]["sub_cluster_id"].ToString();
                    Txtdate.Text = String.Format("{0:yyyy-MM-dd}", dt.Rows[0]["booking_date"]);

                    Txtremarks.Text = dt.Rows[0]["remarks"].ToString();
                    DrpVenue.SelectedValue = dt.Rows[0]["sub_shift_id"].ToString();


                }
                else
                {
                    LtlMessage.Text = "booking cant be retrieve!";
                }





                string nric = Session["nric"].ToString();


            }
        }



        protected void BtnInsert_Click(object sender, EventArgs e)
        {
            string clusbookingid = Request.QueryString["clusterbooking_id"].ToString();




            string sql1 = @"SELECT * FROM Cluster_booking cb, Sub_Cluster_has_shift sch ,Sub_Cluster cs, Shifts s,Shift_Master sm
 WHERE cb.sub_shift_id = sch.sub_shift_id AND cs.sub_cluster_id = sch.sub_cluster_id AND sch.shift_code = s.shift_code
 AND s.shift_id = sm.shift_id AND cs.sub_cluster_name = '{0}' AND nric = '{1}' AND sm.shift_timing = '{2}' AND booking_date = '{3}'";
            sql1 = String.Format(sql1, TxtID.Text, Session["nric"].ToString(), DrpVenue.SelectedItem, Txtdate.Text);
            DataTable dt = DBUtl.GetTable(sql1);


            if (dt.Rows.Count == 1)
            {
                lblmsg.Text = "Sorry you have booked this shift previously";

            }
            else
            {




                string sqlrr = @"UPDATE Cluster_booking SET sub_shift_id='{0}' , remarks='{1}' WHERE clusterbooking_id='{2}'";
                int count = DBUtl.ExecSQL(sqlrr, DrpVenue.SelectedValue, Txtremarks.Text, clusbookingid);






                if (count == 1)
                {

                    lblmsg.Text = "Booking Updated Successfully!";
                }
                else
                {
                    lblmsg.Text = "Booking Updated Unsuccessfully!";
                }
            }
        }
    }
}
