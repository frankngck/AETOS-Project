﻿using System.Data;
using System.Web;
using System.Web.SessionState;

enum RoleType
{
    SUPERADMIN, ADMIN, USER, NULL
}
enum TableType
{
    PREV_LOCATION, SKILL, DRIVING
}
