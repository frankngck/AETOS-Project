﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BookingSystem
{
    public partial class AdminTakeAttendance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Generate the Drop Down list for the cluster
                GenerateDrpCluster();
                // Generate the Drop Down list for the shifts by the selected cluster in the cluster dropdown
                GenerateDrpShifts();
                // Generate the table
                ShowTable();
            }
            // Cannot put ShowTable() inside page_load
            // update will be useless
        }

        protected void ShowTable()
        {
            // the SQL to get the user who book for that particular date.
            string sqlGrivView = String.Format(@"SELECT * FROM Users U, User_has_Tier UT, Tier T, User_has_Cluster UC, 
                                                Cluster C, Sub_Cluster SC, Shifts S, Sub_Cluster_has_Shift SCS, 
                                                Cluster_Booking B
                                                WHERE U.nric = UT.nric
                                                AND UT.tier_id = T.tier_id
                                                AND U.nric = UC.nric
                                                AND UC.cluster_id = C.cluster_id
                                                AND T.tier_id = C.tier_id
                                                AND C.cluster_id = SC.cluster_id
                                                AND SC.sub_cluster_id = SCS.sub_cluster_id
                                                AND SCS.sub_shift_id = B.sub_shift_id
                                                AND U.nric = B.nric
                                                AND SCS.shift_code = S.shift_code
                                                AND booking_date = '{0}'
                                                AND SCS.sub_shift_id = '{1}'
                                                ORDER BY service_id",
                                                //the date in the text box
                                                Convert.ToDateTime(TxtDate.Text).ToString("yyyy-MM-dd"),
                                                DrpShift.SelectedItem.Value);

            DataTable dtGridView = DBUtl.GetTable(sqlGrivView);
            // If there is result
            if (dtGridView.Rows.Count >= 1)
            {
                // setting the data to the gridview
                GvAttendance.DataSource = dtGridView;
                GvAttendance.DataBind();
                // a method to get the radio button click using the result from the sql
                ShowAttendanceStatus(dtGridView);

                // Below is to check if the selected date is before today or not
                DateTime parameterDate = Convert.ToDateTime(TxtDate.Text);
                DateTime todaysDate = DateTime.Today;
                if (parameterDate > todaysDate)
                {
                    // If the date chosen is after today
                    // e.g. today is Aug 1, but the admin chosen Aug 4 
                    // Then the button will be disabled.

                    // This is to disabled the button; the user cannot click on it
                    BtnSubmit.Enabled = false;

                    // This is to hide the button
                    BtnSubmit.Visible = false;
                }
                else
                {
                    // If the date chosen is before today
                    // e.g. today is Aug 1, but the admin chosen Aug 1 or even earlier like July 31
                    // Then the button will be enabled.

                    // This is to show the button
                    BtnSubmit.Visible = true;

                    // This is to enable the button; the user can click on it
                    BtnSubmit.Enabled = true;
                }
            }
            else
            {
                // if not result
                // Means no one book for that day
                GvAttendance.DataSource = null;
                GvAttendance.DataBind();
                BtnSubmit.Visible = false;
                BtnSubmit.Enabled = false;
            }
            LtlMessage.Text = "";
        }

        protected void ShowAttendanceStatus(DataTable dtGridView)
        {
            // empty string array
            string[] attendanceNRIC;
            string[] attendanceBookingID;
            string[] attendanceStatus;

            // this is to save the array of the part timer's nric and their booking id in session
            // and also return the two arrays.
            SaveAttendanceList(dtGridView, out attendanceNRIC, out attendanceBookingID);

            // this is to get the attendance status (present, absent, or haven mark yet) 
            // using the array of nric and booking id from just now
            // stored in session
            // and also return the array of the status
            GetAttendanceStatus(attendanceNRIC, attendanceBookingID, out attendanceStatus);

            // this is to make the radio button click depends on the status
            ShowButtonStatus(attendanceStatus);

            // this is the get the remark from the attendance first
            // if attendance is null then get it from clusterbooking table
            ShowRemarks(attendanceNRIC, attendanceBookingID);
        }

        protected void ShowRemarks(string[] attendanceNRIC, string[] attendanceBookingID)
        {
            int count = 0;
            // gridview loop
            foreach (GridViewRow row in GvAttendance.Rows)
            {
                // find the control in the gridview
                TextBox TxtRemarks = (TextBox)row.FindControl("TxtRemarks");

                // the SQL to get the individual remarks for each nric and the booking id
                string sql1 = String.Format(@"SELECT * FROM Attendance WHERE clusterbooking_id = '{0}'", attendanceBookingID[count]);
                if (DBUtl.GetTable(sql1).Rows.Count != 0)
                {
                    if (!DBUtl.GetTable(sql1).Rows[0]["remarks"].ToString().Equals(""))
                    {
                        TxtRemarks.Text = DBUtl.GetTable(sql1).Rows[0]["remarks"].ToString();
                    }
                }
                else
                {
                    // when the attendance does not have remarks value
                    // means in the attendance is null value
                    // will get it from clusterbooking
                    string sql = String.Format(@"SELECT * FROM Cluster_Booking WHERE clusterbooking_id = '{0}'", attendanceBookingID[count]);
                    if (DBUtl.GetTable(sql).Rows[0]["remarks"].ToString() != null)
                    {
                        TxtRemarks.Text = DBUtl.GetTable(sql).Rows[0]["remarks"].ToString();
                    }
                }
                count++;
            }
        }

        protected void SaveAttendanceList(DataTable dtGridView, out string[] attendanceNRIC, out string[] attendanceBookingID)
        {
            // setting the size of the array to the same as the gridview
            attendanceNRIC = new string[GvAttendance.Rows.Count];
            attendanceBookingID = new string[GvAttendance.Rows.Count];

            // Using loop get the nric and the their booking id from the datatable
            for (int i = 0; i < dtGridView.Rows.Count; i++)
            {
                attendanceNRIC[i] = dtGridView.Rows[i]["nric"].ToString();
                attendanceBookingID[i] = dtGridView.Rows[i]["clusterbooking_id"].ToString();
            }

            // Save the array in session.
            // so that can retrieve them in another method
            Session["nric_array"] = attendanceNRIC;
            Session["booking_id"] = attendanceBookingID;
        }

        protected void GetAttendanceStatus(string[] attendanceNRIC, string[] attendanceBookingID, out string[] attendanceStatus)
        {
            // setting the size of the array to the same as the gridview
            attendanceStatus = new string[GvAttendance.Rows.Count];

            // const string means the string is fixed
            // so that can be reused in the loop 
            // as a get statement
            // where the '{0}' etc. won't be missing
            const string sqlAttendance = @"SELECT * FROM Attendance WHERE clusterbooking_id = {0} AND nric = '{1}'";

            // for loop to get the attendance status from the database and stored in a list
            for (int i = 0; i < attendanceNRIC.Length && i < attendanceBookingID.Length; i++)
            {
                // set the sql in another string 
                string sqlStatus = String.Format(sqlAttendance, attendanceBookingID[i], attendanceNRIC[i]);
                DataTable dtStatus = DBUtl.GetTable(sqlStatus);
                if (dtStatus.Rows.Count == 0) // attendance not marked yet
                    attendanceStatus[i] = "-1";
                else if (dtStatus.Rows[0]["attendance_status"].ToString().Equals("1")) // present
                    attendanceStatus[i] = "1";
                else if (dtStatus.Rows[0]["attendance_status"].ToString().Equals("0")) // absent
                    attendanceStatus[i] = "0";
            }

            // stored in a session
            // retriving in another method
            Session["attendance_status"] = attendanceStatus;
        }

        protected void ShowButtonStatus(string[] attendanceStatus)
        {
            int count = 0;
            // gridvieww loop
            foreach (GridViewRow row in GvAttendance.Rows)
            {
                // finding the control inside the gridview
                RadioButton present = (RadioButton)row.FindControl("RbPresent");
                RadioButton absent = (RadioButton)row.FindControl("RbAbsent");

                // using the attendance status to determine which radio button to be clicked
                if (attendanceStatus[count].Equals("1"))
                    present.Checked = true;
                else if (attendanceStatus[count].Equals("0"))
                    absent.Checked = true;
                else
                {
                    // attendance not marked yet
                    present.Checked = false;
                    absent.Checked = false;
                }
                // increase count
                count++;
            }
            // for loop method same as the foreach
            //for (int i = 0; i < GvAttendance.Rows.Count; i++)
            //{
            //    RadioButton present = (RadioButton)GvAttendance.Rows[i].FindControl("RbPresent");
            //    RadioButton absent = (RadioButton)GvAttendance.Rows[i].FindControl("RbAbsent");

            //    // using the attendance status to determine which radio button to be clicked
            //    if (attendanceStatus[count].Equals("1"))
            //        present.Checked = true;
            //    else if (attendanceStatus[count].Equals("0"))
            //        absent.Checked = true;
            //    else
            //    {
            //        // attendance not marked yet
            //        present.Checked = false;
            //        absent.Checked = false;
            //    }
            //}
        }

        private string[] GetRmarks()
        {
            // setting the size same as the gridview
            string[] remarks = new string[GvAttendance.Rows.Count];
            int count = 0;
            // loop
            foreach (GridViewRow row in GvAttendance.Rows)
            {
                // find the control in the gridview
                TextBox TxtRemarks = (TextBox)row.FindControl("TxtRemarks");
                if (TxtRemarks.Text.Equals("")) // if the admin did not write any remarks
                {
                    remarks[count] = null;
                }
                else // if the admin write remarks
                {
                    remarks[count] = TxtRemarks.Text;
                }
                count++;
            }
            return remarks;
        }

        // method runs when the admin click submit
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            LtlMessage.Text = "";

            // getting the array from the session
            string[] attendanceNRIC = (string[])Session["nric_array"];
            string[] attendanceBookingID = (string[])Session["booking_id"];
            string[] attendanceStatus = (string[])Session["attendance_status"];

            // setting the new attendance status as the same size as the old status array length
            string[] attendanceStatusNew = new string[attendanceStatus.Length];

            // getting the remark list from the gridview
            string[] remarksList = GetRmarks();
            // sql for the insert statement
            string sqlInsert = @"INSERT INTO Attendance(attendance_status, nric, clusterbooking_id, remarks) 
                                        VALUES ('{0}', '{1}', '{2}', '{3}'); ";

            // sql for the update statement
            // if the attendance was already marked
            // so that there is no duplicate records
            string sqlUpdate = @"UPDATE Attendance
                                        SET attendance_status = '{0}', remarks = '{3}'
                                        WHERE nric = '{1}'
                                        AND clusterbooking_id = '{2}'; ";

            // the two sql below is without remarks
            string sqlInsertNoRemarks = @"INSERT INTO Attendance(attendance_status, nric, clusterbooking_id) 
                                        VALUES ('{0}', '{1}', '{2}'); ";

            // sql for the update statement
            // if the attendance was already marked
            // so that there is no duplicate records
            string sqlUpdateNoRemarks = @"UPDATE Attendance
                                        SET attendance_status = '{0}'
                                        WHERE nric = '{1}'
                                        AND clusterbooking_id = '{2}'; ";

            // getting the newest status from the gridview
            for (int i = 0; i < GvAttendance.Rows.Count; i++)
            {
                RadioButton present = (GvAttendance.Rows[i].FindControl("RbPresent") as RadioButton);
                RadioButton absent = (GvAttendance.Rows[i].FindControl("RbAbsent") as RadioButton);
                if (present.Checked == true)
                    attendanceStatusNew[i] = "1";
                else if (absent.Checked == true)
                    attendanceStatusNew[i] = "0";
                else
                    attendanceStatusNew[i] = "-1";
            }
            string sqlExec = "";
            for (int i = 0; i < attendanceNRIC.Length; i++)
            {
                if (attendanceStatusNew[i].Equals("-1")) // no radio button selected then continue on the next one
                    continue;
                else if (attendanceStatusNew[i].Equals("1") && attendanceStatus[i].Equals("0"))
                {
                    if (remarksList[i] == null)
                        // Change attendance from present to absent
                        sqlExec += String.Format(sqlUpdateNoRemarks, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i]);
                    else
                        // Change attendance from present to absent
                        sqlExec += String.Format(sqlUpdate, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i], remarksList[i]);
                }
                else if (attendanceStatusNew[i].Equals("0") && attendanceStatus[i].Equals("1")) 
                {
                    if (remarksList[i] == null)
                        // Change attendance from absent to present
                        sqlExec += String.Format(sqlUpdateNoRemarks, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i]);
                    else
                        // Change attendance from absent to present
                        sqlExec += String.Format(sqlUpdate, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i], remarksList[i]);
                }
                else if (attendanceStatusNew[i].Equals("1") && attendanceStatus[i].Equals("-1")) 
                {
                    if (remarksList[i] == null)
                        // Change attendance from not mark to present
                        sqlExec += String.Format(sqlInsertNoRemarks, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i]);
                    else
                        // Change attendance from not mark to present
                        sqlExec += String.Format(sqlInsert, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i], remarksList[i]);
                }
                else if (attendanceStatusNew[i].Equals("0") && attendanceStatus[i].Equals("-1")) 
                {
                    if (remarksList[i] == null)
                        // Change attendance from not mark to absent
                        sqlExec += String.Format(sqlInsertNoRemarks, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i]);
                    else
                        // Change attendance from not mark to absent
                        sqlExec += String.Format(sqlInsert, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i], remarksList[i]);
                }
                else if (attendanceStatusNew[i].Equals("0") && attendanceStatus[i].Equals("0")) 
                {
                    if (remarksList[i] == null)
                        // Same attendance status; absent
                        sqlExec += String.Format(sqlUpdateNoRemarks, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i]);
                    else
                        // Same attendance status; absent
                        sqlExec += String.Format(sqlUpdate, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i], remarksList[i]);
                }
                else if (attendanceStatusNew[i].Equals("1") && attendanceStatus[i].Equals("1")) 
                {
                    if (remarksList[i] == null)
                        // Same attendance status; present
                        sqlExec += String.Format(sqlUpdateNoRemarks, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i]);
                    else
                        // Same attendance status; present
                        sqlExec += String.Format(sqlUpdate, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i], remarksList[i]);
                }
                else
                {
                    if (remarksList[i] == null)
                        sqlExec += String.Format(sqlInsertNoRemarks, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i]);
                    else
                        sqlExec += String.Format(sqlInsert, attendanceStatusNew[i], attendanceNRIC[i], attendanceBookingID[i], remarksList[i]);
                }
            }
            LtlMessage.Text += sqlExec;
            if (sqlExec.Length == 0)
            {
                LtlMessage.Text = "No Button selected";
                return;
            }
            if (DBUtl.ExecSQL(sqlExec) >= 1)
                LtlMessage.Text = "Attendance Updated Successfully";
            else
                LtlMessage.Text = "Failed to Update Attendance" + DBUtl.DB_Message + sqlExec;
        }

        protected void DrpShift_SelectedIndexChanged(object sender, EventArgs e)
        {
            // regenerate the table when the shift selected is changed
            ShowTable();
        }

        protected void DrpCluster_SelectedIndexChanged(object sender, EventArgs e)
        {
            // regenerate the shift when the cluster selected is changed
            GenerateDrpShifts();
            // regenerate the table when the cluster selected is changed
            ShowTable();
        }

        // to generate the shift
        private void GenerateDrpShifts()
        {
            // Shifts
            string sqlAllShift = String.Format(@"SELECT * FROM Sub_Cluster SC, Sub_Cluster_has_Shift SCS, 
                                                Shifts S 
                                                WHERE SC.sub_cluster_id = SCS.sub_cluster_id 
                                                AND SCS.shift_code = S.shift_code
                                                AND SC.sub_cluster_id = {0}",
                                            DrpCluster.SelectedItem.Value);
            DataTable dtAllShift = DBUtl.GetTable(sqlAllShift);

            if (dtAllShift.Rows.Count >= 1)
            {
                DrpShift.DataSource = dtAllShift;
                DrpShift.DataTextField = "shift_no"; // the items to be displayed in the list items
                DrpShift.DataValueField = "sub_shift_id"; // the id of the items displayed
                DrpShift.DataBind();
            }
        }

        // to generate the cluster drop down
        private void GenerateDrpCluster()
        {
            TxtDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            string sqlAllSubCluster = string.Format(@"SELECT * FROM Cluster C, Sub_Cluster SC
                                WHERE C.cluster_id = SC.cluster_id
                                AND cluster_name = '{0}'", Session["cluster"].ToString());
            DataTable dtAllCluster = DBUtl.GetTable(sqlAllSubCluster);

            if (dtAllCluster.Rows.Count >= 1)
            {
                DrpCluster.DataSource = dtAllCluster;
                DrpCluster.DataTextField = "sub_cluster_name"; // the items to be displayed in the list items
                DrpCluster.DataValueField = "sub_cluster_id"; // the id of the items displayed
                DrpCluster.DataBind();
            }
        }
    }
}